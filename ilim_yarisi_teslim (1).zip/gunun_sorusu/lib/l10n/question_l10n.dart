/// Kategori adları sunucudan serbest metin gelir; bilinen Türkçe adlar İngilizce
/// arayüzde çevrilir, bilinmeyenler olduğu gibi gösterilir.
const Map<String, String> _catEn = {
  'Tümü': 'All',
  'Coğrafya': 'Geography',
  'Bilim': 'Science',
  'Tarih': 'History',
  'Sanat': 'Art',
  'Matematik': 'Mathematics',
  'Edebiyat': 'Literature',
  'Genel Kültür': 'General Knowledge',
  'Teknoloji': 'Technology',
  'Spor': 'Sports',
};

String categoryLabel(String key, String lang) =>
    lang == 'en' ? (_catEn[key] ?? key) : key;
