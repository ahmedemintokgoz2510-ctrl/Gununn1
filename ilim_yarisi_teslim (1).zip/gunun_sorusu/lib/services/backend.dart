import 'dart:async';

import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';

import '../firebase_config.dart';
import '../models/api_models.dart';

enum BackendError { network, unauthenticated, noQuestion, invalid, auth, other }

class BackendException implements Exception {
  const BackendException(this.kind, [this.code = '']);
  final BackendError kind;
  final String code;

  @override
  String toString() => 'BackendException($kind, $code)';
}

Object? _deep(Object? v) {
  if (v is Map) {
    return v.map<String, dynamic>((k, val) => MapEntry(k.toString(), _deep(val)));
  }
  if (v is List) return v.map(_deep).toList();
  return v;
}

Map<String, dynamic> _asMap(Object? v) {
  final d = _deep(v);
  return d is Map<String, dynamic> ? d : <String, dynamic>{};
}

/// Firebase Auth + Cloud Functions erişimi. Firestore'a istemciden doğrudan
/// erişilmez; tüm iş kuralları sunucuda çalışır.
class Backend {
  bool get configured => kBackendConfigured;
  FirebaseAuth? _auth;
  FirebaseFunctions? _fn;

  Future<void> init() async {
    if (!configured) return;
    await Firebase.initializeApp(
      options: const FirebaseOptions(
        apiKey: kFirebaseApiKey,
        appId: kFirebaseAppId,
        messagingSenderId: kFirebaseSenderId,
        projectId: kFirebaseProjectId,
      ),
    );
    _auth = FirebaseAuth.instance;
    _fn = FirebaseFunctions.instanceFor(region: kFunctionsRegion);
  }

  String? get uid => _auth?.currentUser?.uid;
  String? get email => _auth?.currentUser?.email;
  Stream<String?> get authChanges =>
      _auth?.authStateChanges().map((u) => u?.uid) ?? const Stream<String?>.empty();

  // ------------------------------------------------------------------ hesap
  Future<T> _authCall<T>(Future<T> Function(FirebaseAuth a) f) async {
    final a = _auth;
    if (a == null) throw const BackendException(BackendError.other, 'not-configured');
    try {
      return await f(a);
    } on FirebaseAuthException catch (e) {
      throw BackendException(BackendError.auth, e.code);
    } catch (_) {
      throw const BackendException(BackendError.network, 'network');
    }
  }

  Future<void> signIn(String email, String password) => _authCall(
        (a) => a.signInWithEmailAndPassword(email: email, password: password),
      );

  Future<void> register(String email, String password) => _authCall(
        (a) => a.createUserWithEmailAndPassword(email: email, password: password),
      );

  Future<void> resetPassword(String email) =>
      _authCall((a) => a.sendPasswordResetEmail(email: email));

  Future<void> signOut() async => _auth?.signOut();

  // -------------------------------------------------------------- fonksiyonlar
  Future<Map<String, dynamic>> _call(String name, Map<String, dynamic> data) async {
    final f = _fn;
    if (f == null) throw const BackendException(BackendError.other, 'not-configured');
    try {
      final r = await f
          .httpsCallable(name, options: HttpsCallableOptions(timeout: const Duration(seconds: 20)))
          .call<dynamic>(data);
      return _asMap(r.data);
    } on FirebaseFunctionsException catch (e) {
      final BackendError kind;
      switch (e.code) {
        case 'unavailable':
        case 'deadline-exceeded':
          kind = BackendError.network;
        case 'unauthenticated':
          kind = BackendError.unauthenticated;
        case 'failed-precondition':
          kind = BackendError.noQuestion;
        case 'invalid-argument':
          kind = BackendError.invalid;
        default:
          kind = BackendError.other;
      }
      throw BackendException(kind, e.code);
    } on TimeoutException {
      throw const BackendException(BackendError.network, 'timeout');
    } catch (_) {
      throw const BackendException(BackendError.network, 'network');
    }
  }

  Future<DailyStatus> getToday(String lang) async =>
      DailyStatus.fromMap(await _call('getToday', {'lang': lang}));

  Future<QuizSession> startQuestion(String lang) async =>
      QuizSession.fromMap(await _call('startQuestion', {'lang': lang}));

  Future<SubmitOutcome> submitAnswer(int index, String lang) async {
    final m = await _call('submitAnswer', {'answerIndex': index, 'lang': lang});
    return SubmitOutcome(
      AnswerResult.fromMap(_asMap(m['result'])),
      duplicate: m['duplicate'] == true,
    );
  }

  Future<Profile> getProfile() async => Profile.fromMap(await _call('getProfile', {}));

  Future<List<AnswerResult>> getHistory(String lang) async {
    final m = await _call('getHistory', {'lang': lang});
    final l = m['items'];
    return (l is List)
        ? l.whereType<Map<String, dynamic>>().map(AnswerResult.fromMap).toList()
        : <AnswerResult>[];
  }

  Future<List<ArchiveItem>> getArchive(String lang) async {
    final m = await _call('getArchive', {'lang': lang});
    final l = m['items'];
    return (l is List)
        ? l.whereType<Map<String, dynamic>>().map(ArchiveItem.fromMap).toList()
        : <ArchiveItem>[];
  }

  Future<Leaderboard> getLeaderboard(String period) async =>
      Leaderboard.fromMap(await _call('getLeaderboard', {'period': period}));

  Future<void> setDisplayName(String name, {String? phone}) async {
    await _call('setDisplayName', {
      'name': name,
      if (phone != null) 'phone': phone,
    });
  }
}
