int _int(Object? v) => (v is num) ? v.toInt() : 0;
List<String> _strings(Object? v) =>
    (v is List) ? v.map((e) => e.toString()).toList() : <String>[];

/// Sunucunun kaydettiği (dondurulmuş) cevap + soru kopyası.
class AnswerResult {
  const AnswerResult({
    required this.date,
    required this.selectedIndex,
    required this.correctIndex,
    required this.correct,
    required this.points,
    required this.basePoints,
    required this.bonusPoints,
    required this.elapsedMs,
    required this.category,
    required this.text,
    required this.options,
    required this.explanation,
  });

  final String date; // yyyy-MM-dd (sunucu, Europe/Istanbul)
  final int selectedIndex;
  final int correctIndex;
  final bool correct;
  final int points;
  final int basePoints;
  final int bonusPoints;
  final int elapsedMs;
  final String category;
  final String text;
  final List<String> options;
  final String explanation;

  Duration get elapsed => Duration(milliseconds: elapsedMs);

  factory AnswerResult.fromMap(Map<String, dynamic> m) => AnswerResult(
        date: (m['date'] ?? '') as String,
        selectedIndex: _int(m['selectedIndex']),
        correctIndex: _int(m['correctIndex']),
        correct: m['correct'] == true,
        points: _int(m['points']),
        basePoints: _int(m['basePoints']),
        bonusPoints: _int(m['bonusPoints']),
        elapsedMs: _int(m['elapsedMs']),
        category: (m['category'] ?? '') as String,
        text: (m['text'] ?? '') as String,
        options: _strings(m['options']),
        explanation: (m['explanation'] ?? '') as String,
      );
}

enum DayStatus { published, scheduled, none }

class DailyStatus {
  const DailyStatus({
    required this.status,
    required this.date,
    this.category = '',
    this.answered = false,
    this.result,
    this.publishTime = '',
  });

  final DayStatus status;
  final String date;
  final String category;
  final bool answered;
  final AnswerResult? result;
  final String publishTime;

  factory DailyStatus.fromMap(Map<String, dynamic> m) {
    final st = m['status'];
    final r = m['result'];
    return DailyStatus(
      status: st == 'published'
          ? DayStatus.published
          : st == 'scheduled'
              ? DayStatus.scheduled
              : DayStatus.none,
      date: (m['date'] ?? '') as String,
      category: (m['category'] ?? '') as String,
      answered: m['answered'] == true,
      result: r is Map<String, dynamic> ? AnswerResult.fromMap(r) : null,
      publishTime: (m['publishTime'] ?? '') as String,
    );
  }
}

/// Soru açıldığında sunucudan gelen oturum: süre sunucudaki başlangıca göre işler.
class QuizSession {
  const QuizSession({
    this.answered = false,
    this.result,
    this.date = '',
    this.category = '',
    this.text = '',
    this.options = const [],
    this.startedAtMs = 0,
    this.serverNowMs = 0,
  });

  final bool answered;
  final AnswerResult? result;
  final String date;
  final String category;
  final String text;
  final List<String> options;
  final int startedAtMs;
  final int serverNowMs;

  /// Sunucuda şimdiye kadar geçen süre (ekran açıldığı andaki değer).
  int get elapsedAtResponseMs {
    final d = serverNowMs - startedAtMs;
    return d < 0 ? 0 : d;
  }

  factory QuizSession.fromMap(Map<String, dynamic> m) {
    final r = m['result'];
    final q = m['question'];
    final qm = q is Map<String, dynamic> ? q : const <String, dynamic>{};
    return QuizSession(
      answered: m['answered'] == true,
      result: r is Map<String, dynamic> ? AnswerResult.fromMap(r) : null,
      date: (qm['date'] ?? '') as String,
      category: (qm['category'] ?? '') as String,
      text: (qm['text'] ?? '') as String,
      options: _strings(qm['options']),
      startedAtMs: _int(m['startedAtMs']),
      serverNowMs: _int(m['serverNow']),
    );
  }
}

class SubmitOutcome {
  const SubmitOutcome(this.result, {this.duplicate = false});
  final AnswerResult result;
  final bool duplicate;
}

class Profile {
  const Profile({
    required this.displayName,
    this.phone = '',
    required this.totalAnswered,
    required this.totalCorrect,
    required this.totalPoints,
    required this.streak,
    required this.currentStreak,
    required this.bestStreak,
  });

  final String displayName;
  final String phone;
  final int totalAnswered;
  final int totalCorrect;
  final int totalPoints;
  final int streak;
  final int currentStreak;
  final int bestStreak;

  factory Profile.fromMap(Map<String, dynamic> m) => Profile(
        displayName: (m['displayName'] ?? '') as String,
        phone: (m['phone'] ?? '') as String,
        totalAnswered: _int(m['totalAnswered']),
        totalCorrect: _int(m['totalCorrect']),
        totalPoints: _int(m['totalPoints']),
        streak: _int(m['streak']),
        currentStreak: _int(m['currentStreak']),
        bestStreak: _int(m['bestStreak']),
      );
}

class ArchiveItem {
  const ArchiveItem({
    required this.date,
    required this.category,
    required this.text,
    required this.options,
    required this.correctIndex,
    required this.explanation,
    this.myAnswer,
  });

  final String date;
  final String category;
  final String text;
  final List<String> options;
  final int? correctIndex;
  final String explanation;
  final int? myAnswer;

  factory ArchiveItem.fromMap(Map<String, dynamic> m) => ArchiveItem(
        date: (m['date'] ?? '') as String,
        category: (m['category'] ?? '') as String,
        text: (m['text'] ?? '') as String,
        options: _strings(m['options']),
        correctIndex: m['correctIndex'] is num ? _int(m['correctIndex']) : null,
        explanation: (m['explanation'] ?? '') as String,
        myAnswer: m['myAnswer'] is num ? _int(m['myAnswer']) : null,
      );
}

class LeaderEntry {
  const LeaderEntry({
    required this.rank,
    required this.name,
    required this.points,
    required this.isMe,
  });

  final int rank;
  final String name;
  final int points;
  final bool isMe;

  factory LeaderEntry.fromMap(Map<String, dynamic> m) => LeaderEntry(
        rank: _int(m['rank']),
        name: (m['name'] ?? '') as String,
        points: _int(m['points']),
        isMe: m['isMe'] == true,
      );
}

class Leaderboard {
  const Leaderboard({required this.entries, this.meRank, this.mePoints});

  final List<LeaderEntry> entries;
  final int? meRank;
  final int? mePoints;

  factory Leaderboard.fromMap(Map<String, dynamic> m) {
    final list = m['entries'];
    final me = m['me'];
    return Leaderboard(
      entries: (list is List)
          ? list
              .whereType<Map<String, dynamic>>()
              .map(LeaderEntry.fromMap)
              .toList()
          : <LeaderEntry>[],
      meRank: me is Map<String, dynamic> ? _int(me['rank']) : null,
      mePoints: me is Map<String, dynamic> ? _int(me['points']) : null,
    );
  }
}
