import 'dart:async';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/api_models.dart';
import '../services/backend.dart';

enum AuthStatus { unconfigured, signedOut, signedIn }

enum DataStatus { idle, loading, ready, error }

int _dayNum(String d) {
  final p = d.split('-');
  if (p.length != 3) return 0;
  final dt = DateTime.utc(int.parse(p[0]), int.parse(p[1]), int.parse(p[2]));
  return dt.millisecondsSinceEpoch ~/ 86400000;
}

String _addDay(String d) {
  final p = d.split('-');
  final dt = DateTime.utc(int.parse(p[0]), int.parse(p[1]), int.parse(p[2]) + 1);
  final m = dt.month.toString().padLeft(2, '0');
  final day = dt.day.toString().padLeft(2, '0');
  return '${dt.year}-$m-$day';
}

/// Uygulama durumu. Günlük hak, puan ve cevaplar SUNUCUDA tutulur; burada yalnızca
/// görüntü tercihleri ve "istatistik görünümü başlangıcı" yerel saklanır.
class AppState extends ChangeNotifier {
  AppState(this._backend);

  final Backend _backend;
  SharedPreferences? _prefs;
  StreamSubscription<String?>? _authSub;

  ThemeMode themeMode = ThemeMode.system;
  String language = 'tr';
  bool welcomeSeen = false;

  AuthStatus authStatus = AuthStatus.signedOut;
  DataStatus dataStatus = DataStatus.idle;
  DailyStatus? today;
  Profile? profile;
  List<AnswerResult> _history = [];
  String? _statsFrom;

  bool get backendConfigured => _backend.configured;
  String? get uid => _backend.uid;
  String get email => _backend.email ?? '';
  String get displayName => profile?.displayName ?? '';
  String get phone => profile?.phone ?? '';
  List<AnswerResult> get history => _history;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    _prefs = prefs;

    final t = prefs.getInt('theme') ?? 0;
    themeMode = (t >= 0 && t < ThemeMode.values.length)
        ? ThemeMode.values[t]
        : ThemeMode.system;
    final lang = prefs.getString('lang');
    language = (lang == 'en' || lang == 'tr') ? lang! : 'tr';
    welcomeSeen = prefs.getBool('welcome_seen') ?? false;

    if (!_backend.configured) {
      authStatus = AuthStatus.unconfigured;
      return;
    }
    await _backend.init();
    _onAuth(_backend.uid);
    _authSub = _backend.authChanges.listen(_onAuth);
  }

  @override
  void dispose() {
    _authSub?.cancel();
    super.dispose();
  }

  void _onAuth(String? uid) {
    if (uid == null) {
      authStatus = AuthStatus.signedOut;
      today = null;
      profile = null;
      _history = [];
      _statsFrom = null;
      dataStatus = DataStatus.idle;
      notifyListeners();
    } else {
      authStatus = AuthStatus.signedIn;
      _statsFrom = _prefs?.getString('stats_from_$uid');
      notifyListeners();
      unawaited(refreshAll());
    }
  }

  // ---------------------------------------------------------------- veri yükleme
  Future<void> refreshAll() async {
    if (authStatus != AuthStatus.signedIn) return;
    dataStatus = DataStatus.loading;
    notifyListeners();
    try {
      final r = await Future.wait<Object?>([
        _backend.getToday(language),
        _backend.getProfile(),
        _backend.getHistory(language),
      ]);
      today = r[0] as DailyStatus;
      profile = r[1] as Profile;
      _history = r[2] as List<AnswerResult>;
      dataStatus = DataStatus.ready;
    } catch (_) {
      dataStatus = DataStatus.error;
    }
    notifyListeners();
  }

  Future<List<ArchiveItem>> loadArchive() => _backend.getArchive(language);
  Future<Leaderboard> loadLeaderboard(String period) => _backend.getLeaderboard(period);

  // ----------------------------------------------------------------- yarışma
  Future<QuizSession> startQuiz() => _backend.startQuestion(language);

  /// Cevabı sunucuya gönderir. Ağ koparsa, istek sunucuya ulaşmış olabilir:
  /// bu durumda gerçek durum sunucudan sorgulanır; yanlış sonuç gösterilmez.
  Future<SubmitOutcome> submit(int index) async {
    try {
      final out = await _backend.submitAnswer(index, language);
      unawaited(refreshAll());
      return out;
    } on BackendException catch (e) {
      if (e.kind == BackendError.network) {
        try {
          final t = await _backend.getToday(language);
          final r = t.result;
          if (t.answered && r != null) {
            unawaited(refreshAll());
            return SubmitOutcome(r);
          }
        } catch (_) {
          // Durum doğrulanamadı: kullanıcıya ağ hatası gösterilir.
        }
      }
      rethrow;
    }
  }

  // ------------------------------------------------------ istatistik görünümü
  List<AnswerResult> get _viewItems {
    final from = _statsFrom;
    if (from == null) return _history;
    return _history.where((e) => e.date.compareTo(from) >= 0).toList();
  }

  bool get statsViewReset => _statsFrom != null;

  int get totalAnswered =>
      _statsFrom == null ? (profile?.totalAnswered ?? _history.length) : _viewItems.length;

  int get totalCorrect => _statsFrom == null
      ? (profile?.totalCorrect ?? _history.where((e) => e.correct).length)
      : _viewItems.where((e) => e.correct).length;

  int get totalPoints => _statsFrom == null
      ? (profile?.totalPoints ?? _history.fold<int>(0, (a, e) => a + e.points))
      : _viewItems.fold<int>(0, (a, e) => a + e.points);

  List<int> get _viewDays {
    final days = _viewItems.map((e) => _dayNum(e.date)).toSet().toList()..sort();
    return days;
  }

  int get bestStreak {
    if (_statsFrom == null) return profile?.bestStreak ?? 0;
    var best = 0;
    var run = 0;
    int? prev;
    for (final d in _viewDays) {
      run = (prev != null && d == prev + 1) ? run + 1 : 1;
      if (run > best) best = run;
      prev = d;
    }
    return best;
  }

  int get currentStreak {
    if (_statsFrom == null) return profile?.currentStreak ?? 0;
    final days = _viewDays;
    final t = today;
    if (days.isEmpty || t == null) return 0;
    final todayNum = _dayNum(t.date);
    if (days.last != todayNum && days.last != todayNum - 1) return 0;
    var run = 1;
    for (var i = days.length - 1; i > 0; i--) {
      if (days[i] == days[i - 1] + 1) {
        run++;
      } else {
        break;
      }
    }
    return run;
  }

  /// İstatistikleri sıfırla: yalnızca GÖRÜNÜMÜ yeniden başlatır. Sunucudaki cevaplar,
  /// günlük hak ve puanlar silinmez; aynı gün tekrar cevap verilemez.
  Future<void> resetStatsView() async {
    final u = uid;
    if (u == null) return;
    final base = today?.date;
    if (base == null) return;
    // Bugün zaten cevaplandıysa onu da hariç tutmak için yarından başlat.
    final from = _addDay(base);
    _statsFrom = from;
    await _prefs?.setString('stats_from_$u', from);
    notifyListeners();
  }

  /// Yerel uygulama verilerini temizle: tema/dil/karşılama ve istatistik görünümü
  /// sıfırlanır, oturum kapatılır. Sunucu kayıtları ve günlük hak etkilenmez.
  Future<void> clearLocalData() async {
    await _prefs?.clear();
    themeMode = ThemeMode.system;
    language = 'tr';
    welcomeSeen = false;
    _statsFrom = null;
    await _backend.signOut();
    notifyListeners();
  }

  // ------------------------------------------------------------------- hesap
  Future<void> signIn(String email, String password) =>
      _backend.signIn(email.trim(), password);

  Future<void> register(
    String name,
    String email,
    String password, {
    String phone = '',
  }) async {
    await _backend.register(email.trim(), password);
    try {
      await _backend.setDisplayName(name, phone: phone);
    } catch (_) {
      // Ad sonradan Hesap ekranından da değiştirilebilir.
    }
    unawaited(refreshAll());
  }

  Future<void> resetPassword(String email) => _backend.resetPassword(email.trim());

  Future<void> signOut() => _backend.signOut();

  Future<void> updateDisplayName(String name, {String? phone}) async {
    await _backend.setDisplayName(name, phone: phone);
    await refreshAll();
  }

  // ---------------------------------------------------------------- tercihler
  Future<void> setLanguage(String code) async {
    if (code != 'tr' && code != 'en') return;
    language = code;
    await _prefs?.setString('lang', code);
    notifyListeners();
    unawaited(refreshAll());
  }

  Future<void> completeWelcome() async {
    welcomeSeen = true;
    await _prefs?.setBool('welcome_seen', true);
    notifyListeners();
  }

  Future<void> setTheme(ThemeMode mode) async {
    themeMode = mode;
    await _prefs?.setInt('theme', mode.index);
    notifyListeners();
  }
}
