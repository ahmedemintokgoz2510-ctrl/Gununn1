import 'package:flutter/material.dart';

import '../state/app_scope.dart';
import '../state/app_state.dart';
import '../theme/app_icons.dart';
import '../widgets/app_card.dart';
import '../widgets/app_page.dart';

class AchievementsScreen extends StatelessWidget {
  final AppState state;
  const AchievementsScreen({super.key, required this.state});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: state,
      builder: (context, _) {
        final s = context.s;
        final badges = [
          _BadgeData('badge.first', 'badge.first_desc', state.totalAnswered, 1),
          _BadgeData('badge.streak3', 'badge.streak3_desc', state.bestStreak, 3),
          _BadgeData('badge.streak7', 'badge.streak7_desc', state.bestStreak, 7),
          _BadgeData('badge.correct10', 'badge.correct10_desc', state.totalCorrect, 10),
        ];
        return AppPage(
          title: s('profile.achievements'),
          showBack: true,
          child: ListView.separated(
            padding: const EdgeInsets.fromLTRB(20, 24, 20, 24),
            itemCount: badges.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (_, i) => _BadgeTile(data: badges[i]),
          ),
        );
      },
    );
  }
}

class _BadgeData {
  const _BadgeData(this.titleKey, this.descKey, this.value, this.goal);
  final String titleKey, descKey;
  final int value, goal;
  bool get unlocked => value >= goal;
}

class _BadgeTile extends StatelessWidget {
  const _BadgeTile({required this.data});
  final _BadgeData data;

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final p = context.pal;
    final on = data.unlocked;
    return AppCard(
      child: Row(
        children: [
          IconBadge(
            icon: AppIcons.award,
            bg: on ? null : p.bg,
            color: on ? null : p.muted,
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  s(data.titleKey),
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                    color: on ? p.text : p.muted,
                  ),
                ),
                const SizedBox(height: 2),
                Text(s(data.descKey), style: TextStyle(fontSize: 13, color: p.muted)),
              ],
            ),
          ),
          const SizedBox(width: 8),
          if (on)
            Icon(AppIcons.check, size: 20, color: p.success)
          else
            Text(
              '${data.value > data.goal ? data.goal : data.value}/${data.goal}',
              style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: p.muted),
            ),
        ],
      ),
    );
  }
}
