import 'package:flutter/material.dart';

import '../l10n/question_l10n.dart';
import '../models/api_models.dart';
import '../state/app_scope.dart';
import '../state/app_state.dart';
import '../theme/app_icons.dart';
import '../theme/app_theme.dart';
import '../utils/date_utils.dart';
import '../widgets/app_button.dart';
import '../widgets/app_card.dart';
import '../widgets/app_page.dart';
import '../widgets/state_views.dart';
import 'quiz_screen.dart';
import 'result_screen.dart';

class TodayScreen extends StatelessWidget {
  final AppState state;
  const TodayScreen({super.key, required this.state});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: state,
      builder: (context, _) {
        final s = context.s;
        final today = state.today;
        final total = state.totalAnswered;
        final accuracy =
            total == 0 ? null : (state.totalCorrect / total * 100).round();

        Widget body;
        if (today == null && state.dataStatus == DataStatus.error) {
          body = ErrorState(onRetry: state.refreshAll);
        } else if (today == null) {
          body = const Center(child: CircularProgressIndicator());
        } else {
          body = RefreshIndicator(
            onRefresh: state.refreshAll,
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(20, 24, 20, 24),
              children: [
                _dayCard(context, today),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: _MiniStat(
                        icon: AppIcons.flame,
                        label: s('home.streak'),
                        value: s.days(state.currentStreak),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _MiniStat(
                        icon: AppIcons.target,
                        label: s('home.accuracy'),
                        value: accuracy == null ? '—' : s.percent(accuracy),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                _MiniStat(
                  icon: AppIcons.award,
                  label: s('home.points'),
                  value: formatPoints(state.totalPoints, state.language),
                ),
              ],
            ),
          );
        }

        return AppPage(
          title: s('home.title'),
          // Tarih sunucudan (Europe/Istanbul) gelir; cihaz saati kullanılmaz.
          subtitle: today == null ? null : formatDate(DateTime.parse(today.date), state.language),
          trailing: _StreakChip(days: state.currentStreak),
          child: body,
        );
      },
    );
  }

  Widget _dayCard(BuildContext context, DailyStatus today) {
    final s = context.s;
    switch (today.status) {
      case DayStatus.none:
        return AppCard(
          child: EmptyStateInline(
            icon: AppIcons.calendar,
            title: s('home.none_title'),
            message: s('home.none_msg'),
          ),
        );
      case DayStatus.scheduled:
        return AppCard(
          child: EmptyStateInline(
            icon: AppIcons.timer,
            title: s('home.scheduled_title'),
            message: s('home.scheduled_msg', {'time': today.publishTime}),
          ),
        );
      case DayStatus.published:
        final r = today.result;
        if (today.answered && r != null) {
          return _DoneCard(
            correct: r.correct,
            points: formatPoints(r.points, state.language),
            onView: () => Navigator.of(context).push(
              MaterialPageRoute<void>(
                builder: (_) => ResultScreen(state: state, result: r),
              ),
            ),
          );
        }
        return _StartCard(
          category: categoryLabel(today.category, state.language),
          onStart: () => Navigator.of(context).push(
            MaterialPageRoute<void>(builder: (_) => QuizScreen(state: state)),
          ),
        );
    }
  }
}

/// Kart içinde kullanılan, ortalanmış kısa boş durum.
class EmptyStateInline extends StatelessWidget {
  const EmptyStateInline({
    super.key,
    required this.icon,
    required this.title,
    required this.message,
  });
  final IconData icon;
  final String title;
  final String message;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Column(
      children: [
        const SizedBox(height: 8),
        IconBadge(icon: icon, size: 52),
        const SizedBox(height: 14),
        Text(
          title,
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
        ),
        const SizedBox(height: 6),
        Text(
          message,
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 14, height: 1.4, color: p.muted),
        ),
        const SizedBox(height: 8),
      ],
    );
  }
}

class _StreakChip extends StatelessWidget {
  const _StreakChip({required this.days});
  final int days;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: p.gold.withValues(alpha: 0.6)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(AppIcons.flame, size: 16, color: p.gold),
          const SizedBox(width: 6),
          Text(
            context.s.days(days),
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: p.onHeader,
            ),
          ),
        ],
      ),
    );
  }
}

class _StartCard extends StatelessWidget {
  const _StartCard({required this.category, required this.onStart});
  final String category;
  final VoidCallback onStart;

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final p = context.pal;
    return AppCard(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              IconBadge(icon: AppIcons.calendar),
              const Spacer(),
              InfoPill(text: category),
            ],
          ),
          const SizedBox(height: 16),
          Text(
            s('home.card_title'),
            style: AppText.serif(24, color: p.text, height: 1.25),
          ),
          const SizedBox(height: 8),
          Text(
            s('home.card_desc'),
            style: TextStyle(fontSize: 14, height: 1.4, color: p.muted),
          ),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            decoration: BoxDecoration(
              color: p.bg,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: p.line),
            ),
            child: Row(
              children: [
                Icon(AppIcons.timer, size: 20, color: p.muted),
                const SizedBox(width: 10),
                Text(s('home.timer_label'), style: TextStyle(color: p.muted)),
                const Spacer(),
                Text(
                  '00:00',
                  style: TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.w700,
                    color: p.text,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          AppButton(
            label: s('home.start'),
            icon: AppIcons.arrowRight,
            trailingIcon: true,
            onPressed: onStart,
          ),
        ],
      ),
    );
  }
}

class _DoneCard extends StatelessWidget {
  const _DoneCard({required this.correct, required this.points, required this.onView});
  final bool correct;
  final String points;
  final VoidCallback onView;

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final p = context.pal;
    return AppCard(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          Row(
            children: [
              IconBadge(
                icon: correct ? AppIcons.check : AppIcons.close,
                bg: correct ? p.successBg : p.dangerBg,
                color: correct ? p.success : p.danger,
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      s('home.done_title'),
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      correct
                          ? '${s('home.done_correct')} · ${s('home.earned', {'n': points})}'
                          : s('home.done_wrong'),
                      style: TextStyle(color: p.muted),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          AppButton(
            label: s('home.view_result'),
            style: AppButtonStyle.outline,
            onPressed: onView,
          ),
          const SizedBox(height: 12),
          Text(
            s('home.next_tomorrow'),
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 13, color: p.muted),
          ),
        ],
      ),
    );
  }
}

class _MiniStat extends StatelessWidget {
  const _MiniStat({required this.icon, required this.label, required this.value});
  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 16, color: p.muted),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  label,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 12.5, color: p.muted),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}
