import 'package:flutter/material.dart';

import '../state/app_scope.dart';
import '../state/app_state.dart';
import '../theme/app_icons.dart';
import '../widgets/app_card.dart';
import '../widgets/app_page.dart';

class StatsScreen extends StatelessWidget {
  final AppState state;
  const StatsScreen({super.key, required this.state});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: state,
      builder: (context, _) {
        final s = context.s;
        final p = context.pal;
        final accuracy = state.totalAnswered == 0
            ? 0.0
            : state.totalCorrect / state.totalAnswered;

        return AppPage(
          title: s('stats.title'),
          showBack: true,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(20, 24, 20, 24),
            children: [
              Row(
                children: [
                  _StatCard(
                    icon: AppIcons.flame,
                    label: s('stats.current_streak'),
                    value: s.days(state.currentStreak),
                  ),
                  const SizedBox(width: 12),
                  _StatCard(
                    icon: AppIcons.award,
                    label: s('stats.best_streak'),
                    value: s.days(state.bestStreak),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  _StatCard(
                    icon: AppIcons.questions,
                    label: s('stats.answered'),
                    value: '${state.totalAnswered}',
                  ),
                  const SizedBox(width: 12),
                  _StatCard(
                    icon: AppIcons.check,
                    label: s('stats.correct'),
                    value: '${state.totalCorrect}',
                  ),
                ],
              ),
              const SizedBox(height: 12),
              AppCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            s('stats.accuracy'),
                            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
                          ),
                        ),
                        Text(
                          s.percent((accuracy * 100).round()),
                          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(6),
                      child: LinearProgressIndicator(value: accuracy, minHeight: 8),
                    ),
                    if (state.totalAnswered == 0) ...[
                      const SizedBox(height: 12),
                      Text(
                        s('stats.empty_msg'),
                        style: TextStyle(fontSize: 13, height: 1.4, color: p.muted),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _StatCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _StatCard({required this.icon, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Expanded(
      child: AppCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            IconBadge(icon: icon, size: 36),
            const SizedBox(height: 12),
            Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w700)),
            const SizedBox(height: 2),
            Text(label, style: TextStyle(fontSize: 13, color: p.muted)),
          ],
        ),
      ),
    );
  }
}
