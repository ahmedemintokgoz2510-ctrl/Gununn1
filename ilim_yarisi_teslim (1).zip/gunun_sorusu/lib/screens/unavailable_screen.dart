import 'package:flutter/material.dart';

import '../widgets/app_page.dart';
import '../widgets/state_views.dart';

/// Henüz etkin olmayan özellikler (ödüller, bildirimler) için ortak ekran.
class UnavailableScreen extends StatelessWidget {
  const UnavailableScreen({
    super.key,
    required this.title,
    required this.icon,
    required this.heading,
    required this.message,
  });
  final String title, heading, message;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: title,
      showBack: true,
      child: EmptyState(icon: icon, title: heading, message: message),
    );
  }
}
