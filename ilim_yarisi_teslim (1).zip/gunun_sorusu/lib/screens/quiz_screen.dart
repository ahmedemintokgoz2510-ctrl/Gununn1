import 'dart:async';

import 'package:flutter/material.dart';

import '../l10n/question_l10n.dart';
import '../models/api_models.dart';
import '../services/backend.dart';
import '../state/app_scope.dart';
import '../state/app_state.dart';
import '../theme/app_icons.dart';
import '../theme/app_theme.dart';
import '../utils/constants.dart';
import '../utils/date_utils.dart';
import '../widgets/app_button.dart';
import '../widgets/app_card.dart';
import '../widgets/app_page.dart';
import '../widgets/option_tile.dart';
import '../widgets/state_views.dart';
import 'result_screen.dart';

/// Soru çözme ekranı. Süre SUNUCUDA, soru açıldığı anda başlar; ekrandan çıkıp
/// dönmek veya uygulamayı arka plana almak süreyi sıfırlamaz. Ekrandaki sayaç yalnızca
/// görüntüdür, puan ve süre sunucuda hesaplanır.
class QuizScreen extends StatefulWidget {
  final AppState state;
  const QuizScreen({super.key, required this.state});

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> with WidgetsBindingObserver {
  final Stopwatch _watch = Stopwatch();
  Timer? _ticker;
  QuizSession? _session;
  bool _loading = true;
  bool _failed = false;
  bool _submitting = false;
  int? _selected;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _ticker?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Stopwatch tek yönlü (monotonic) çalışır; geri dönünce yalnızca ekranı tazele.
    if (state == AppLifecycleState.resumed && mounted) setState(() {});
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _failed = false;
    });
    try {
      final session = await widget.state.startQuiz();
      if (!mounted) return;
      final r = session.result;
      if (session.answered && r != null) {
        // Bugün zaten cevaplanmış: kayıtlı sonucu göster, yeniden çözdürme.
        Navigator.of(context).pushReplacement(
          MaterialPageRoute<void>(
            builder: (_) => ResultScreen(state: widget.state, result: r, duplicate: true),
          ),
        );
        return;
      }
      _watch
        ..reset()
        ..start();
      _ticker?.cancel();
      _ticker = Timer.periodic(const Duration(milliseconds: 500), (_) {
        if (mounted) setState(() {});
      });
      setState(() {
        _session = session;
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _failed = true;
      });
    }
  }

  Duration get _elapsed {
    final s = _session;
    if (s == null) return Duration.zero;
    return Duration(milliseconds: s.elapsedAtResponseMs) + _watch.elapsed;
  }

  Future<void> _submit() async {
    final sel = _selected;
    if (sel == null || _submitting) return;
    final s = context.s;
    final messenger = ScaffoldMessenger.of(context);
    final nav = Navigator.of(context);
    setState(() => _submitting = true);
    try {
      final out = await widget.state.submit(sel);
      if (!mounted) return;
      _ticker?.cancel();
      nav.pushReplacement(
        MaterialPageRoute<void>(
          builder: (_) => ResultScreen(
            state: widget.state,
            result: out.result,
            duplicate: out.duplicate,
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _submitting = false);
      final network = e is BackendException && e.kind == BackendError.network;
      messenger.showSnackBar(
        SnackBar(content: Text(network ? s('quiz.network_error') : s('quiz.error'))),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final p = context.pal;
    final lang = widget.state.language;
    final session = _session;

    if (_loading || _failed || session == null) {
      return AppPage(
        title: s('home.title'),
        showBack: true,
        child: _loading
            ? Center(child: Text(s('quiz.loading')))
            : ErrorState(onRetry: _load),
      );
    }

    return AppPage(
      title: s('home.title'),
      showBack: true,
      trailing: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: p.gold.withValues(alpha: 0.6)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(AppIcons.timer, size: 16, color: p.gold),
            const SizedBox(width: 6),
            Text(
              formatDuration(_elapsed),
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w700,
                color: p.onHeader,
              ),
            ),
          ],
        ),
      ),
      child: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(20, 24, 20, 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  InfoPill(text: categoryLabel(session.category, lang)),
                  const SizedBox(height: 14),
                  Text(
                    session.text,
                    style: AppText.serif(24, color: p.text, height: 1.3),
                  ),
                  const SizedBox(height: 24),
                  for (int i = 0; i < session.options.length && i < kLetters.length; i++)
                    OptionTile(
                      letter: kLetters[i],
                      text: session.options[i],
                      isSelected: _selected == i,
                      onTap: _submitting ? null : () => setState(() => _selected = i),
                    ),
                ],
              ),
            ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 4, 20, 16),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (_selected == null)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Text(
                        s('quiz.select_hint'),
                        style: TextStyle(fontSize: 13, color: p.muted),
                      ),
                    ),
                  AppButton(
                    label: s('quiz.submit'),
                    icon: AppIcons.check,
                    loading: _submitting,
                    onPressed: (_selected == null || _submitting) ? null : _submit,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
