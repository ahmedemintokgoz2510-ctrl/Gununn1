import 'package:flutter/material.dart';

import '../state/app_scope.dart';
import '../state/app_state.dart';
import '../theme/app_icons.dart';
import '../theme/app_theme.dart';
import '../utils/date_utils.dart';
import '../widgets/app_card.dart';
import '../widgets/app_page.dart';
import 'account_screen.dart';
import 'achievements_screen.dart';
import 'history_screen.dart';
import 'settings_screen.dart';
import 'stats_screen.dart';
import 'unavailable_screen.dart';

class ProfileScreen extends StatelessWidget {
  final AppState state;
  const ProfileScreen({super.key, required this.state});

  void _open(BuildContext context, Widget page) {
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: state,
      builder: (context, _) {
        final s = context.s;
        final p = context.pal;
        final total = state.totalAnswered;
        final accuracy = total == 0 ? 0 : (state.totalCorrect / total * 100).round();

        final rows = <_Row>[
          _Row(AppIcons.stats, s('stats.title'), () => _open(context, StatsScreen(state: state))),
          _Row(AppIcons.history, s('profile.history'), () => _open(context, HistoryScreen(state: state))),
          _Row(AppIcons.award, s('profile.achievements'), () => _open(context, AchievementsScreen(state: state))),
          _Row(
            AppIcons.gift,
            s('profile.rewards'),
            () => _open(
              context,
              UnavailableScreen(
                title: s('profile.rewards'),
                icon: AppIcons.gift,
                heading: s('rewards.empty_title'),
                message: s('rewards.empty_msg'),
              ),
            ),
          ),
          _Row(
            AppIcons.bell,
            s('profile.notifications'),
            () => _open(
              context,
              UnavailableScreen(
                title: s('profile.notifications'),
                icon: AppIcons.bell,
                heading: s('notifications.empty_title'),
                message: s('notifications.empty_msg'),
              ),
            ),
          ),
          _Row(AppIcons.user, s('profile.account'), () => _open(context, AccountScreen(state: state))),
          _Row(AppIcons.settings, s('settings.title'), () => _open(context, SettingsScreen(state: state))),
        ];

        return AppPage(
          title: s('profile.title'),
          headerExtra: SizedBox(
            width: double.infinity,
            child: Column(
              children: [
                Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: p.gold, width: 1.5),
                  ),
                  child: Icon(AppIcons.user, size: 30, color: p.onHeader),
                ),
                const SizedBox(height: 10),
                Text(
                  state.displayName.isEmpty ? s('profile.title') : state.displayName,
                  style: AppText.serif(22, color: p.onHeader),
                ),
                const SizedBox(height: 2),
                Text(
                  state.email,
                  style: TextStyle(fontSize: 13, color: p.onHeaderMuted),
                ),
              ],
            ),
          ),
          child: ListView(
            padding: const EdgeInsets.fromLTRB(20, 24, 20, 24),
            children: [
              Row(
                children: [
                  _Tile(value: '${state.totalAnswered}', label: s('stats.answered')),
                  const SizedBox(width: 10),
                  _Tile(value: '${state.totalCorrect}', label: s('stats.correct')),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  _Tile(
                    value: formatPoints(state.totalPoints, state.language),
                    label: s('profile.points'),
                  ),
                  const SizedBox(width: 10),
                  _Tile(value: s.percent(accuracy), label: s('stats.accuracy')),
                ],
              ),
              const SizedBox(height: 20),
              AppCard(
                padding: EdgeInsets.zero,
                child: Column(
                  children: [
                    for (var i = 0; i < rows.length; i++) ...[
                      InkWell(
                        onTap: rows[i].onTap,
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
                          child: Row(
                            children: [
                              Icon(rows[i].icon, size: 20, color: p.primary),
                              const SizedBox(width: 14),
                              Expanded(
                                child: Text(
                                  rows[i].label,
                                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w500),
                                ),
                              ),
                              Icon(AppIcons.chevronRight, size: 20, color: p.muted),
                            ],
                          ),
                        ),
                      ),
                      if (i != rows.length - 1) const Divider(indent: 50),
                    ],
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _Row {
  const _Row(this.icon, this.label, this.onTap);
  final IconData icon;
  final String label;
  final VoidCallback onTap;
}

class _Tile extends StatelessWidget {
  const _Tile({required this.value, required this.label});
  final String value, label;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Expanded(
      child: AppCard(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 14),
        child: Column(
          children: [
            Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
            const SizedBox(height: 2),
            Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 12, color: p.muted),
            ),
          ],
        ),
      ),
    );
  }
}
