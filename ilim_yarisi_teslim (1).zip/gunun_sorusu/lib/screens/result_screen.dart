import 'package:flutter/material.dart';

import '../models/api_models.dart';
import '../state/app_scope.dart';
import '../state/app_state.dart';
import '../theme/app_icons.dart';
import '../theme/app_theme.dart';
import '../utils/constants.dart';
import '../utils/date_utils.dart';
import '../widgets/app_button.dart';
import '../widgets/app_card.dart';
import '../widgets/app_page.dart';

class ResultScreen extends StatelessWidget {
  final AppState state;
  final AnswerResult result;
  final bool duplicate;
  const ResultScreen({
    super.key,
    required this.state,
    required this.result,
    this.duplicate = false,
  });

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final p = context.pal;
    final r = result;
    final options = r.options;
    final correct = r.correct;
    final answer = r.selectedIndex;
    final explanation = r.explanation;
    final hasCorrectOpt = r.correctIndex >= 0 && r.correctIndex < options.length;

    return AppPage(
      title: s('home.title'),
      showBack: true,
      headerExtra: SizedBox(
        width: double.infinity,
        child: Column(
          children: [
            Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: p.gold, width: 1.5),
              ),
              child: Icon(
                correct ? AppIcons.check : AppIcons.close,
                size: 30,
                color: correct ? p.onHeader : const Color(0xFFE8A39B),
              ),
            ),
            const SizedBox(height: 12),
            Text(
              correct ? s('result.correct') : s('result.wrong'),
              style: AppText.serif(26, color: p.onHeader),
            ),
            const SizedBox(height: 4),
            Text(
              correct ? s('result.correct_sub') : s('result.wrong_sub'),
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 14, color: p.onHeaderMuted),
            ),
          ],
        ),
      ),
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 24, 20, 24),
        children: [
          if (duplicate) ...[
            AppCard(child: Text(s('quiz.duplicate'), style: TextStyle(color: p.muted))),
            const SizedBox(height: 12),
          ],
          if (!correct && answer >= 0 && answer < options.length) ...[
            _AnswerRow(
              label: s('result.your_answer'),
              letter: kLetters[answer],
              text: options[answer],
              good: false,
            ),
            const SizedBox(height: 12),
          ],
          if (hasCorrectOpt)
            _AnswerRow(
              label: s('result.correct_answer'),
              letter: kLetters[r.correctIndex],
              text: options[r.correctIndex],
              good: true,
            ),
          if (explanation.isNotEmpty) ...[
            const SizedBox(height: 12),
            AppCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    s('result.explanation'),
                    style: TextStyle(
                      fontSize: 12.5,
                      fontWeight: FontWeight.w600,
                      color: p.muted,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(explanation, style: const TextStyle(fontSize: 15, height: 1.45)),
                ],
              ),
            ),
          ],
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _Stat(
                  icon: AppIcons.award,
                  label: s('result.points'),
                  value: formatPoints(r.points, state.language),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _Stat(
                  icon: AppIcons.timer,
                  label: s('result.time'),
                  value: formatDuration(r.elapsed, millis: true),
                ),
              ),
            ],
          ),
          if (r.bonusPoints > 0) ...[
            const SizedBox(height: 8),
            Text(
              s('result.bonus_note', {'n': formatPoints(r.bonusPoints, state.language)}),
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 13, color: p.muted),
            ),
          ],
          const SizedBox(height: 12),
          FutureBuilder<Leaderboard>(
            future: state.loadLeaderboard('daily'),
            builder: (context, snap) {
              final rank = snap.data?.meRank;
              if (rank == null) return const SizedBox.shrink();
              return Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: _Stat(
                  icon: AppIcons.trophy,
                  label: s('result.daily_rank'),
                  value: '$rank',
                ),
              );
            },
          ),
          _Stat(
            icon: AppIcons.flame,
            label: s('result.streak'),
            value: s.days(state.currentStreak),
          ),
          const SizedBox(height: 12),
          Text(
            s('home.next_tomorrow'),
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 13, color: p.muted),
          ),
          const SizedBox(height: 20),
          AppButton(
            label: s('result.back_home'),
            onPressed: () => Navigator.of(context).popUntil((r) => r.isFirst),
          ),
        ],
      ),
    );
  }
}

class _AnswerRow extends StatelessWidget {
  const _AnswerRow({
    required this.label,
    required this.letter,
    required this.text,
    required this.good,
  });
  final String label, letter, text;
  final bool good;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final color = good ? p.success : p.danger;
    return AppCard(
      color: good ? p.successBg : p.dangerBg,
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            alignment: Alignment.center,
            decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(9)),
            child: Text(
              letter,
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: good ? p.successBg : p.dangerBg,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: color),
                ),
                const SizedBox(height: 2),
                Text(text, style: TextStyle(fontSize: 16, color: p.text)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  const _Stat({required this.icon, required this.label, required this.value});
  final IconData icon;
  final String label, value;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return AppCard(
      child: Row(
        children: [
          IconBadge(icon: icon, size: 36),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: TextStyle(fontSize: 12, color: p.muted)),
                Text(value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
