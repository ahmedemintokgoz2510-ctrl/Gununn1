import 'package:flutter/material.dart';

import '../services/backend.dart';
import '../state/app_scope.dart';
import '../state/app_state.dart';
import '../theme/app_icons.dart';
import '../theme/app_theme.dart';
import '../widgets/app_button.dart';
import '../widgets/app_page.dart';
import '../widgets/notice_banner.dart';
import '../widgets/password_field.dart';
import 'info_screens.dart';

String _authMessage(BuildContext context, Object e) {
  final s = context.s;
  if (e is BackendException) {
    if (e.kind == BackendError.network) return s('auth.err.network');
    switch (e.code) {
      case 'invalid-email':
      case 'email-already-in-use':
      case 'weak-password':
      case 'too-many-requests':
        return s('auth.err.${e.code}');
      case 'user-not-found':
      case 'wrong-password':
      case 'invalid-credential':
        return s('auth.err.invalid-credential');
      case 'network-request-failed':
        return s('auth.err.network');
    }
  }
  return s('auth.err.other');
}

/// Boşluk/tire/parantezleri atar; geçerliyse temiz numarayı, değilse null döndürür ('' = boş).
String? cleanPhone(String raw) {
  final p = raw.replaceAll(RegExp(r'[\s()-]'), '');
  if (p.isEmpty) return '';
  return RegExp(r'^\+?\d{10,15}$').hasMatch(p) ? p : null;
}

Widget phoneField(BuildContext context, TextEditingController c) => TextField(
      controller: c,
      keyboardType: TextInputType.phone,
      textInputAction: TextInputAction.next,
      decoration: appInput(
        context.pal,
        label: context.s('account.phone'),
        hint: '+90 5xx xxx xx xx',
      ).copyWith(
        helperText: context.s('account.phone_hint'),
        helperMaxLines: 3,
        prefixIcon: Icon(AppIcons.phone, size: 20, color: context.pal.muted),
      ),
    );

Widget _emailField(BuildContext context, TextEditingController c) => TextField(
      controller: c,
      keyboardType: TextInputType.emailAddress,
      autocorrect: false,
      textInputAction: TextInputAction.next,
      decoration: appInput(context.pal, label: context.s('auth.email')).copyWith(
        prefixIcon: Icon(AppIcons.mail, size: 20, color: context.pal.muted),
      ),
    );

Widget _nameField(BuildContext context, TextEditingController c) => TextField(
      controller: c,
      textCapitalization: TextCapitalization.words,
      textInputAction: TextInputAction.next,
      decoration: appInput(context.pal, label: context.s('auth.name')).copyWith(
        prefixIcon: Icon(AppIcons.user, size: 20, color: context.pal.muted),
      ),
    );

/// Giriş ekranı. [isRoot] true ise oturum yokken uygulamanın ana ekranıdır.
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key, this.isRoot = false});
  final bool isRoot;

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_busy) return;
    if (_email.text.trim().isEmpty || _password.text.isEmpty) {
      setState(() => _error = context.s('auth.err.empty'));
      return;
    }
    final state = context.app;
    final nav = Navigator.of(context);
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await state.signIn(_email.text, _password.text);
      nav.popUntil((r) => r.isFirst);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _busy = false;
        _error = _authMessage(context, e);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return AppPage(
      title: s('auth.welcome'),
      subtitle: s('auth.login_sub'),
      showBack: !widget.isRoot,
      child: ListView(
        keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
        padding: const EdgeInsets.fromLTRB(20, 24, 20, 24),
        children: [
          NoticeBanner(text: _error ?? s('auth.login_required')),
          const SizedBox(height: 20),
          _emailField(context, _email),
          const SizedBox(height: 12),
          PasswordField(
            label: s('auth.password'),
            action: TextInputAction.done,
            controller: _password,
          ),
          const SizedBox(height: 20),
          AppButton(
            label: s('account.login'),
            loading: _busy,
            onPressed: _busy ? null : _submit,
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              TextButton(
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(builder: (_) => const ForgotPasswordScreen()),
                ),
                child: Text(s('auth.forgot')),
              ),
              TextButton(
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(builder: (_) => const RegisterScreen()),
                ),
                child: Text(s('account.register')),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _confirm = TextEditingController();
  final _phone = TextEditingController();
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _password.dispose();
    _confirm.dispose();
    _phone.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_busy) return;
    final s = context.s;
    if (_name.text.trim().length < 2 ||
        _email.text.trim().isEmpty ||
        _password.text.isEmpty) {
      setState(() => _error = s('auth.err.empty'));
      return;
    }
    if (_password.text != _confirm.text) {
      setState(() => _error = s('auth.err.mismatch'));
      return;
    }
    final phone = cleanPhone(_phone.text);
    if (phone == null) {
      setState(() => _error = s('account.phone_invalid'));
      return;
    }
    final state = context.app;
    final nav = Navigator.of(context);
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await state.register(_name.text.trim(), _email.text, _password.text, phone: phone);
      nav.popUntil((r) => r.isFirst);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _busy = false;
        _error = _authMessage(context, e);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return AppPage(
      title: s('account.register'),
      subtitle: s('auth.register_sub'),
      showBack: true,
      child: ListView(
        keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
        padding: const EdgeInsets.fromLTRB(20, 24, 20, 24),
        children: [
          if (_error != null) ...[
            NoticeBanner(text: _error!),
            const SizedBox(height: 20),
          ],
          _nameField(context, _name),
          const SizedBox(height: 12),
          _emailField(context, _email),
          const SizedBox(height: 12),
          phoneField(context, _phone),
          const SizedBox(height: 12),
          PasswordField(label: s('auth.password'), controller: _password),
          const SizedBox(height: 12),
          PasswordField(
            label: s('auth.confirm'),
            action: TextInputAction.done,
            controller: _confirm,
          ),
          const SizedBox(height: 14),
          Text.rich(
            TextSpan(
              style: TextStyle(fontSize: 12.5, height: 1.4, color: context.pal.muted),
              children: [
                TextSpan(text: s('auth.consent_pre')),
                WidgetSpan(
                  alignment: PlaceholderAlignment.baseline,
                  baseline: TextBaseline.alphabetic,
                  child: GestureDetector(
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute<void>(builder: (_) => const KvkkScreen()),
                    ),
                    child: Text(
                      s('auth.consent_link'),
                      style: TextStyle(
                        fontSize: 12.5,
                        height: 1.4,
                        fontWeight: FontWeight.w700,
                        color: context.pal.primary,
                        decoration: TextDecoration.underline,
                      ),
                    ),
                  ),
                ),
                TextSpan(text: s('auth.consent_post')),
              ],
            ),
          ),
          const SizedBox(height: 14),
          AppButton(
            label: s('account.register'),
            loading: _busy,
            onPressed: _busy ? null : _submit,
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(s('auth.have_account'), style: TextStyle(color: context.pal.muted)),
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: Text(s('account.login')),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final _email = TextEditingController();
  bool _busy = false;
  String? _msg;

  @override
  void dispose() {
    _email.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    if (_busy) return;
    final s = context.s;
    if (_email.text.trim().isEmpty) {
      setState(() => _msg = s('auth.err.empty'));
      return;
    }
    final state = context.app;
    setState(() {
      _busy = true;
      _msg = null;
    });
    try {
      await state.resetPassword(_email.text);
      if (!mounted) return;
      setState(() {
        _busy = false;
        _msg = context.s('auth.reset_sent');
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _busy = false;
        _msg = _authMessage(context, e);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return AppPage(
      title: s('auth.forgot_title'),
      showBack: true,
      child: ListView(
        keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
        padding: const EdgeInsets.fromLTRB(20, 24, 20, 24),
        children: [
          Text(
            s('auth.forgot_sub'),
            style: TextStyle(fontSize: 15, height: 1.45, color: context.pal.muted),
          ),
          if (_msg != null) ...[
            const SizedBox(height: 16),
            NoticeBanner(text: _msg!),
          ],
          const SizedBox(height: 20),
          _emailField(context, _email),
          const SizedBox(height: 20),
          AppButton(
            label: s('auth.send_link'),
            loading: _busy,
            onPressed: _busy ? null : _send,
          ),
        ],
      ),
    );
  }
}

/// Backend ayarları olmadan derlenmiş sürümde gösterilir (sahte çalışma yok).
class BackendMissingScreen extends StatelessWidget {
  const BackendMissingScreen({super.key, required this.state});
  final AppState state;

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return AppPage(
      title: s('backend.missing_title'),
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 24, 20, 24),
        children: [NoticeBanner(text: s('backend.missing_msg'))],
      ),
    );
  }
}
