import 'package:flutter/material.dart';

import '../state/app_scope.dart';
import '../state/app_state.dart';
import '../theme/app_icons.dart';
import '../utils/constants.dart';
import '../widgets/app_card.dart';
import '../widgets/app_page.dart';
import '../widgets/confirm_dialog.dart';
import '../widgets/segmented_pills.dart';
import 'info_screens.dart';

class SettingsScreen extends StatelessWidget {
  final AppState state;
  const SettingsScreen({super.key, required this.state});

  Future<void> _confirmReset(BuildContext context) async {
    final s = context.s;
    final messenger = ScaffoldMessenger.of(context);
    final ok = await showConfirmDialog(
      context,
      title: s('settings.reset_title'),
      message: s('settings.reset_msg'),
      confirmLabel: s('settings.reset_confirm'),
      destructive: true,
    );
    if (!ok) return;
    await state.resetStatsView();
    messenger.showSnackBar(SnackBar(content: Text(s('settings.reset_done'))));
  }

  Future<void> _confirmClear(BuildContext context) async {
    final s = context.s;
    final nav = Navigator.of(context);
    final ok = await showConfirmDialog(
      context,
      title: s('settings.clear_title'),
      message: s('settings.clear_msg'),
      confirmLabel: s('settings.clear_confirm'),
      destructive: true,
    );
    if (!ok) return;
    await state.clearLocalData();
    nav.popUntil((r) => r.isFirst);
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: state,
      builder: (context, _) {
        final s = context.s;
        final p = context.pal;

        Widget section(String text) => Padding(
              padding: const EdgeInsets.only(top: 24, bottom: 8),
              child: Text(
                text,
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: p.muted),
              ),
            );

        return AppPage(
          title: s('settings.title'),
          showBack: true,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
            children: [
              section(s('settings.language')),
              SegmentedPills<String>(
                selected: state.language,
                onChanged: state.setLanguage,
                items: const [
                  PillItem(value: 'tr', label: 'Türkçe'),
                  PillItem(value: 'en', label: 'English'),
                ],
              ),
              section(s('settings.theme')),
              SegmentedPills<ThemeMode>(
                selected: state.themeMode,
                onChanged: state.setTheme,
                items: [
                  PillItem(value: ThemeMode.system, label: s('theme.system'), icon: AppIcons.phone),
                  PillItem(value: ThemeMode.light, label: s('theme.light'), icon: AppIcons.sun),
                  PillItem(value: ThemeMode.dark, label: s('theme.dark'), icon: AppIcons.moon),
                ],
              ),
              section(s('settings.data')),
              AppCard(
                onTap: () => _confirmReset(context),
                child: Row(
                  children: [
                    Icon(AppIcons.reset, size: 20, color: p.danger),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            s('settings.reset'),
                            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            s('settings.reset_desc'),
                            style: TextStyle(fontSize: 13, color: p.muted),
                          ),
                        ],
                      ),
                    ),
                    Icon(AppIcons.chevronRight, size: 20, color: p.muted),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              AppCard(
                onTap: () => _confirmClear(context),
                child: Row(
                  children: [
                    Icon(AppIcons.trash, size: 20, color: p.danger),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            s('settings.clear'),
                            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            s('settings.clear_desc'),
                            style: TextStyle(fontSize: 13, color: p.muted),
                          ),
                        ],
                      ),
                    ),
                    Icon(AppIcons.chevronRight, size: 20, color: p.muted),
                  ],
                ),
              ),
              section(s('settings.about')),
              AppCard(
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(builder: (_) => const AboutScreen()),
                ),
                child: Row(
                  children: [
                    Icon(AppIcons.info, size: 20, color: p.muted),
                    const SizedBox(width: 14),
                    const Expanded(
                      child: Text(kAppName, style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
                    ),
                    Text(
                      '${s('settings.version')} $kAppVersion',
                      style: TextStyle(fontSize: 13, color: p.muted),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
