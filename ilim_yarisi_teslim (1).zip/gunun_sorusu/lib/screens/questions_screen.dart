import 'package:flutter/material.dart';

import '../l10n/question_l10n.dart';
import '../models/api_models.dart';
import '../state/app_scope.dart';
import '../state/app_state.dart';
import '../theme/app_icons.dart';
import '../theme/app_theme.dart';
import '../utils/constants.dart';
import '../utils/date_utils.dart';
import '../widgets/app_card.dart';
import '../widgets/app_page.dart';
import '../widgets/option_tile.dart';
import '../widgets/state_views.dart';

/// Soru bankası: yalnızca yayın günü geçmiş sorular (doğru cevaplar ancak o zaman açılır).
class QuestionsScreen extends StatefulWidget {
  final AppState state;
  const QuestionsScreen({super.key, required this.state});

  @override
  State<QuestionsScreen> createState() => _QuestionsScreenState();
}

class _QuestionsScreenState extends State<QuestionsScreen> {
  late Future<List<ArchiveItem>> _future = widget.state.loadArchive();
  String _category = '';
  String _query = '';
  String _lang = '';

  void _reload() => setState(() => _future = widget.state.loadArchive());

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final p = context.pal;
    final lang = widget.state.language;
    if (_lang != lang) {
      // Dil değişince içerik yeniden (yeni dilde) alınır.
      if (_lang.isNotEmpty) _future = widget.state.loadArchive();
      _lang = lang;
    }

    return AppPage(
      title: s('questions.title'),
      child: FutureBuilder<List<ArchiveItem>>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) return ErrorState(onRetry: _reload);
          final all = snap.data ?? const <ArchiveItem>[];
          if (all.isEmpty) {
            return EmptyState(
              icon: AppIcons.questions,
              title: s('questions.empty_title'),
              message: s('questions.empty_msg'),
            );
          }
          final cats = all.map((e) => e.category).where((c) => c.isNotEmpty).toSet().toList()
            ..sort();
          final q = _query.trim().toLowerCase();
          final items = all.where((e) {
            if (_category.isNotEmpty && e.category != _category) return false;
            if (q.isEmpty) return true;
            return e.text.toLowerCase().contains(q) || e.category.toLowerCase().contains(q);
          }).toList();

          return RefreshIndicator(
            onRefresh: () async => _reload(),
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 24),
              children: [
                TextField(
                  onChanged: (v) => setState(() => _query = v),
                  decoration: appInput(p, label: s('questions.search')).copyWith(
                    prefixIcon: Icon(Icons.search, size: 20, color: p.muted),
                  ),
                ),
                if (cats.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        for (final c in ['', ...cats])
                          Padding(
                            padding: const EdgeInsets.only(right: 8),
                            child: ChoiceChip(
                              label: Text(c.isEmpty ? categoryLabel('Tümü', lang) : categoryLabel(c, lang)),
                              selected: _category == c,
                              onSelected: (_) => setState(() => _category = c),
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
                const SizedBox(height: 12),
                if (items.isEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 40),
                    child: Center(
                      child: Text(s('questions.empty_title'), style: TextStyle(color: p.muted)),
                    ),
                  ),
                for (final e in items)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: AppCard(
                      onTap: () => _showDetail(context, e),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Text(
                                formatDate(DateTime.parse(e.date), lang),
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  color: p.muted,
                                ),
                              ),
                              const Spacer(),
                              if (e.category.isNotEmpty)
                                InfoPill(text: categoryLabel(e.category, lang)),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Text(
                            e.text,
                            maxLines: 3,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 15, height: 1.35),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }

  void _showDetail(BuildContext context, ArchiveItem e) {
    final s = context.s;
    final p = context.pal;
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(e.text, style: AppText.serif(21, color: p.text, height: 1.3)),
              const SizedBox(height: 16),
              for (int i = 0; i < e.options.length && i < kLetters.length; i++)
                OptionTile(
                  letter: kLetters[i],
                  text: e.options[i],
                  revealed: e.correctIndex != null,
                  isCorrect: e.correctIndex == i,
                  isSelected: e.myAnswer == i,
                ),
              const SizedBox(height: 4),
              Text(
                e.myAnswer == null
                    ? s('questions.not_answered')
                    : '${s('questions.my_answer')}: ${kLetters[e.myAnswer!]}',
                style: TextStyle(fontSize: 13, color: p.muted),
              ),
              if (e.explanation.isNotEmpty) ...[
                const SizedBox(height: 12),
                Text(e.explanation, style: const TextStyle(fontSize: 15, height: 1.45)),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
