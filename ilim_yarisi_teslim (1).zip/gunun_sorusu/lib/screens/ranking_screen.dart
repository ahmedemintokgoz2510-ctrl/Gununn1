import 'package:flutter/material.dart';

import '../models/api_models.dart';
import '../state/app_scope.dart';
import '../state/app_state.dart';
import '../theme/app_icons.dart';
import '../utils/date_utils.dart';
import '../widgets/app_card.dart';
import '../widgets/app_page.dart';
import '../widgets/segmented_pills.dart';
import '../widgets/state_views.dart';

/// Sıralama: tüm veriler sunucudan gelir (günlük / aylık / genel).
class RankingScreen extends StatefulWidget {
  final AppState state;
  const RankingScreen({super.key, required this.state});

  @override
  State<RankingScreen> createState() => _RankingScreenState();
}

class _RankingScreenState extends State<RankingScreen> {
  String _period = 'daily';
  late Future<Leaderboard> _future = widget.state.loadLeaderboard(_period);

  void _load() => setState(() => _future = widget.state.loadLeaderboard(_period));

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final p = context.pal;
    return AppPage(
      title: s('ranking.title'),
      headerExtra: SegmentedPills<String>(
        onDark: true,
        selected: _period,
        onChanged: (v) {
          _period = v;
          _load();
        },
        items: [
          PillItem(value: 'daily', label: s('ranking.daily')),
          PillItem(value: 'monthly', label: s('ranking.monthly')),
          PillItem(value: 'all', label: s('ranking.all')),
        ],
      ),
      child: FutureBuilder<Leaderboard>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) return ErrorState(onRetry: _load);
          final board = snap.data;
          if (board == null || board.entries.isEmpty) {
            return EmptyState(
              icon: AppIcons.trophy,
              title: s('ranking.empty_title'),
              message: s('ranking.empty_msg'),
            );
          }
          final meInList = board.entries.any((e) => e.isMe);
          return RefreshIndicator(
            onRefresh: () async => _load(),
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 24),
              children: [
                for (final e in board.entries)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: _Row(entry: e),
                  ),
                if (!meInList && board.meRank != null) ...[
                  const SizedBox(height: 8),
                  _Row(
                    entry: LeaderEntry(
                      rank: board.meRank!,
                      name: s('ranking.you'),
                      points: board.mePoints ?? 0,
                      isMe: true,
                    ),
                  ),
                ],
                if (board.meRank != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 12),
                    child: Text(
                      '${s('ranking.your_rank')}: ${board.meRank}',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 13, color: p.muted),
                    ),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _Row extends StatelessWidget {
  const _Row({required this.entry});
  final LeaderEntry entry;

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final p = context.pal;
    final top = entry.rank <= 3;
    return AppCard(
      child: Row(
        children: [
          Container(
            width: top ? 38 : 32,
            height: top ? 38 : 32,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: top ? p.gold.withValues(alpha: 0.18) : p.accentSoft,
              border: top ? Border.all(color: p.gold, width: 1.5) : null,
            ),
            child: top
                ? Icon(AppIcons.award, size: 20, color: p.gold)
                : Text('${entry.rank}', style: const TextStyle(fontWeight: FontWeight.w700)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              entry.isMe ? '${entry.name} (${s('ranking.you')})' : entry.name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 15,
                fontWeight: entry.isMe || top ? FontWeight.w700 : FontWeight.w500,
              ),
            ),
          ),
          const SizedBox(width: 8),
          Text(
            s('ranking.points', {'n': formatPoints(entry.points, context.app.language)}),
            style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700, color: p.muted),
          ),
        ],
      ),
    );
  }
}
