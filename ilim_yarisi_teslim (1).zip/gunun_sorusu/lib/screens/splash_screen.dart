import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../state/app_scope.dart';
import '../theme/app_theme.dart';
import '../utils/constants.dart';
import '../widgets/app_logo.dart';
import '../widgets/geometric_pattern.dart';
import '../widgets/state_views.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key, this.failed = false, this.onRetry});
  final bool failed;
  final VoidCallback? onRetry;

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light.copyWith(statusBarColor: Colors.transparent),
      child: Scaffold(
        backgroundColor: AppColors.forestDeep,
        body: GeometricBackground(
          child: SafeArea(
            child: failed
                ? ErrorState(onDark: true, onRetry: onRetry ?? () {})
                : Center(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 32),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const AppLogo(size: 104),
                          const SizedBox(height: 24),
                          Text(
                            kAppName,
                            textAlign: TextAlign.center,
                            style: AppText.serif(40, color: AppColors.cream),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            s('app.tagline'),
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              fontSize: 15,
                              height: 1.4,
                              color: Color(0xFFB9C7BC),
                            ),
                          ),
                          const SizedBox(height: 36),
                          const SizedBox(
                            width: 22,
                            height: 22,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: AppColors.gold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
          ),
        ),
      ),
    );
  }
}
