import 'package:flutter/material.dart';

import '../state/app_scope.dart';
import '../state/app_state.dart';
import '../theme/app_icons.dart';
import 'questions_screen.dart';
import 'profile_screen.dart';
import 'ranking_screen.dart';
import 'today_screen.dart';

class HomeShell extends StatefulWidget {
  final AppState state;
  const HomeShell({super.key, required this.state});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final p = context.pal;
    return Scaffold(
      body: IndexedStack(
        index: _index,
        children: [
          TodayScreen(state: widget.state),
          QuestionsScreen(state: widget.state),
          RankingScreen(state: widget.state),
          ProfileScreen(state: widget.state),
        ],
      ),
      bottomNavigationBar: DecoratedBox(
        decoration: BoxDecoration(border: Border(top: BorderSide(color: p.line))),
        child: NavigationBar(
          selectedIndex: _index,
          onDestinationSelected: (i) => setState(() => _index = i),
          destinations: [
            NavigationDestination(icon: Icon(AppIcons.home), label: s('nav.today')),
            NavigationDestination(icon: Icon(AppIcons.questions), label: s('nav.questions')),
            NavigationDestination(icon: Icon(AppIcons.trophy), label: s('nav.ranking')),
            NavigationDestination(icon: Icon(AppIcons.user), label: s('nav.profile')),
          ],
        ),
      ),
    );
  }
}
