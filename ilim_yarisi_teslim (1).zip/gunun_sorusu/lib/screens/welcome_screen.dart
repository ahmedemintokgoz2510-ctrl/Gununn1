import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../state/app_scope.dart';
import '../state/app_state.dart';
import '../theme/app_icons.dart';
import '../theme/app_theme.dart';
import '../utils/constants.dart';
import '../widgets/app_button.dart';
import '../widgets/app_logo.dart';
import '../widgets/geometric_pattern.dart';
import '../widgets/segmented_pills.dart';

class WelcomeScreen extends StatelessWidget {
  final AppState state;
  const WelcomeScreen({super.key, required this.state});

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final points = [
      (AppIcons.calendar, s('welcome.p1')),
      (AppIcons.flame, s('welcome.p2')),
      (AppIcons.plus, s('welcome.p3')),
    ];

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light.copyWith(statusBarColor: Colors.transparent),
      child: Scaffold(
        backgroundColor: AppColors.forestDeep,
        body: GeometricBackground(
          child: SafeArea(
            child: LayoutBuilder(
              builder: (context, c) => SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
                child: ConstrainedBox(
                  constraints: BoxConstraints(minHeight: c.maxHeight - 48),
                  child: Center(
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 400),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const AppLogo(size: 96),
                          const SizedBox(height: 20),
                          Text(
                            kAppName,
                            textAlign: TextAlign.center,
                            style: AppText.serif(38, color: AppColors.cream),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            s('app.tagline'),
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              fontSize: 15,
                              height: 1.4,
                              color: Color(0xFFB9C7BC),
                            ),
                          ),
                          const SizedBox(height: 32),
                          for (final pt in points)
                            Padding(
                              padding: const EdgeInsets.only(bottom: 14),
                              child: Row(
                                children: [
                                  Icon(pt.$1, size: 20, color: AppColors.gold),
                                  const SizedBox(width: 14),
                                  Expanded(
                                    child: Text(
                                      pt.$2,
                                      style: const TextStyle(
                                        fontSize: 15,
                                        color: AppColors.cream,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          const SizedBox(height: 22),
                          Align(
                            alignment: Alignment.centerLeft,
                            child: Padding(
                              padding: const EdgeInsets.only(bottom: 8),
                              child: Text(
                                s('welcome.choose_lang'),
                                style: const TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                  color: AppColors.gold,
                                ),
                              ),
                            ),
                          ),
                          SegmentedPills<String>(
                            onDark: true,
                            selected: state.language,
                            onChanged: state.setLanguage,
                            items: const [
                              PillItem(value: 'tr', label: 'Türkçe'),
                              PillItem(value: 'en', label: 'English'),
                            ],
                          ),
                          const SizedBox(height: 24),
                          AppButton(
                            label: s('welcome.start'),
                            icon: AppIcons.arrowRight,
                            trailingIcon: true,
                            style: AppButtonStyle.gold,
                            onPressed: state.completeWelcome,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
