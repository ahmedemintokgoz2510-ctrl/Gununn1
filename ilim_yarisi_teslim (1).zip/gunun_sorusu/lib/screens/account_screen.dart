import 'package:flutter/material.dart';

import '../state/app_scope.dart';
import '../state/app_state.dart';
import '../theme/app_icons.dart';
import '../theme/app_theme.dart';
import '../widgets/app_button.dart';
import '../widgets/app_card.dart';
import '../widgets/app_page.dart';
import 'auth_screens.dart';

class AccountScreen extends StatefulWidget {
  final AppState state;
  const AccountScreen({super.key, required this.state});

  @override
  State<AccountScreen> createState() => _AccountScreenState();
}

class _AccountScreenState extends State<AccountScreen> {
  late final TextEditingController _name =
      TextEditingController(text: widget.state.displayName);
  late final TextEditingController _phone =
      TextEditingController(text: widget.state.phone);
  bool _saving = false;

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    super.dispose();
  }

  Future<void> _saveName() async {
    final s = context.s;
    final messenger = ScaffoldMessenger.of(context);
    final name = _name.text.trim();
    if (name.length < 2 || name.length > 24 || _saving) return;
    final phone = cleanPhone(_phone.text);
    if (phone == null) {
      messenger.showSnackBar(SnackBar(content: Text(s('account.phone_invalid'))));
      return;
    }
    setState(() => _saving = true);
    try {
      await widget.state.updateDisplayName(name, phone: phone);
      messenger.showSnackBar(SnackBar(content: Text(s('account.name_saved'))));
    } catch (_) {
      messenger.showSnackBar(SnackBar(content: Text(s('auth.err.other'))));
    }
    if (mounted) setState(() => _saving = false);
  }

  Future<void> _logout() async {
    final nav = Navigator.of(context);
    await widget.state.signOut();
    nav.popUntil((r) => r.isFirst);
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final p = context.pal;
    return AppPage(
      title: s('account.title'),
      showBack: true,
      child: ListView(
        keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
        padding: const EdgeInsets.fromLTRB(20, 24, 20, 24),
        children: [
          AppCard(
            child: Row(
              children: [
                IconBadge(icon: AppIcons.user),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        s('account.email'),
                        style: TextStyle(fontSize: 12.5, color: p.muted),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        widget.state.email,
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          TextField(
            controller: _name,
            maxLength: 24,
            textCapitalization: TextCapitalization.words,
            decoration: appInput(p, label: s('account.name')),
          ),
          const SizedBox(height: 4),
          phoneField(context, _phone),
          const SizedBox(height: 12),
          AppButton(
            label: s('account.save'),
            style: AppButtonStyle.outline,
            loading: _saving,
            onPressed: _saving ? null : _saveName,
          ),
          const SizedBox(height: 24),
          AppCard(
            onTap: _logout,
            child: Row(
              children: [
                Icon(AppIcons.logOut, size: 20, color: p.danger),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        s('account.logout'),
                        style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        s('account.logout_desc'),
                        style: TextStyle(fontSize: 13, color: p.muted),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
