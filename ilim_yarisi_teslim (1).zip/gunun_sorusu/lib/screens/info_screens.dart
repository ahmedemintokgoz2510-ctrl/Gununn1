import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../state/app_scope.dart';
import '../theme/app_theme.dart';
import '../utils/constants.dart';
import '../widgets/app_card.dart';
import '../widgets/app_page.dart';

const List<String> kCredits = [
  'Muhammed Tosun',
  'Ahmed Emin Tokgöz',
  'Melih Güney',
  'Süleyman Berat Ünal',
  'Hüseyin Emir Cücioğlu',
  'Muhammed Eymen Sarıoğlu',
  'Osman Nuri Üğüden',
];

const String kInstagramUrl =
    'https://www.instagram.com/seyri.hakikatt?dmpr=MXg1NmU5b3lsZXA2bw==';
const String kWhatsappUrl = 'https://whatsapp.com/channel/0029Vb8fS8W4NVig2OrUHh1I';

Future<void> _openLink(BuildContext context, String url) async {
  final messenger = ScaffoldMessenger.of(context);
  final failed = context.s('about.open_failed');
  var ok = false;
  try {
    ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  } catch (_) {
    ok = false;
  }
  if (!ok) messenger.showSnackBar(SnackBar(content: Text(failed)));
}

Widget _heading(BuildContext context, String text) => Padding(
      padding: const EdgeInsets.only(top: 24, bottom: 8),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 13,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.4,
          color: context.pal.muted,
        ),
      ),
    );

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final p = context.pal;

    Widget linkTile(IconData icon, String title, VoidCallback onTap) => Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: AppCard(
            onTap: onTap,
            child: Row(
              children: [
                Icon(icon, size: 20, color: p.primary),
                const SizedBox(width: 14),
                Expanded(
                  child: Text(
                    title,
                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
                  ),
                ),
                Icon(Icons.chevron_right, size: 20, color: p.muted),
              ],
            ),
          ),
        );

    return AppPage(
      title: s('about.title'),
      subtitle: '$kAppName · ${s('about.version')} $kAppVersion',
      showBack: true,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
        children: [
          _heading(context, s('about.mission_title').toUpperCase()),
          AppCard(
            child: Text(s('about.mission'), style: const TextStyle(fontSize: 15, height: 1.5)),
          ),
          _heading(context, s('about.founder_title').toUpperCase()),
          AppCard(
            child: Text(
              s('about.founder'),
              style: AppText.serif(20, color: p.text),
            ),
          ),
          _heading(context, s('about.credits_title').toUpperCase()),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                for (final name in kCredits)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Text(name, style: const TextStyle(fontSize: 15)),
                  ),
              ],
            ),
          ),
          _heading(context, s('about.social_title').toUpperCase()),
          linkTile(
            Icons.camera_alt_outlined,
            s('about.instagram'),
            () => _openLink(context, kInstagramUrl),
          ),
          linkTile(
            Icons.chat_outlined,
            s('about.whatsapp'),
            () => _openLink(context, kWhatsappUrl),
          ),
          _heading(context, s('about.legal_title').toUpperCase()),
          linkTile(
            Icons.privacy_tip_outlined,
            s('about.kvkk'),
            () => Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => const KvkkScreen()),
            ),
          ),
          linkTile(
            Icons.rule_outlined,
            s('about.rules'),
            () => Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => const RulesScreen()),
            ),
          ),
        ],
      ),
    );
  }
}

class _TextSections extends StatelessWidget {
  const _TextSections({required this.title, required this.prefix, required this.count});
  final String title;
  final String prefix;
  final int count;

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return AppPage(
      title: title,
      showBack: true,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
        children: [
          for (var i = 1; i <= count; i++) ...[
            _heading(context, s('$prefix.s$i.t').toUpperCase()),
            AppCard(
              child: Text(
                s('$prefix.s$i.b'),
                style: const TextStyle(fontSize: 15, height: 1.5),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class KvkkScreen extends StatelessWidget {
  const KvkkScreen({super.key});

  @override
  Widget build(BuildContext context) =>
      _TextSections(title: context.s('kvkk.title'), prefix: 'kvkk', count: 7);
}

class RulesScreen extends StatelessWidget {
  const RulesScreen({super.key});

  @override
  Widget build(BuildContext context) =>
      _TextSections(title: context.s('rules.title'), prefix: 'rules', count: 4);
}
