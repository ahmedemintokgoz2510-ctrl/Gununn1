import 'package:flutter/material.dart';

import 'screens/auth_screens.dart';
import 'screens/home_shell.dart';
import 'screens/splash_screen.dart';
import 'screens/welcome_screen.dart';
import 'services/backend.dart';
import 'state/app_scope.dart';
import 'state/app_state.dart';
import 'theme/app_theme.dart';
import 'utils/constants.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const GununApp());
}

class GununApp extends StatefulWidget {
  const GununApp({super.key});

  @override
  State<GununApp> createState() => _GununAppState();
}

class _GununAppState extends State<GununApp> {
  final AppState _state = AppState(Backend());
  bool _ready = false;
  Object? _error;

  @override
  void initState() {
    super.initState();
    _start();
  }

  Future<void> _start() async {
    try {
      await Future.wait([
        _state.load(),
        Future<void>.delayed(const Duration(milliseconds: 900)),
      ]);
      if (!mounted) return;
      setState(() => _ready = true);
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = e);
    }
  }

  void _retry() {
    setState(() => _error = null);
    _start();
  }

  Widget _home() {
    if (_error != null) return SplashScreen(failed: true, onRetry: _retry);
    if (!_ready) return const SplashScreen();
    if (!_state.welcomeSeen) return WelcomeScreen(state: _state);
    switch (_state.authStatus) {
      case AuthStatus.unconfigured:
        return BackendMissingScreen(state: _state);
      case AuthStatus.signedOut:
        return const LoginScreen(isRoot: true);
      case AuthStatus.signedIn:
        return HomeShell(state: _state);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppScope(
      state: _state,
      child: ListenableBuilder(
        listenable: _state,
        builder: (context, _) => MaterialApp(
          title: kAppName,
          debugShowCheckedModeBanner: false,
          theme: buildTheme(Brightness.light),
          darkTheme: buildTheme(Brightness.dark),
          themeMode: _state.themeMode,
          // Geçişlerde ve ilk karede beyaz görünmesin diye sabit zemin.
          builder: (context, child) => ColoredBox(
            color: Theme.of(context).scaffoldBackgroundColor,
            child: child,
          ),
          home: AnimatedSwitcher(
            duration: const Duration(milliseconds: 250),
            child: KeyedSubtree(
              key: ValueKey<Object>('${_ready}_${_error != null}_${_state.welcomeSeen}_${_state.authStatus}'),
              child: _home(),
            ),
          ),
        ),
      ),
    );
  }
}
