/// Firebase yapılandırması derleme sırasında --dart-define ile verilir.
/// Gizli anahtar içermez (Firebase web/android API anahtarları istemci kimliğidir;
/// asıl güvenlik Firestore kuralları ve Cloud Functions'tadır).
const String kFirebaseApiKey = String.fromEnvironment('FIREBASE_API_KEY');
const String kFirebaseAppId = String.fromEnvironment('FIREBASE_APP_ID');
const String kFirebaseProjectId = String.fromEnvironment('FIREBASE_PROJECT_ID');
const String kFirebaseSenderId = String.fromEnvironment('FIREBASE_SENDER_ID');
const String kFunctionsRegion = 'europe-west1';

bool get kBackendConfigured =>
    kFirebaseApiKey.isNotEmpty &&
    kFirebaseAppId.isNotEmpty &&
    kFirebaseProjectId.isNotEmpty &&
    kFirebaseSenderId.isNotEmpty;
