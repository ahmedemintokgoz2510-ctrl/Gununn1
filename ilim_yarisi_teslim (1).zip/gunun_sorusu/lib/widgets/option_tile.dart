import 'package:flutter/material.dart';

import '../state/app_scope.dart';
import '../theme/app_icons.dart';

class OptionTile extends StatelessWidget {
  final String letter;
  final String text;
  final bool revealed;
  final bool isCorrect;
  final bool isSelected;
  final VoidCallback? onTap;

  const OptionTile({
    super.key,
    required this.letter,
    required this.text,
    this.revealed = false,
    this.isCorrect = false,
    this.isSelected = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    Color bg = p.card;
    Color border = p.line;
    double bw = 1;
    Color badgeBg = p.bg;
    Color badgeFg = p.muted;
    IconData? icon;

    if (revealed && isCorrect) {
      bg = p.successBg;
      border = p.success;
      bw = 1.5;
      badgeBg = p.success;
      badgeFg = p.successBg;
      icon = AppIcons.check;
    } else if (revealed && isSelected) {
      bg = p.dangerBg;
      border = p.danger;
      bw = 1.5;
      badgeBg = p.danger;
      badgeFg = p.dangerBg;
      icon = AppIcons.close;
    } else if (!revealed && isSelected) {
      bg = p.accentSoft;
      border = p.primary;
      bw = 1.5;
      badgeBg = p.primary;
      badgeFg = p.onPrimary;
    }

    final radius = BorderRadius.circular(14);
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Semantics(
        button: onTap != null,
        selected: isSelected,
        child: Material(
          color: bg,
          shape: RoundedRectangleBorder(
            borderRadius: radius,
            side: BorderSide(color: border, width: bw),
          ),
          child: InkWell(
            borderRadius: radius,
            onTap: onTap,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              child: Row(
                children: [
                  Container(
                    width: 32,
                    height: 32,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: badgeBg,
                      borderRadius: BorderRadius.circular(9),
                    ),
                    child: Text(
                      letter,
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: badgeFg,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      text,
                      style: TextStyle(fontSize: 16, height: 1.3, color: p.text),
                    ),
                  ),
                  if (icon != null) ...[
                    const SizedBox(width: 8),
                    Icon(icon, color: border, size: 22),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
