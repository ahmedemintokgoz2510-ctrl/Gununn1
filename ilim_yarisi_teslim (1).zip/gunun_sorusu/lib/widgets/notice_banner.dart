import 'package:flutter/material.dart';

import '../state/app_scope.dart';
import '../theme/app_icons.dart';

class NoticeBanner extends StatelessWidget {
  const NoticeBanner({super.key, required this.text});
  final String text;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.accentSoft,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(AppIcons.info, size: 18, color: p.primary),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              text,
              style: TextStyle(fontSize: 13.5, height: 1.4, color: p.text),
            ),
          ),
        ],
      ),
    );
  }
}
