import 'dart:math' as math;

import 'package:flutter/material.dart';

/// Çok hafif, sekiz köşeli yıldız (iki üst üste kare) deseni.
class GeometricPainter extends CustomPainter {
  GeometricPainter({required this.color, this.cell = 48});
  final Color color;
  final double cell;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;
    final r = cell * 0.36;
    var row = 0;
    for (double y = 0; y < size.height + cell; y += cell) {
      final shift = row.isOdd ? cell / 2 : 0.0;
      for (double x = -cell; x < size.width + cell; x += cell) {
        _star(canvas, Offset(x + shift, y), r, paint);
      }
      row++;
    }
  }

  void _star(Canvas canvas, Offset c, double r, Paint paint) {
    for (final rot in [0.0, math.pi / 4]) {
      final path = Path();
      for (var i = 0; i < 4; i++) {
        final a = rot + i * math.pi / 2 + math.pi / 4;
        final pt = Offset(c.dx + math.cos(a) * r, c.dy + math.sin(a) * r);
        if (i == 0) {
          path.moveTo(pt.dx, pt.dy);
        } else {
          path.lineTo(pt.dx, pt.dy);
        }
      }
      path.close();
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(GeometricPainter old) =>
      old.color != color || old.cell != cell;
}

class GeometricBackground extends StatelessWidget {
  const GeometricBackground({super.key, required this.child, this.color});
  final Widget child;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Positioned.fill(
          child: IgnorePointer(
            child: CustomPaint(
              painter: GeometricPainter(
                color: (color ?? const Color(0xFFC4A04D)).withValues(alpha: 0.09),
              ),
            ),
          ),
        ),
        child,
      ],
    );
  }
}
