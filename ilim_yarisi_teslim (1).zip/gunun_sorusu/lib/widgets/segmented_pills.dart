import 'package:flutter/material.dart';

import '../state/app_scope.dart';
import '../theme/app_theme.dart';

class PillItem<T> {
  const PillItem({required this.value, required this.label, this.icon});
  final T value;
  final String label;
  final IconData? icon;
}

class SegmentedPills<T> extends StatelessWidget {
  const SegmentedPills({
    super.key,
    required this.items,
    required this.selected,
    required this.onChanged,
    this.onDark = false,
  });

  final List<PillItem<T>> items;
  final T selected;
  final ValueChanged<T> onChanged;
  final bool onDark;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final trackBg = onDark ? Colors.white.withValues(alpha: 0.06) : p.card;
    final trackLine = onDark ? AppColors.gold.withValues(alpha: 0.35) : p.line;
    final selBg = onDark ? AppColors.gold : p.primary;
    final selFg = onDark ? AppColors.forestDeep : p.onPrimary;
    final idleFg = onDark ? AppColors.cream : p.text;

    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: trackBg,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: trackLine),
      ),
      child: Row(
        children: [
          for (final it in items)
            Expanded(
              child: Semantics(
                button: true,
                selected: it.value == selected,
                child: Material(
                  color: it.value == selected ? selBg : Colors.transparent,
                  borderRadius: BorderRadius.circular(10),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(10),
                    onTap: () => onChanged(it.value),
                    child: Container(
                      height: 44,
                      alignment: Alignment.center,
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          if (it.icon != null) ...[
                            Icon(it.icon, size: 16, color: it.value == selected ? selFg : idleFg),
                            const SizedBox(width: 6),
                          ],
                          Flexible(
                            child: Text(
                              it.label,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                color: it.value == selected ? selFg : idleFg,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
