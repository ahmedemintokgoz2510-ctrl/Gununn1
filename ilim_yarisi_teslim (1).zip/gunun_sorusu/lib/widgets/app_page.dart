import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../state/app_scope.dart';
import '../theme/app_icons.dart';
import '../theme/app_theme.dart';
import 'geometric_pattern.dart';

/// Yeşil başlık + krem gövde: tüm iç ekranların ortak iskeleti.
class AppPage extends StatelessWidget {
  const AppPage({
    super.key,
    required this.title,
    required this.child,
    this.subtitle,
    this.showBack = false,
    this.trailing,
    this.headerExtra,
    this.floatingActionButton,
  });

  final String title;
  final String? subtitle;
  final bool showBack;
  final Widget? trailing;
  final Widget? headerExtra;
  final Widget? floatingActionButton;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light.copyWith(statusBarColor: Colors.transparent),
      child: Scaffold(
        backgroundColor: p.header,
        floatingActionButton: floatingActionButton,
        body: Column(
          children: [
            ClipRect(
              child: Stack(
                children: [
                  Positioned.fill(
                    child: IgnorePointer(
                      child: CustomPaint(
                        painter: GeometricPainter(
                          color: p.gold.withValues(alpha: 0.10),
                          cell: 48,
                        ),
                      ),
                    ),
                  ),
                  SafeArea(
                    bottom: false,
                    child: Padding(
                      padding: EdgeInsets.fromLTRB(showBack ? 4 : 20, 8, 16, 28),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              if (showBack)
                                IconButton(
                                  icon: Icon(AppIcons.back, color: p.onHeader),
                                  tooltip: MaterialLocalizations.of(context).backButtonTooltip,
                                  onPressed: () => Navigator.of(context).maybePop(),
                                ),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      title,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: AppText.serif(22, color: p.onHeader),
                                    ),
                                    if (subtitle != null)
                                      Padding(
                                        padding: const EdgeInsets.only(top: 2),
                                        child: Text(
                                          subtitle!,
                                          style: TextStyle(fontSize: 13, color: p.onHeaderMuted),
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                              if (trailing != null) trailing!,
                            ],
                          ),
                          if (headerExtra != null)
                            Padding(
                              padding: EdgeInsets.only(top: 16, left: showBack ? 16 : 0),
                              child: headerExtra!,
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Container(
                width: double.infinity,
                clipBehavior: Clip.antiAlias,
                decoration: BoxDecoration(
                  color: p.bg,
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
                ),
                child: Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 640),
                    child: SizedBox.expand(child: child),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
