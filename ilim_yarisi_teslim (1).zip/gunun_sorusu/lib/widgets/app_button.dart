import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

enum AppButtonStyle { primary, gold, outline, outlineLight }

class AppButton extends StatelessWidget {
  const AppButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
    this.trailingIcon = false,
    this.style = AppButtonStyle.primary,
    this.loading = false,
  });

  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final bool trailingIcon;
  final AppButtonStyle style;
  final bool loading;

  @override
  Widget build(BuildContext context) {
    final iconWidget = icon == null ? null : Icon(icon, size: 18);
    final content = Row(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        if (loading)
          const SizedBox(
            width: 18,
            height: 18,
            child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white70),
          )
        else if (iconWidget != null && !trailingIcon) ...[
          iconWidget,
          const SizedBox(width: 8),
        ],
        Flexible(child: Text(label, textAlign: TextAlign.center)),
        if (!loading && iconWidget != null && trailingIcon) ...[
          const SizedBox(width: 8),
          iconWidget,
        ],
      ],
    );

    switch (style) {
      case AppButtonStyle.primary:
        return FilledButton(onPressed: onPressed, child: content);
      case AppButtonStyle.gold:
        return FilledButton(
          onPressed: onPressed,
          style: FilledButton.styleFrom(
            backgroundColor: AppColors.gold,
            foregroundColor: AppColors.forestDeep,
          ),
          child: content,
        );
      case AppButtonStyle.outline:
        return OutlinedButton(onPressed: onPressed, child: content);
      case AppButtonStyle.outlineLight:
        return OutlinedButton(
          onPressed: onPressed,
          style: OutlinedButton.styleFrom(
            foregroundColor: AppColors.cream,
            side: BorderSide(color: AppColors.gold.withValues(alpha: 0.7)),
          ),
          child: content,
        );
    }
  }
}
