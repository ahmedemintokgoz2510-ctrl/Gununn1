import 'package:flutter/material.dart';

import '../state/app_scope.dart';

class AppCard extends StatelessWidget {
  const AppCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.onTap,
    this.color,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final inner = Padding(padding: padding, child: child);
    return Material(
      color: color ?? p.card,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: p.line),
      ),
      child: onTap == null ? inner : InkWell(onTap: onTap, child: inner),
    );
  }
}

class IconBadge extends StatelessWidget {
  const IconBadge({super.key, required this.icon, this.size = 44, this.bg, this.color});
  final IconData icon;
  final double size;
  final Color? bg;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(color: bg ?? p.accentSoft, shape: BoxShape.circle),
      child: Icon(icon, size: size * 0.48, color: color ?? p.primary),
    );
  }
}

class InfoPill extends StatelessWidget {
  const InfoPill({super.key, required this.text});
  final String text;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: p.bg,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: p.line),
      ),
      child: Text(
        text,
        style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: p.muted),
      ),
    );
  }
}
