import 'package:flutter/material.dart';

import '../state/app_scope.dart';
import '../theme/app_icons.dart';
import '../theme/app_theme.dart';
import 'app_button.dart';
import 'app_card.dart';

class EmptyState extends StatelessWidget {
  const EmptyState({
    super.key,
    required this.icon,
    required this.title,
    this.message,
    this.action,
    this.onDark = false,
  });

  final IconData icon;
  final String title;
  final String? message;
  final Widget? action;
  final bool onDark;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final fg = onDark ? AppColors.cream : p.text;
    final muted = onDark ? const Color(0xFFB9C7BC) : p.muted;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconBadge(
              icon: icon,
              size: 56,
              bg: onDark ? Colors.white.withValues(alpha: 0.08) : null,
              color: onDark ? AppColors.gold : null,
            ),
            const SizedBox(height: 16),
            Text(
              title,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: fg),
            ),
            if (message != null) ...[
              const SizedBox(height: 8),
              Text(
                message!,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 14, height: 1.4, color: muted),
              ),
            ],
            if (action != null) ...[const SizedBox(height: 20), action!],
          ],
        ),
      ),
    );
  }
}

class ErrorState extends StatelessWidget {
  const ErrorState({super.key, required this.onRetry, this.onDark = false});
  final VoidCallback onRetry;
  final bool onDark;

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return EmptyState(
      icon: AppIcons.info,
      title: s('splash.error_title'),
      message: s('splash.error_msg'),
      onDark: onDark,
      action: SizedBox(
        width: 200,
        child: AppButton(
          label: s('common.retry'),
          icon: AppIcons.refresh,
          onPressed: onRetry,
          style: onDark ? AppButtonStyle.gold : AppButtonStyle.primary,
        ),
      ),
    );
  }
}
