import 'package:flutter/material.dart';

/// Tüm ikonlar tek yerden gelir. Şimdilik Flutter'ın yerleşik çizgi ikonları
/// kullanılıyor (ek paket yok). Lucide'e geçmek için yalnızca bu dosya değişir.
class AppIcons {
  AppIcons._();
  static const IconData home = Icons.home_outlined;
  static const IconData questions = Icons.menu_book_outlined;
  static const IconData stats = Icons.trending_up;
  static const IconData settings = Icons.settings_outlined;
  static const IconData flame = Icons.local_fire_department_outlined;
  static const IconData check = Icons.check;
  static const IconData close = Icons.close;
  static const IconData chevronRight = Icons.chevron_right;
  static const IconData back = Icons.chevron_left;
  static const IconData arrowRight = Icons.arrow_forward;
  static const IconData plus = Icons.add;
  static const IconData trash = Icons.delete_outline;
  static const IconData timer = Icons.timer_outlined;
  static const IconData globe = Icons.language;
  static const IconData sun = Icons.light_mode_outlined;
  static const IconData moon = Icons.dark_mode_outlined;
  static const IconData phone = Icons.smartphone;
  static const IconData reset = Icons.restart_alt;
  static const IconData star = Icons.star_outline;
  static const IconData info = Icons.info_outline;
  static const IconData target = Icons.track_changes;
  static const IconData calendar = Icons.calendar_today_outlined;
  static const IconData inbox = Icons.inbox_outlined;
  static const IconData refresh = Icons.refresh;
  static const IconData award = Icons.workspace_premium_outlined;
  static const IconData user = Icons.person_outline;
  static const IconData mail = Icons.mail_outline;
  static const IconData lock = Icons.lock_outline;
  static const IconData eye = Icons.visibility_outlined;
  static const IconData eyeOff = Icons.visibility_off_outlined;
  static const IconData bell = Icons.notifications_none;
  static const IconData gift = Icons.card_giftcard;
  static const IconData history = Icons.history;
  static const IconData logOut = Icons.logout;
  static const IconData trophy = Icons.emoji_events_outlined;
}
