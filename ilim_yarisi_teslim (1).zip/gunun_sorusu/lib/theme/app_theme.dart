import 'package:flutter/material.dart';

class AppColors {
  AppColors._();
  static const forestDeep = Color(0xFF082A1F);
  static const forest = Color(0xFF0F3D2E);
  static const cream = Color(0xFFF5EEDD);
  static const creamCard = Color(0xFFFBF8EF);
  static const creamLine = Color(0xFFE4DAC0);
  static const gold = Color(0xFFC4A04D);
  static const goldSoft = Color(0xFFEBDFB6);
  static const ink = Color(0xFF1B2B24);
  static const inkMuted = Color(0xFF5F6C64);
}

/// Açık/koyu temaya göre anlamsal renk paleti.
@immutable
class Pal {
  const Pal({
    required this.header,
    required this.onHeader,
    required this.onHeaderMuted,
    required this.bg,
    required this.card,
    required this.line,
    required this.text,
    required this.muted,
    required this.primary,
    required this.onPrimary,
    required this.gold,
    required this.accentSoft,
    required this.success,
    required this.successBg,
    required this.danger,
    required this.dangerBg,
  });

  final Color header, onHeader, onHeaderMuted;
  final Color bg, card, line, text, muted;
  final Color primary, onPrimary, gold, accentSoft;
  final Color success, successBg, danger, dangerBg;

  static const light = Pal(
    header: AppColors.forest,
    onHeader: AppColors.cream,
    onHeaderMuted: Color(0xFFB9C7BC),
    bg: AppColors.cream,
    card: AppColors.creamCard,
    line: AppColors.creamLine,
    text: AppColors.ink,
    muted: AppColors.inkMuted,
    primary: AppColors.forest,
    onPrimary: AppColors.cream,
    gold: AppColors.gold,
    accentSoft: AppColors.goldSoft,
    success: Color(0xFF2E7D55),
    successBg: Color(0xFFE2EFE4),
    danger: Color(0xFFA5433B),
    dangerBg: Color(0xFFF4E0DC),
  );

  static const dark = Pal(
    header: Color(0xFF071F17),
    onHeader: AppColors.cream,
    onHeaderMuted: Color(0xFF9FB1A5),
    bg: Color(0xFF0E2A20),
    card: Color(0xFF153A2D),
    line: Color(0xFF26493B),
    text: Color(0xFFEFE8D6),
    muted: Color(0xFFA3B4A9),
    primary: AppColors.gold,
    onPrimary: AppColors.forestDeep,
    gold: AppColors.gold,
    accentSoft: Color(0xFF24493A),
    success: Color(0xFF6CC08F),
    successBg: Color(0xFF1C4A38),
    danger: Color(0xFFE08A80),
    dangerBg: Color(0xFF4A2A27),
  );
}

class AppText {
  AppText._();
  static TextStyle serif(double size,
          {FontWeight weight = FontWeight.w600, Color? color, double? height}) =>
      TextStyle(
        fontFamily: 'serif',
        fontSize: size,
        fontWeight: weight,
        color: color,
        height: height,
      );
}

InputDecoration appInput(Pal p, {required String label, String? hint}) {
  OutlineInputBorder b(Color c, [double w = 1]) => OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: c, width: w),
      );
  return InputDecoration(
    labelText: label,
    hintText: hint,
    filled: true,
    fillColor: p.card,
    labelStyle: TextStyle(color: p.muted),
    hintStyle: TextStyle(color: p.muted.withValues(alpha: 0.7)),
    floatingLabelStyle: TextStyle(color: p.primary),
    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
    border: b(p.line),
    enabledBorder: b(p.line),
    focusedBorder: b(p.primary, 1.6),
    errorBorder: b(p.danger),
    focusedErrorBorder: b(p.danger, 1.6),
    errorStyle: TextStyle(color: p.danger),
  );
}

ThemeData buildTheme(Brightness brightness) {
  final dark = brightness == Brightness.dark;
  final p = dark ? Pal.dark : Pal.light;
  final base = ThemeData(brightness: brightness, useMaterial3: true);
  final scheme = ColorScheme(
    brightness: brightness,
    primary: p.primary,
    onPrimary: p.onPrimary,
    secondary: p.gold,
    onSecondary: AppColors.forestDeep,
    error: p.danger,
    onError: dark ? AppColors.forestDeep : Colors.white,
    surface: p.bg,
    onSurface: p.text,
    outline: p.line,
    outlineVariant: p.line,
  );
  final shape = RoundedRectangleBorder(borderRadius: BorderRadius.circular(14));

  return base.copyWith(
    colorScheme: scheme,
    scaffoldBackgroundColor: p.bg,
    canvasColor: p.bg,
    // Sayfa geçişlerinde beyaz flaş olmasın: yumuşak solma geçişi, arka plan sabit.
    pageTransitionsTheme: const PageTransitionsTheme(
      builders: {
        TargetPlatform.android: FadeUpwardsPageTransitionsBuilder(),
        TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
      },
    ),
    textTheme: base.textTheme.apply(bodyColor: p.text, displayColor: p.text),
    splashFactory: InkRipple.splashFactory,
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: p.primary,
        foregroundColor: p.onPrimary,
        disabledBackgroundColor: p.line,
        disabledForegroundColor: p.muted,
        minimumSize: const Size.fromHeight(52),
        shape: shape,
        textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: p.primary,
        minimumSize: const Size.fromHeight(52),
        shape: shape,
        side: BorderSide(color: p.primary, width: 1.2),
        textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(foregroundColor: p.primary),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: p.card,
      surfaceTintColor: Colors.transparent,
      indicatorColor: p.accentSoft,
      elevation: 0,
      height: 68,
      iconTheme: WidgetStateProperty.resolveWith((states) => IconThemeData(
            size: 22,
            color: states.contains(WidgetState.selected) ? p.primary : p.muted,
          )),
      labelTextStyle: WidgetStateProperty.resolveWith((states) {
        final sel = states.contains(WidgetState.selected);
        return TextStyle(
          fontSize: 11.5,
          fontWeight: sel ? FontWeight.w700 : FontWeight.w500,
          color: sel ? p.primary : p.muted,
        );
      }),
    ),
    floatingActionButtonTheme: FloatingActionButtonThemeData(
      backgroundColor: AppColors.gold,
      foregroundColor: AppColors.forestDeep,
      elevation: 1,
      highlightElevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      backgroundColor: dark ? AppColors.forest : AppColors.forestDeep,
      contentTextStyle: const TextStyle(color: AppColors.cream),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ),
    bottomSheetTheme: BottomSheetThemeData(
      backgroundColor: p.bg,
      surfaceTintColor: Colors.transparent,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
    ),
    progressIndicatorTheme: ProgressIndicatorThemeData(
      color: p.primary,
      linearTrackColor: p.line,
    ),
    dividerTheme: DividerThemeData(color: p.line, thickness: 1, space: 1),
  );
}
