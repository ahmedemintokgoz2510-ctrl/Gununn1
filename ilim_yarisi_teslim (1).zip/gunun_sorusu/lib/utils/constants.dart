const String kAppName = 'İlim Yarışı';
const String kAppVersion = '1.0.0';
const List<String> kLetters = ['A', 'B', 'C', 'D', 'E', 'F'];
