'use strict';
const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { onSchedule } = require('firebase-functions/v2/scheduler');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');
const core = require('./core');

initializeApp();
const db = getFirestore();

const REGION = 'europe-west1';
const OPTS = { region: REGION, maxInstances: 20 };

// ---------------------------------------------------------------- yardımcılar

function authUid(req) {
  if (!req.auth || !req.auth.uid) {
    throw new HttpsError('unauthenticated', 'auth-required');
  }
  return req.auth.uid;
}

function langOf(req) {
  return req.data && req.data.lang === 'en' ? 'en' : 'tr';
}

function defaultName(uid) {
  return `Katılımcı ${uid.slice(-4).toUpperCase()}`;
}

async function ensureUser(req) {
  const uid = authUid(req);
  const ref = db.doc(`users/${uid}`);
  const email = (req.auth.token && req.auth.token.email) || '';
  const snap = await ref.get();
  if (snap.exists) {
    // E-posta yönetici panelinde iletişim için gösterilir; eksik/değişmişse güncelle.
    if (email && snap.data().email !== email) {
      await ref.update({ email });
      return { uid, user: { ...snap.data(), email } };
    }
    return { uid, user: snap.data() };
  }
  const user = {
    email,
    phone: '',
    displayName: defaultName(uid),
    createdAt: FieldValue.serverTimestamp(),
    totalAnswered: 0,
    totalCorrect: 0,
    totalPoints: 0,
    streak: 0,
    bestStreak: 0,
    lastDate: '',
  };
  try {
    await ref.create(user);
  } catch (e) {
    // eşzamanlı ilk çağrı: zaten oluşturulmuş olabilir
  }
  const again = await ref.get();
  return { uid, user: again.data() };
}

/** Bugünün (veya verilen tarihin) yayınını, zamanı geldiyse oluşturur. */
async function materialize(date, nowDate) {
  const dref = db.doc(`daily/${date}`);
  const pre = await dref.get();
  if (pre.exists) return pre.data();
  const sref = db.doc(`schedule/${date}`);
  return db.runTransaction(async (tx) => {
    const d = await tx.get(dref);
    if (d.exists) return d.data();
    const s = await tx.get(sref);
    if (!s.exists) return null;
    const sd = s.data();
    const p = core.istanbulParts(nowDate);
    const publishTime = sd.publishTime || '00:00';
    if (date > p.date) return null;
    if (date === p.date && publishTime > p.time) return null;
    const qref = db.doc(`questions/${sd.questionId}`);
    const q = await tx.get(qref);
    if (!q.exists) return null;
    const qd = q.data();
    const pub = {
      date,
      questionId: q.id,
      version: qd.version || 1,
      defaultLang: qd.defaultLang || 'tr',
      category: qd.category || '',
      i18n: core.publicI18n(qd.i18n),
    };
    tx.set(dref, { ...pub, publishedAt: FieldValue.serverTimestamp() });
    tx.set(db.doc(`dailyKeys/${date}`), {
      correctIndex: qd.correctIndex,
      i18n: core.explanationI18n(qd.i18n),
    });
    tx.update(qref, { published: true, publishedDate: date });
    return pub;
  });
}

function localizedPublic(daily, lang) {
  const { v } = core.pickLang(daily.i18n, daily.defaultLang, lang);
  return { text: v.text, options: v.options };
}

/** Cevap kaydını istemciye uygun, dile göre seçilmiş biçime çevirir. */
function answerView(a, lang) {
  const q = a.question;
  const { v } = core.pickLang(q.i18n, q.defaultLang, lang);
  return {
    date: a.date,
    selectedIndex: a.selectedIndex,
    correctIndex: q.correctIndex,
    correct: a.correct,
    points: a.points,
    basePoints: a.basePoints,
    bonusPoints: a.bonusPoints,
    elapsedMs: a.elapsedMs,
    category: q.category,
    text: v.text,
    options: v.options,
    explanation: v.explanation || '',
  };
}

function toMs(ts) {
  return ts && typeof ts.toMillis === 'function' ? ts.toMillis() : null;
}

// ------------------------------------------------------------------ callable

/** Ana sayfa: günün durumu. Soru metni/seçenekler burada VERİLMEZ. */
exports.getToday = onCall(OPTS, async (req) => {
  const { uid, user } = await ensureUser(req);
  const lang = langOf(req);
  const now = new Date();
  const p = core.istanbulParts(now);
  const daily = await materialize(p.date, now);
  const base = {
    serverNow: now.getTime(),
    date: p.date,
    displayName: user.displayName,
  };
  if (!daily) {
    const s = await db.doc(`schedule/${p.date}`).get();
    if (s.exists) {
      return { ...base, status: 'scheduled', publishTime: s.data().publishTime || '00:00' };
    }
    return { ...base, status: 'none' };
  }
  const a = await db.doc(`answers/${p.date}_${uid}`).get();
  return {
    ...base,
    status: 'published',
    category: daily.category,
    answered: a.exists,
    result: a.exists ? answerView(a.data(), lang) : null,
  };
});

/**
 * Soruyu açar ve sunucuda süreyi başlatır. Başlangıç zamanı yalnızca bir kez
 * yazılır; ekrandan çıkıp dönmek veya cihaz saati süreyi etkilemez.
 */
exports.startQuestion = onCall(OPTS, async (req) => {
  const { uid } = await ensureUser(req);
  const lang = langOf(req);
  const now = new Date();
  const p = core.istanbulParts(now);
  const daily = await materialize(p.date, now);
  if (!daily) throw new HttpsError('failed-precondition', 'no-question');

  const a = await db.doc(`answers/${p.date}_${uid}`).get();
  if (a.exists) {
    return { serverNow: now.getTime(), answered: true, result: answerView(a.data(), lang) };
  }
  const aref = db.doc(`attempts/${p.date}_${uid}`);
  try {
    await aref.create({
      uid,
      date: p.date,
      startedAt: FieldValue.serverTimestamp(),
      startedAtMs: Date.now(),
    });
  } catch (e) {
    if (e.code !== 6 && !/ALREADY_EXISTS/.test(String(e.message))) throw e;
  }
  const att = await aref.get();
  const q = localizedPublic(daily, lang);
  return {
    serverNow: Date.now(),
    answered: false,
    startedAtMs: att.data().startedAtMs || toMs(att.data().startedAt),
    question: { date: p.date, category: daily.category, text: q.text, options: q.options },
  };
});

/** Cevabı atomik olarak kaydeder. Aynı gün ikinci cevap kabul edilmez. */
exports.submitAnswer = onCall(OPTS, async (req) => {
  const { uid } = await ensureUser(req);
  const lang = langOf(req);
  const idx = req.data && req.data.answerIndex;
  if (!Number.isInteger(idx) || idx < 0 || idx > 3) {
    throw new HttpsError('invalid-argument', 'bad-answer');
  }
  const now = new Date();
  const p = core.istanbulParts(now);
  await materialize(p.date, now);

  const aref = db.doc(`answers/${p.date}_${uid}`);
  const dref = db.doc(`daily/${p.date}`);
  const kref = db.doc(`dailyKeys/${p.date}`);
  const attref = db.doc(`attempts/${p.date}_${uid}`);
  const uref = db.doc(`users/${uid}`);
  const mref = db.doc(`monthly/${p.ym}_${uid}`);
  const prevQuery = db
    .collection('daily')
    .where('date', '<', p.date)
    .orderBy('date', 'desc')
    .limit(1);

  const out = await db.runTransaction(async (tx) => {
    const [a, d, k, att, u, m, prev] = await Promise.all([
      tx.get(aref),
      tx.get(dref),
      tx.get(kref),
      tx.get(attref),
      tx.get(uref),
      tx.get(mref),
      tx.get(prevQuery),
    ]);
    if (a.exists) return { duplicate: true, data: a.data() };
    if (!d.exists || !k.exists) throw new HttpsError('failed-precondition', 'no-question');

    const nowMs = Date.now();
    const startedMs = att.exists ? att.data().startedAtMs || toMs(att.data().startedAt) : null;
    const elapsedMs = startedMs === null ? 3600000 : core.clampElapsed(nowMs - startedMs);
    const dd = d.data();
    const kd = k.data();
    const correct = idx === kd.correctIndex;
    const score = core.computeScore(correct, elapsedMs);

    // Sunucu tarafında dondurulmuş soru kopyası (sonradan düzenlemeden etkilenmez).
    const fullI18n = {};
    for (const [lg, v] of Object.entries(dd.i18n || {})) {
      fullI18n[lg] = {
        text: v.text,
        options: v.options,
        explanation: (kd.i18n && kd.i18n[lg] && kd.i18n[lg].explanation) || '',
      };
    }
    const record = {
      uid,
      date: p.date,
      ym: p.ym,
      questionId: dd.questionId,
      questionVersion: dd.version || 1,
      selectedIndex: idx,
      correct,
      points: score.total,
      basePoints: score.base,
      bonusPoints: score.bonus,
      elapsedMs,
      answeredAt: FieldValue.serverTimestamp(),
      answeredAtMs: nowMs,
      question: {
        defaultLang: dd.defaultLang,
        category: dd.category,
        correctIndex: kd.correctIndex,
        i18n: fullI18n,
      },
    };

    const ud = u.exists ? u.data() : {};
    const prevDate = prev.empty ? null : prev.docs[0].data().date;
    const streak = core.nextStreak(ud.streak, ud.lastDate, prevDate);
    tx.create(aref, record);
    tx.set(
      uref,
      {
        totalAnswered: (ud.totalAnswered || 0) + 1,
        totalCorrect: (ud.totalCorrect || 0) + (correct ? 1 : 0),
        totalPoints: (ud.totalPoints || 0) + score.total,
        streak,
        bestStreak: Math.max(ud.bestStreak || 0, streak),
        lastDate: p.date,
        displayName: ud.displayName || defaultName(uid),
      },
      { merge: true },
    );
    const md = m.exists ? m.data() : { points: 0, answered: 0, correct: 0 };
    tx.set(mref, {
      uid,
      ym: p.ym,
      displayName: ud.displayName || defaultName(uid),
      points: md.points + score.total,
      answered: md.answered + 1,
      correct: md.correct + (correct ? 1 : 0),
    });
    return { duplicate: false, data: { ...record, answeredAt: null } };
  });
  return { duplicate: out.duplicate, result: answerView(out.data, lang) };
});

exports.getHistory = onCall(OPTS, async (req) => {
  const uid = authUid(req);
  const lang = langOf(req);
  const snap = await db
    .collection('answers')
    .where('uid', '==', uid)
    .orderBy('date', 'desc')
    .limit(500)
    .get();
  return { items: snap.docs.map((d) => answerView(d.data(), lang)) };
});

exports.getProfile = onCall(OPTS, async (req) => {
  const { user } = await ensureUser(req);
  // Aktif seri: son cevap bugün veya bugünden önceki son yayınlanmış gündeyse geçerli.
  const today = core.istanbulParts(new Date()).date;
  let currentStreak = 0;
  if (user.lastDate === today) {
    currentStreak = user.streak || 0;
  } else if (user.lastDate) {
    const prev = await db
      .collection('daily')
      .where('date', '<', today)
      .orderBy('date', 'desc')
      .limit(1)
      .get();
    if (!prev.empty && prev.docs[0].data().date === user.lastDate) {
      currentStreak = user.streak || 0;
    }
  }
  return {
    currentStreak,
    displayName: user.displayName,
    phone: user.phone || '',
    totalAnswered: user.totalAnswered || 0,
    totalCorrect: user.totalCorrect || 0,
    totalPoints: user.totalPoints || 0,
    streak: user.streak || 0,
    bestStreak: user.bestStreak || 0,
    lastDate: user.lastDate || '',
  };
});

exports.setDisplayName = onCall(OPTS, async (req) => {
  const { uid } = await ensureUser(req);
  const raw = req.data && req.data.name;
  const name = typeof raw === 'string' ? raw.trim().replace(/\s+/g, ' ') : '';
  if (name.length < 2 || name.length > 24) {
    throw new HttpsError('invalid-argument', 'bad-name');
  }
  const update = { displayName: name };
  // Telefon isteğe bağlı: yalnızca gönderildiyse güncellenir; boş metin siler.
  if (req.data && typeof req.data.phone === 'string') {
    const phone = req.data.phone.replace(/[\s()-]/g, '');
    if (phone !== '' && !/^\+?\d{10,15}$/.test(phone)) {
      throw new HttpsError('invalid-argument', 'bad-phone');
    }
    update.phone = phone;
  }
  const month = core.istanbulParts(new Date()).ym;
  await db.doc(`users/${uid}`).update(update);
  const m = db.doc(`monthly/${month}_${uid}`);
  if ((await m.get()).exists) await m.update({ displayName: name });
  return { displayName: name };
});

/** Geçmiş günlerin soru bankası (doğru cevaplar yalnızca yayın günü geçtikten sonra). */
exports.getArchive = onCall(OPTS, async (req) => {
  const uid = authUid(req);
  const lang = langOf(req);
  const p = core.istanbulParts(new Date());
  const snap = await db
    .collection('daily')
    .where('date', '<', p.date)
    .orderBy('date', 'desc')
    .limit(300)
    .get();
  if (snap.empty) return { items: [] };
  const keyRefs = snap.docs.map((d) => db.doc(`dailyKeys/${d.id}`));
  const ansRefs = snap.docs.map((d) => db.doc(`answers/${d.id}_${uid}`));
  const keys = await db.getAll(...keyRefs);
  const answers = await db.getAll(...ansRefs);
  const items = snap.docs.map((d, i) => {
    const dd = d.data();
    const kd = keys[i].exists ? keys[i].data() : null;
    const { lang: used, v } = core.pickLang(dd.i18n, dd.defaultLang, lang);
    const expl = kd && kd.i18n && kd.i18n[used] ? kd.i18n[used].explanation : '';
    return {
      date: dd.date,
      category: dd.category,
      text: v.text,
      options: v.options,
      correctIndex: kd ? kd.correctIndex : null,
      explanation: expl || '',
      myAnswer: answers[i].exists ? answers[i].data().selectedIndex : null,
    };
  });
  return { items };
});

exports.getLeaderboard = onCall(OPTS, async (req) => {
  const uid = authUid(req);
  const period = req.data && req.data.period;
  const now = core.istanbulParts(new Date());
  let list;
  let mine;
  let better;

  if (period === 'daily') {
    const col = db.collection('answers');
    const base = col.where('date', '==', now.date).where('points', '>', 0);
    const snap = await base.orderBy('points', 'desc').orderBy('answeredAtMs', 'asc').limit(50).get();
    list = snap.docs.map((d) => ({ uid: d.data().uid, points: d.data().points, extra: d.data().elapsedMs }));
    const me = await db.doc(`answers/${now.date}_${uid}`).get();
    if (me.exists && me.data().points > 0) {
      const md = me.data();
      mine = { points: md.points };
      const gt = await base.where('points', '>', md.points).count().get();
      const eq = await col
        .where('date', '==', now.date)
        .where('points', '==', md.points)
        .where('answeredAtMs', '<', md.answeredAtMs || 0)
        .count()
        .get();
      better = gt.data().count + eq.data().count;
    }
  } else if (period === 'monthly') {
    const col = db.collection('monthly');
    const snap = await col.where('ym', '==', now.ym).orderBy('points', 'desc').limit(50).get();
    list = snap.docs.map((d) => ({ uid: d.data().uid, name: d.data().displayName, points: d.data().points }));
    const me = await db.doc(`monthly/${now.ym}_${uid}`).get();
    if (me.exists && me.data().points > 0) {
      mine = { points: me.data().points };
      const gt = await col.where('ym', '==', now.ym).where('points', '>', mine.points).count().get();
      better = gt.data().count;
    }
  } else if (period === 'all') {
    const col = db.collection('users');
    const snap = await col.where('totalPoints', '>', 0).orderBy('totalPoints', 'desc').limit(50).get();
    list = snap.docs.map((d) => ({ uid: d.id, name: d.data().displayName, points: d.data().totalPoints }));
    const me = await db.doc(`users/${uid}`).get();
    if (me.exists && (me.data().totalPoints || 0) > 0) {
      mine = { points: me.data().totalPoints };
      const gt = await col.where('totalPoints', '>', mine.points).count().get();
      better = gt.data().count;
    }
  } else {
    throw new HttpsError('invalid-argument', 'bad-period');
  }

  // Günlük listede isimler users koleksiyonundan toplu okunur.
  const needNames = list.filter((e) => !e.name);
  if (needNames.length) {
    const docs = await db.getAll(...needNames.map((e) => db.doc(`users/${e.uid}`)));
    docs.forEach((d, i) => {
      needNames[i].name = d.exists ? d.data().displayName : defaultName(needNames[i].uid);
    });
  }
  return {
    period,
    entries: list.map((e, i) => ({
      rank: i + 1,
      name: e.name,
      points: e.points,
      isMe: e.uid === uid,
    })),
    me: mine ? { rank: better + 1, points: mine.points } : null,
  };
});

// ---------------------------------------------------------------- zamanlanmış

/** Her 5 dakikada bugünün planlanmış sorusunu yayına alır (yedek: getToday de yapar). */
exports.publishDaily = onSchedule(
  { region: REGION, schedule: 'every 5 minutes', timeZone: core.TZ, maxInstances: 1 },
  async () => {
    const now = new Date();
    await materialize(core.istanbulParts(now).date, now);
  },
);

exports._materialize = materialize; // testler için
