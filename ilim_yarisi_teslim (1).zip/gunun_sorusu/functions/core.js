'use strict';
// Saf (yan etkisiz) iş kuralları. Sunucu zamanı ve puanlama burada.

const TZ = 'Europe/Istanbul';
// Puanlar "milli-puan" (1 puan = 1000 birim) tamsayısı olarak saklanır; arayüzde 3 ondalıkla gösterilir.
// Doğru cevap: 1000 puan + hız bonusu (0-500 puan). Bonus 5 dakikada doğrusal olarak sıfırlanır;
// her salise (ms) farkı puana yansır, bu yüzden iki kişinin aynı puanı alması pratikte imkânsızdır.
const BASE_POINTS = 1000 * 1000;
const SPEED_BONUS_MAX = 500 * 1000;
const SPEED_WINDOW_MS = 5 * 60 * 1000;
const MAX_ELAPSED_MS = 60 * 60 * 1000;

/** Verilen anın Türkiye saatindeki tarih/saat bileşenleri. */
function istanbulParts(now) {
  const f = new Intl.DateTimeFormat('en-CA', {
    timeZone: TZ,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
  });
  const p = {};
  for (const part of f.formatToParts(now)) p[part.type] = part.value;
  return {
    date: `${p.year}-${p.month}-${p.day}`,
    time: `${p.hour}:${p.minute}`,
    ym: `${p.year}-${p.month}`,
  };
}

/** 'yyyy-MM-dd' tarihine gün ekler (saat dilimi bağımsız, UTC aritmetiği). */
function addDays(dateStr, n) {
  const [y, m, d] = dateStr.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d + n));
  return dt.toISOString().slice(0, 10);
}

function isValidDate(s) {
  if (typeof s !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  return addDays(s, 0) === s;
}

function isValidTime(s) {
  return typeof s === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(s);
}

/** Puanı yalnızca sunucu hesaplar. Yanlış = 0. Dönen değerler milli-puandır. */
function computeScore(correct, elapsedMs) {
  if (!correct) return { base: 0, bonus: 0, total: 0 };
  const e = Number.isFinite(elapsedMs) ? Math.min(Math.max(elapsedMs, 0), SPEED_WINDOW_MS) : SPEED_WINDOW_MS;
  const bonus = Math.round((SPEED_BONUS_MAX * (SPEED_WINDOW_MS - e)) / SPEED_WINDOW_MS);
  return { base: BASE_POINTS, bonus, total: BASE_POINTS + bonus };
}

function clampElapsed(ms) {
  if (!Number.isFinite(ms) || ms < 0) return 0;
  return Math.min(Math.round(ms), MAX_ELAPSED_MS);
}

/** Seri: önceki yayınlanmış gün cevaplandıysa +1, aksi halde 1. */
function nextStreak(prevStreak, lastDate, previousPublishedDate) {
  if (lastDate && previousPublishedDate && lastDate === previousPublishedDate) {
    return (prevStreak || 0) + 1;
  }
  return 1;
}

/** Çok dilli içerikten istenen dili seç; yoksa varsayılan dile düş. */
function pickLang(i18n, defaultLang, lang) {
  const src = i18n || {};
  const ok = (v) => v && typeof v.text === 'string' && v.text.trim() !== '';
  if (ok(src[lang])) return { lang, v: src[lang] };
  if (ok(src[defaultLang])) return { lang: defaultLang, v: src[defaultLang] };
  for (const k of Object.keys(src)) if (ok(src[k])) return { lang: k, v: src[k] };
  return { lang: defaultLang, v: { text: '', options: [], explanation: '' } };
}

function publicI18n(i18n) {
  const out = {};
  for (const [k, v] of Object.entries(i18n || {})) {
    out[k] = { text: v.text, options: v.options };
  }
  return out;
}

function explanationI18n(i18n) {
  const out = {};
  for (const [k, v] of Object.entries(i18n || {})) {
    out[k] = { explanation: v.explanation || '' };
  }
  return out;
}

module.exports = {
  TZ,
  BASE_POINTS,
  SPEED_BONUS_MAX,
  SPEED_WINDOW_MS,
  istanbulParts,
  addDays,
  isValidDate,
  isValidTime,
  computeScore,
  clampElapsed,
  nextStreak,
  pickLang,
  publicI18n,
  explanationI18n,
};
