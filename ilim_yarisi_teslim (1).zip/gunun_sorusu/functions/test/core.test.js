'use strict';
const test = require('node:test');
const assert = require('node:assert');
const c = require('../core');

test('Istanbul tarihi UTC gece yarisindan once degisir', () => {
  const p = c.istanbulParts(new Date('2026-12-01T21:30:00Z'));
  assert.strictEqual(p.date, '2026-12-02');
  assert.strictEqual(p.time, '00:30');
  assert.strictEqual(p.ym, '2026-12');
  const q = c.istanbulParts(new Date('2026-12-01T20:59:00Z'));
  assert.strictEqual(q.date, '2026-12-01');
  assert.strictEqual(q.time, '23:59');
});

test('addDays ay/yil sinirlari', () => {
  assert.strictEqual(c.addDays('2026-12-31', 1), '2027-01-01');
  assert.strictEqual(c.addDays('2028-02-28', 1), '2028-02-29');
  assert.strictEqual(c.addDays('2026-03-01', -1), '2026-02-28');
});

test('tarih/saat dogrulama', () => {
  assert.ok(c.isValidDate('2026-02-28'));
  assert.ok(!c.isValidDate('2026-02-30'));
  assert.ok(!c.isValidDate('26-2-3'));
  assert.ok(c.isValidTime('00:00'));
  assert.ok(!c.isValidTime('24:00'));
});

test('puanlama: salise hassasiyeti, esitlik yok', () => {
  assert.deepStrictEqual(c.computeScore(false, 1000), { base: 0, bonus: 0, total: 0 });
  assert.strictEqual(c.computeScore(true, 0).total, 1500000);
  assert.strictEqual(c.computeScore(true, 300000).total, 1000000);
  assert.strictEqual(c.computeScore(true, 999999999).total, 1000000);
  // 0..300000 ms araligindaki her salise farkli puan verir
  const seen = new Set();
  for (let ms = 0; ms <= 300000; ms++) seen.add(c.computeScore(true, ms).total);
  assert.strictEqual(seen.size, 300001);
  assert.ok(c.computeScore(true, 12345).total > c.computeScore(true, 12346).total);
});

test('sure sinirlama', () => {
  assert.strictEqual(c.clampElapsed(-5), 0);
  assert.strictEqual(c.clampElapsed(99999999), 3600000);
  assert.strictEqual(c.clampElapsed(1234.6), 1235);
});

test('seri', () => {
  assert.strictEqual(c.nextStreak(3, '2026-12-01', '2026-12-01'), 4);
  assert.strictEqual(c.nextStreak(3, '2026-11-29', '2026-12-01'), 1);
  assert.strictEqual(c.nextStreak(0, '', null), 1);
});

test('dil secimi ve geri dusme', () => {
  const i18n = {
    tr: { text: 'Soru', options: ['a', 'b', 'c', 'd'], explanation: 'x' },
    en: { text: '  ', options: [], explanation: '' },
  };
  assert.strictEqual(c.pickLang(i18n, 'tr', 'en').lang, 'tr');
  assert.strictEqual(c.pickLang(i18n, 'tr', 'tr').v.text, 'Soru');
});

test('public icerik aciklama/dogru cevap sizdirmaz', () => {
  const pub = c.publicI18n({ tr: { text: 't', options: ['a'], explanation: 'gizli' } });
  assert.deepStrictEqual(pub, { tr: { text: 't', options: ['a'] } });
});
