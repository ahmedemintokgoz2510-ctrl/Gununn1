'use strict';
// Kullanım (yerel makinede, servis hesabı anahtarıyla):
//   export GOOGLE_APPLICATION_CREDENTIALS=/yol/serviceAccount.json
//   node scripts/set-admin.js yonetici@ornek.com        # yönetici yap
//   node scripts/set-admin.js yonetici@ornek.com --revoke
// Not: firebase-admin için önce `cd functions && npm install` çalıştırın.
const path = require('path');
const admin = require(path.join(__dirname, '..', 'functions', 'node_modules', 'firebase-admin'));

async function main() {
  const email = process.argv[2];
  const revoke = process.argv.includes('--revoke');
  if (!email) {
    console.error('E-posta gerekli.');
    process.exit(1);
  }
  admin.initializeApp();
  const user = await admin.auth().getUserByEmail(email);
  await admin.auth().setCustomUserClaims(user.uid, revoke ? { admin: false } : { admin: true });
  console.log(`${email}: admin=${!revoke}. Kullanıcı çıkış yapıp tekrar girmelidir.`);
}
main().catch((e) => {
  console.error(e.message);
  process.exit(1);
});
