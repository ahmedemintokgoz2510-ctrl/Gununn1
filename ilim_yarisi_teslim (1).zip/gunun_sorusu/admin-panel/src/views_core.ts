import * as api from './api';
import { t, getLang, errText } from './i18n';
import { $, $$, esc, msg, fmtDate } from './ui';
import { istanbulNow, addDays, isValidTime } from './lib/dates';
import { firstFreeDate } from './lib/scheduler';
import { validateDraft } from './lib/pdfParser';
import type { DraftQuestion, Lang } from './lib/types';

export interface Ctx { uid: string; email: string }
export type View = (root: HTMLElement, ctx: Ctx, arg?: string) => Promise<void>;

const statusPill = (q: api.QDoc): string =>
  q.published ? `<span class="pill pub">${esc(t('published'))}</span>` : q.scheduledDate ? `<span class="pill plan">${esc(t('planned'))} · ${esc(q.scheduledDate)}</span>` : `<span class="pill draft">${esc(t('draft'))}</span>`;

export const overview: View = async (root) => {
  root.innerHTML = `<h1>${esc(t('nav_overview'))}</h1><p>${esc(t('loading'))}</p>`;
  const today = istanbulNow().date;
  const [c, qs, sched] = await Promise.all([api.overviewCounts(today), api.listQuestions(), api.listSchedule()]);
  const rate = c.todayAnswers ? Math.round((c.todayCorrect / c.todayAnswers) * 100) + '%' : '–';
  const stat = (v: string | number, k: string) => `<div class="card stat"><b>${esc(v)}</b><span>${esc(k)}</span></div>`;
  const byId = new Map(qs.map((q) => [q.id, q]));
  const up = sched.filter((s) => s.date >= today).sort((a, b) => a.date.localeCompare(b.date)).slice(0, 7);
  root.innerHTML = `<h1>${esc(t('nav_overview'))}</h1>
  <div class="grid">${stat(c.total, t('total'))}${stat(c.published, t('published'))}${stat(c.drafts, t('draft'))}${stat(c.planned, t('planned'))}${stat(c.participants, t('participants'))}${stat(c.todayAnswers, t('todayAnswers'))}${stat(rate, t('todayRate'))}</div>
  <div class="two"><div class="card"><h2>${esc(t('recent'))}</h2>${qs.slice(0, 6).map((q) => `<p>${esc(api.mainContent(q).text.slice(0, 80))} ${statusPill(q)}</p>`).join('') || esc(t('none'))}</div>
  <div class="card"><h2>${esc(t('upcoming'))}</h2>${up.map((s) => `<p><b>${esc(fmtDate(s.date, getLang()))}</b> ${esc(s.publishTime)} – ${esc((byId.get(s.questionId) ? api.mainContent(byId.get(s.questionId)!).text : '').slice(0, 60))}</p>`).join('') || esc(t('none'))}</div></div>`;
};

export const questions: View = async (root) => {
  root.innerHTML = `<h1>${esc(t('nav_questions'))}</h1><p>${esc(t('loading'))}</p>`;
  const qs = await api.listQuestions();
  const draw = (filter: string) => {
    const f = filter.toLocaleLowerCase('tr');
    const rows = qs.filter((q) => !f || api.mainContent(q).text.toLocaleLowerCase('tr').includes(f) || q.category.toLocaleLowerCase('tr').includes(f));
    $('#qtbody', root).innerHTML = rows.map((q) => `<tr><td>${esc(api.mainContent(q).text.slice(0, 110))}</td><td>${esc(q.category)}</td><td>${statusPill(q)}</td>
      <td class="row"><a href="#/edit/${esc(q.id)}"><button class="ghost">${esc(t('edit'))}</button></a><button class="danger" data-del="${esc(q.id)}" ${q.published ? 'disabled title="' + esc(t('deleteBlocked')) + '"' : ''}>${esc(t('delete'))}</button></td></tr>`).join('') || `<tr><td colspan="4">${esc(t('none'))}</td></tr>`;
    $$<HTMLButtonElement>('[data-del]', root).forEach((b) => (b.onclick = async () => {
      if (!confirm(t('confirm'))) return;
      try { await api.deleteQuestion(b.dataset.del!); location.reload(); } catch { alert(t('deleteBlocked')); }
    }));
  };
  root.innerHTML = `<h1>${esc(t('nav_questions'))}</h1><div class="card"><input id="qs" placeholder="${esc(t('question'))} / ${esc(t('category'))}"><div class="tbl"><table><thead><tr><th>${esc(t('question'))}</th><th>${esc(t('category'))}</th><th>${esc(t('status'))}</th><th></th></tr></thead><tbody id="qtbody"></tbody></table></div></div>`;
  draw('');
  $<HTMLInputElement>('#qs', root).oninput = (e) => draw((e.target as HTMLInputElement).value);
};

export function previewHtml(d: DraftQuestion): string {
  const L = ['A', 'B', 'C', 'D'];
  return `<div class="preview"><small>${esc(d.category)}</small><p><b>${esc(d.text)}</b></p>${d.options.map((o, i) => `<div class="opt ${i === d.correctIndex ? 'right' : ''}">${L[i]}) ${esc(o)}</div>`).join('')}${d.explanation ? `<p><i>${esc(d.explanation)}</i></p>` : ''}</div>`;
}

export const questionForm: View = async (root, ctx, id) => {
  const existing = id ? await api.getQuestion(id) : null;
  const main = existing ? api.mainContent(existing) : { text: '', options: ['', '', '', ''], explanation: '' };
  const otherLang: Lang = (existing?.defaultLang ?? 'tr') === 'tr' ? 'en' : 'tr';
  const alt = existing?.i18n[otherLang] ?? { text: '', options: ['', '', '', ''], explanation: '' };
  const L = ['A', 'B', 'C', 'D'];
  const locked = existing?.published === true;
  root.innerHTML = `<h1>${esc(existing ? t('edit') : t('nav_new'))}</h1>${locked ? msg('warn', t('lockedEdit')) : ''}
  <div class="two"><div class="card"><div id="alert"></div>
  <label>${esc(t('language'))}</label><select id="lang"><option value="tr">Türkçe</option><option value="en">English</option></select>
  <label>${esc(t('qText'))}</label><textarea id="text">${esc(main.text)}</textarea>
  ${L.map((l, i) => `<label>${esc(t('option'))} ${l}</label><input id="o${i}" value="${esc(main.options[i] ?? '')}">`).join('')}
  <label>${esc(t('correct'))}</label><select id="correct">${L.map((l, i) => `<option value="${i}" ${existing && existing.correctIndex === i ? 'selected' : ''}>${l}</option>`).join('')}</select>
  <label>${esc(t('explanation'))}</label><textarea id="expl">${esc(main.explanation)}</textarea>
  <label>${esc(t('category'))}</label><input id="cat" value="${esc(existing?.category ?? '')}">
  <details><summary>${esc(t('translation'))}</summary><label>${esc(t('qText'))}</label><textarea id="atext">${esc(alt.text)}</textarea>
  ${L.map((l, i) => `<label>${esc(t('option'))} ${l}</label><input id="a${i}" value="${esc(alt.options[i] ?? '')}">`).join('')}<label>${esc(t('explanation'))}</label><textarea id="aexpl">${esc(alt.explanation)}</textarea></details>
  ${existing ? '' : `<h2>${esc(t('date'))}</h2><div class="row"><input type="date" id="date" style="width:auto"><input type="time" id="time" value="00:00" style="width:auto"></div>
  <label><input type="checkbox" id="auto" style="width:auto"> ${esc(t('autoSlot'))}</label>`}
  <div class="row" style="margin-top:12px"><button id="save">${esc(existing ? t('save') : t('saveDraft'))}</button>${existing ? '' : `<button id="savesch" class="ghost">${esc(t('saveSchedule'))}</button>`}</div></div>
  <div><h2>${esc(t('preview'))}</h2><div id="prev"></div></div></div>`;
  $<HTMLSelectElement>('#lang', root).value = existing?.defaultLang ?? getLang();
  const val = (s: string) => $<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>(s, root).value;
  const read = (): DraftQuestion => ({ text: val('#text'), options: [0, 1, 2, 3].map((i) => val('#o' + i)), correctIndex: Number(val('#correct')), explanation: val('#expl'), category: val('#cat'), lang: val('#lang') as Lang });
  const readAlt = () => ({ text: val('#atext'), options: [0, 1, 2, 3].map((i) => val('#a' + i)), explanation: val('#aexpl') });
  const refresh = () => ($('#prev', root).innerHTML = previewHtml(read()));
  $$<HTMLElement>('input,textarea,select', root).forEach((e) => e.addEventListener('input', refresh));
  refresh();

  const doSave = async (withDate: boolean) => {
    const d = read();
    const errs = validateDraft(d);
    const al = $('#alert', root);
    if (errs.length) { al.innerHTML = msg('err', errs.map((e) => errText(e.code, e.detail)).join(' · ')); return; }
    try {
      if (existing) await api.updateQuestion(existing.id, d, readAlt());
      else {
        let sched: { date: string; time: string } | undefined;
        if (withDate) {
          const time = val('#time');
          if (!isValidTime(time)) { al.innerHTML = msg('err', t('err_badDate')); return; }
          let date = val('#date');
          if ($<HTMLInputElement>('#auto', root).checked) {
            const taken = new Set((await api.listSchedule()).map((s) => s.date));
            date = firstFreeDate(istanbulNow().date, taken);
          }
          if (!date) { al.innerHTML = msg('err', t('err_badDate')); return; }
          sched = { date, time };
        }
        await api.createQuestion(d, ctx.uid, readAlt(), sched);
      }
      location.hash = '#/questions';
    } catch (e) {
      al.innerHTML = msg('err', e instanceof api.DuplicateError ? t('duplicateQ') : e instanceof api.DateTakenError ? t('dateTaken') : e instanceof api.LockedError ? t('dateLocked') : String((e as Error).message));
    }
  };
  $<HTMLButtonElement>('#save', root).onclick = () => doSave(false);
  if (!existing) $<HTMLButtonElement>('#savesch', root).onclick = () => doSave(true);
};

export const calendar: View = async (root, ctx) => {
  root.innerHTML = `<h1>${esc(t('nav_calendar'))}</h1><p>${esc(t('loading'))}</p>`;
  const [qs, sched, pubDates] = await Promise.all([api.listQuestions(), api.listSchedule(), api.listPublishedDates()]);
  const byId = new Map(qs.map((q) => [q.id, q]));
  const sMap = new Map(sched.map((s) => [s.date, s]));
  let month = istanbulNow().date.slice(0, 7);
  let sel = '';
  const draw = () => {
    const [y, m] = month.split('-').map(Number);
    const first = new Date(Date.UTC(y, m - 1, 1));
    const offset = (first.getUTCDay() + 6) % 7;
    const days = new Date(Date.UTC(y, m, 0)).getUTCDate();
    const heads = getLang() === 'en' ? ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'] : ['Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt', 'Paz'];
    let cells = heads.map((h) => `<div class="h">${h}</div>`).join('') + '<div></div>'.repeat(offset);
    for (let d = 1; d <= days; d++) {
      const date = `${month}-${String(d).padStart(2, '0')}`;
      const s = sMap.get(date);
      const cls = pubDates.has(date) ? 'pub' : s ? 'plan' : '';
      const q = s ? byId.get(s.questionId) : undefined;
      cells += `<div class="d ${cls} ${sel === date ? 'sel' : ''}" data-date="${date}"><b>${d}</b><br>${esc(q ? api.mainContent(q).text.slice(0, 28) : '')}</div>`;
    }
    const s = sel ? sMap.get(sel) : undefined;
    const locked = sel ? pubDates.has(sel) : false;
    const drafts = qs.filter((q) => !q.published && !q.scheduledDate);
    const panel = !sel ? '' : `<div class="card"><h2>${esc(fmtDate(sel, getLang()))}</h2>${locked ? msg('warn', t('dateLocked')) : ''}
      ${s ? `<p>${esc(byId.get(s.questionId) ? api.mainContent(byId.get(s.questionId)!).text : '')}<br><small>${esc(t('time'))}: ${esc(s.publishTime)}</small></p>${locked ? '' : `<div class="row"><input type="date" id="nd" value="${esc(sel)}" style="width:auto"><button id="mv">${esc(t('changeDate'))}</button><button class="danger" id="un">${esc(t('unschedule'))}</button></div>`}`
      : drafts.length === 0 ? `<p>${esc(t('noFree'))}</p>` : `<label>${esc(t('question'))}</label><select id="pick">${drafts.map((q) => `<option value="${esc(q.id)}">${esc(api.mainContent(q).text.slice(0, 80))}</option>`).join('')}</select><label>${esc(t('time'))}</label><input type="time" id="tm" value="00:00" style="width:auto"><div style="margin-top:10px"><button id="as">${esc(t('assign'))}</button></div>`}<div id="al"></div></div>`;
    root.innerHTML = `<h1>${esc(t('nav_calendar'))}</h1><div class="row"><button class="ghost" id="pm">‹</button><b>${esc(month)}</b><button class="ghost" id="nm">›</button></div><div class="cal card">${cells}</div>${panel}`;
    $('#pm', root).onclick = () => { month = addDays(month + '-01', -1).slice(0, 7); draw(); };
    $('#nm', root).onclick = () => { month = addDays(month + '-28', 5).slice(0, 7); draw(); };
    $$('.d', root).forEach((e) => (e.onclick = () => { sel = e.dataset.date!; draw(); }));
    const run = async (fn: () => Promise<void>) => {
      try { await fn(); location.reload(); } catch (e) { $('#al', root).innerHTML = msg('err', e instanceof api.DateTakenError ? t('dateTaken') : e instanceof api.LockedError ? t('dateLocked') : String((e as Error).message)); }
    };
    const un = root.querySelector<HTMLButtonElement>('#un');
    if (un && s) un.onclick = () => run(() => api.unassign(s.questionId));
    const mv = root.querySelector<HTMLButtonElement>('#mv');
    if (mv && s) mv.onclick = () => run(() => api.assignDate(s.questionId, $<HTMLInputElement>('#nd', root).value, s.publishTime, ctx.uid));
    const as = root.querySelector<HTMLButtonElement>('#as');
    if (as) as.onclick = () => run(() => api.assignDate($<HTMLSelectElement>('#pick', root).value, sel, $<HTMLInputElement>('#tm', root).value, ctx.uid));
  };
  draw();
};
