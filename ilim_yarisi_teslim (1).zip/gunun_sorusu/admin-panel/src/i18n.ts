import type { ErrorCode, Lang } from './lib/types';

const tr = {
  appName: 'İlim Yarışı – Yönetim', login: 'Yönetici Girişi', email: 'E-posta', password: 'Şifre', signIn: 'Giriş yap', signOut: 'Çıkış',
  denied: 'Bu hesabın yönetici yetkisi yok. Erişim reddedildi.', notConfigured: 'Firebase yapılandırılmamış. .env dosyasını doldurun.',
  nav_overview: 'Genel Bakış', nav_questions: 'Soru Yönetimi', nav_new: 'Yeni Soru Ekle', nav_pdf: "PDF'den Soru Aktar", nav_bulk: 'Toplu Soru Aktar',
  nav_calendar: 'Yayın Takvimi', nav_participants: 'Katılımcılar', nav_results: 'Sıralama ve Sonuçlar', nav_settings: 'Ayarlar', nav_account: 'Yönetici Hesabı',
  total: 'Toplam soru', published: 'Yayınlanmış', draft: 'Taslak', planned: 'Planlanmış', participants: 'Katılımcı', todayAnswers: 'Bugün cevap veren', todayRate: 'Bugünkü doğru oranı',
  recent: 'Son eklenen sorular', upcoming: 'Yaklaşan yayınlar', none: 'Kayıt yok', loading: 'Yükleniyor…', save: 'Kaydet', cancel: 'Vazgeç', delete: 'Sil', edit: 'Düzenle', confirm: 'Emin misiniz?',
  qText: 'Soru metni', option: 'Seçenek', correct: 'Doğru cevap', explanation: 'Açıklama', category: 'Kategori', language: 'Dil', date: 'Yayın tarihi', time: 'Yayın saati', status: 'Durum',
  translation: 'İngilizce/Türkçe çeviri (isteğe bağlı)', preview: 'Önizleme (öğrencide böyle görünür)', autoSlot: 'Sıradaki boş güne otomatik ata', saveDraft: 'Taslak olarak kaydet', saveSchedule: 'Kaydet ve tarihe ata',
  saved: 'Kaydedildi.', duplicateQ: 'Bu soru zaten ekli (aynı metin ve seçenekler).', dateTaken: 'Bu tarih dolu. Önce mevcut planı değiştirin.', dateLocked: 'Bu gün yayına alınmış; değiştirilemez.',
  pickPdf: 'Metin tabanlı PDF seçin', noText: 'Bu PDF metin içermiyor (taranmış/fotoğraf olabilir). Yalnızca metin tabanlı PDF desteklenir.', parsed: 'ayrıştırılan soru', problems: 'sorunlu',
  pdfFormat: 'Beklenen biçim: "Soru 1: …", "A) …" – "D) …", "Doğru cevap: B", isteğe bağlı "Açıklama:" ve "Kategori:".',
  csvFormat: 'CSV/JSON zorunlu alanlar: text, optionA, optionB, optionC, optionD, correct (A-D). İsteğe bağlı: explanation, category, lang (tr/en), date (yyyy-MM-dd).',
  approveAll: 'Hepsini onayla ve kaydet', fixFirst: 'Sorunlu satırları düzeltin veya silin.', startDate: 'Başlangıç tarihi', perDay: 'Günlük soru sayısı: 1', onConflict: 'Dolu gün olursa', skipTaken: 'Dolu günleri atla', abortTaken: 'İşlemi durdur',
  assignAuto: 'Otomatik tarihlendir', conflictWarn: 'Dolu günler bulundu:', unscheduled: 'Tarihsiz', publishedLocked: 'Yayınlandı', answerOrder: 'Sıra', question: 'Soru',
  csvFile: 'CSV veya JSON dosyası', pickDate: 'Tarih seç', unschedule: 'Takvimden kaldır', assign: 'Ata', noFree: 'Atanacak taslak soru yok.', today: 'Bugün', email2: 'E-posta',
  period_daily: 'Günlük', period_monthly: 'Aylık', period_all: 'Genel', name: 'Ad', points: 'Puan', answered: 'Cevap', correctC: 'Doğru', rank: 'Sıra',
  settingsInfo: 'Saat dilimi: Europe/Istanbul. Puan: doğru 1000 + hız bonusu (en fazla 500; 5 dakikada sıfırlanır), yanlış 0. Her salise puanı değiştirir; eşitlikte önce cevaplayan üstte. Günde bir soru.', accountInfo: 'Yönetici yetkisi yalnızca sunucuda scripts/set-admin.js ile verilir.',
  err_missingText: 'Soru metni eksik', err_missingOption: 'Seçenek eksik', err_missingCorrect: 'Doğru cevap yok', err_badCorrect: 'Doğru cevap geçersiz (A-D olmalı)', err_duplicate: 'Yinelenen soru', err_badDate: 'Tarih geçersiz', err_badLang: 'Dil geçersiz',
  missingCols: 'Eksik sütunlar:', invalidJson: 'Geçersiz JSON dosyası.', notArray: 'JSON bir dizi olmalı.', onlyDraft: 'Yalnızca taslak sorular atanabilir.',
  changeDate: 'Tarihi değiştir', phone: 'Telefon', resetMail: 'Şifre sıfırlama e-postası gönder', resetSent: 'Sıfırlama e-postası gönderildi.', existsInDb: 'Veritabanında zaten var', useFor: 'Kullan', row: 'Satır', lockedEdit: 'Yayınlanmış soru: düzenleme geçmiş sonuçları etkilemez.', deleteBlocked: 'Yayınlanmış soru silinemez.', sched: 'Plan',
};
type Dict = typeof tr;
const en: Dict = {
  appName: 'Ilim Yarisi – Admin', login: 'Admin Sign-in', email: 'Email', password: 'Password', signIn: 'Sign in', signOut: 'Sign out',
  denied: 'This account has no admin permission. Access denied.', notConfigured: 'Firebase is not configured. Fill in the .env file.',
  nav_overview: 'Overview', nav_questions: 'Questions', nav_new: 'New Question', nav_pdf: 'Import from PDF', nav_bulk: 'Bulk Import',
  nav_calendar: 'Schedule', nav_participants: 'Participants', nav_results: 'Rankings & Results', nav_settings: 'Settings', nav_account: 'Admin Account',
  total: 'Total questions', published: 'Published', draft: 'Draft', planned: 'Scheduled', participants: 'Participants', todayAnswers: 'Answered today', todayRate: 'Correct rate today',
  recent: 'Recently added', upcoming: 'Upcoming', none: 'No records', loading: 'Loading…', save: 'Save', cancel: 'Cancel', delete: 'Delete', edit: 'Edit', confirm: 'Are you sure?',
  qText: 'Question text', option: 'Option', correct: 'Correct answer', explanation: 'Explanation', category: 'Category', language: 'Language', date: 'Publish date', time: 'Publish time', status: 'Status',
  translation: 'Translation (optional)', preview: 'Preview (as students see it)', autoSlot: 'Assign to next free day', saveDraft: 'Save as draft', saveSchedule: 'Save and assign date',
  saved: 'Saved.', duplicateQ: 'This question already exists (same text and options).', dateTaken: 'This date is taken. Change the existing plan first.', dateLocked: 'This day is already published and cannot be changed.',
  pickPdf: 'Choose a text-based PDF', noText: 'This PDF has no text (it may be scanned/photo). Only text-based PDFs are supported.', parsed: 'questions parsed', problems: 'with problems',
  pdfFormat: 'Expected format: "Question 1: …", "A) …" – "D) …", "Correct answer: B", optional "Explanation:" and "Category:".',
  csvFormat: 'CSV/JSON required fields: text, optionA, optionB, optionC, optionD, correct (A-D). Optional: explanation, category, lang (tr/en), date (yyyy-MM-dd).',
  approveAll: 'Approve all and save', fixFirst: 'Fix or delete the problem rows.', startDate: 'Start date', perDay: 'Questions per day: 1', onConflict: 'If a day is taken', skipTaken: 'Skip taken days', abortTaken: 'Stop the operation',
  assignAuto: 'Auto-schedule', conflictWarn: 'Taken days found:', unscheduled: 'Unscheduled', publishedLocked: 'Published', answerOrder: 'Order', question: 'Question',
  csvFile: 'CSV or JSON file', pickDate: 'Pick a date', unschedule: 'Remove from calendar', assign: 'Assign', noFree: 'No draft questions to assign.', today: 'Today', email2: 'Email',
  period_daily: 'Daily', period_monthly: 'Monthly', period_all: 'All-time', name: 'Name', points: 'Points', answered: 'Answered', correctC: 'Correct', rank: 'Rank',
  settingsInfo: 'Time zone: Europe/Istanbul. Scoring: correct 1000 + speed bonus (up to 500, reaches zero at 5 minutes), wrong 0. Every millisecond changes the score; ties go to the earlier answer. One question per day.', accountInfo: 'Admin rights are granted only on the server via scripts/set-admin.js.',
  err_missingText: 'Question text missing', err_missingOption: 'Option missing', err_missingCorrect: 'No correct answer', err_badCorrect: 'Invalid correct answer (must be A-D)', err_duplicate: 'Duplicate question', err_badDate: 'Invalid date', err_badLang: 'Invalid language',
  missingCols: 'Missing columns:', invalidJson: 'Invalid JSON file.', notArray: 'JSON must be an array.', onlyDraft: 'Only draft questions can be assigned.',
  changeDate: 'Change date', phone: 'Phone', resetMail: 'Send password reset email', resetSent: 'Reset email sent.', existsInDb: 'Already in database', useFor: 'Use', row: 'Row', lockedEdit: 'Published question: editing does not affect past results.', deleteBlocked: 'Published questions cannot be deleted.', sched: 'Plan',
};

export type Key = keyof Dict;
let lang: Lang = (localStorage.getItem('adminLang') as Lang) === 'en' ? 'en' : 'tr';
export const getLang = (): Lang => lang;
export function setLang(l: Lang): void {
  lang = l;
  localStorage.setItem('adminLang', l);
}
export const t = (k: Key): string => (lang === 'en' ? en : tr)[k];
export const errText = (c: ErrorCode, detail?: string): string =>
  t(('err_' + c) as Key) + (detail ? ` (${detail})` : '');
