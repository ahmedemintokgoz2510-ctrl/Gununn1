import type { Lang, ParsedQuestion } from './types';
import { validateDraft } from './pdfParser';
import { isValidDate } from './dates';

/** RFC 4180 benzeri CSV ayrıştırıcı: tırnaklı alanlar, virgül ve satır sonları. */
export function parseCsv(input: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = '';
  let quoted = false;
  const s = input.replace(/^\uFEFF/, '');
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (quoted) {
      if (ch === '"') {
        if (s[i + 1] === '"') {
          cell += '"';
          i++;
        } else quoted = false;
      } else cell += ch;
    } else if (ch === '"') quoted = true;
    else if (ch === ',' || ch === ';') {
      row.push(cell);
      cell = '';
    } else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && s[i + 1] === '\n') i++;
      row.push(cell);
      cell = '';
      if (row.some((c) => c.trim() !== '')) rows.push(row);
      row = [];
    } else cell += ch;
  }
  row.push(cell);
  if (row.some((c) => c.trim() !== '')) rows.push(row);
  return rows;
}

export const CSV_COLUMNS = [
  'text',
  'optionA',
  'optionB',
  'optionC',
  'optionD',
  'correct',
  'explanation',
  'category',
  'lang',
  'date',
] as const;

export const REQUIRED_COLUMNS = ['text', 'optionA', 'optionB', 'optionC', 'optionD', 'correct'];

type Rec = Record<string, unknown>;

function fromRecord(r: Rec, idx: number, defaultLang: Lang): ParsedQuestion {
  const str = (k: string) => (r[k] === undefined || r[k] === null ? '' : String(r[k]).trim());
  const options = [str('optionA'), str('optionB'), str('optionC'), str('optionD')];
  const cRaw = str('correct').toUpperCase();
  const correctIndex = ['A', 'B', 'C', 'D'].indexOf(cRaw.charAt(0));
  const langRaw = str('lang').toLowerCase();
  const lang: Lang = langRaw === 'en' ? 'en' : 'tr';
  const q: ParsedQuestion = {
    sourceIndex: idx,
    text: str('text'),
    options,
    correctIndex,
    explanation: str('explanation'),
    category: str('category'),
    lang: langRaw ? lang : defaultLang,
    errors: [],
  };
  q.errors = validateDraft(q, cRaw !== '');
  if (langRaw && langRaw !== 'tr' && langRaw !== 'en') q.errors.push({ code: 'badLang', detail: langRaw });
  const date = str('date');
  if (date) {
    if (isValidDate(date)) q.date = date;
    else q.errors.push({ code: 'badDate', detail: date });
  }
  return q;
}

/** CSV'yi başlık satırına göre ayrıştırır. Eksik zorunlu sütun varsa hata fırlatır. */
export function parseCsvQuestions(
  text: string,
  defaultLang: Lang = 'tr',
): { questions: ParsedQuestion[]; missingColumns: string[] } {
  const rows = parseCsv(text);
  if (rows.length === 0) return { questions: [], missingColumns: [...REQUIRED_COLUMNS] };
  const header = rows[0].map((h) => h.trim());
  const missingColumns = REQUIRED_COLUMNS.filter((c) => !header.includes(c));
  if (missingColumns.length) return { questions: [], missingColumns };
  const questions = rows.slice(1).map((cells, i) => {
    const rec: Rec = {};
    header.forEach((h, j) => (rec[h] = cells[j] ?? ''));
    return fromRecord(rec, i + 2, defaultLang); // satır numarası (başlık = 1)
  });
  return { questions, missingColumns: [] };
}

/** JSON: [{text, optionA..optionD, correct, explanation?, category?, lang?, date?}, ...] */
export function parseJsonQuestions(
  text: string,
  defaultLang: Lang = 'tr',
): { questions: ParsedQuestion[]; error?: string } {
  let data: unknown;
  try {
    data = JSON.parse(text);
  } catch {
    return { questions: [], error: 'invalidJson' };
  }
  if (!Array.isArray(data)) return { questions: [], error: 'notArray' };
  return {
    questions: data.map((r, i) =>
      fromRecord(r && typeof r === 'object' ? (r as Rec) : {}, i + 1, defaultLang),
    ),
  };
}
