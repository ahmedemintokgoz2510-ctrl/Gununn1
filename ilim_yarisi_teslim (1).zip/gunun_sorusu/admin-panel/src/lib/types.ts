export type Lang = 'tr' | 'en';

export interface I18nContent {
  text: string;
  options: string[];
  explanation: string;
}

export interface DraftQuestion {
  text: string;
  options: string[]; // 4 adet
  correctIndex: number; // 0-3, bulunamadıysa -1
  explanation: string;
  category: string;
  lang: Lang;
}

export type ErrorCode =
  | 'missingText'
  | 'missingOption'
  | 'missingCorrect'
  | 'badCorrect'
  | 'duplicate'
  | 'badDate'
  | 'badLang';

export interface RowError {
  code: ErrorCode;
  detail?: string;
}

export interface ParsedQuestion extends DraftQuestion {
  /** Kaynaktaki sıra (PDF'de soru numarası, CSV'de satır). */
  sourceIndex: number;
  /** İsteğe bağlı yayın tarihi (CSV/JSON'dan). */
  date?: string;
  errors: RowError[];
}
