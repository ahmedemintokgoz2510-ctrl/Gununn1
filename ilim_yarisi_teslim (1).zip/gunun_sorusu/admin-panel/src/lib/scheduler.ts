import { addDays } from './dates';

export interface AutoScheduleResult {
  assignments: { index: number; date: string }[];
  /** Dolu olduğu için atlanan günler. */
  skipped: string[];
}

/**
 * Soruları başlangıç tarihinden itibaren günde BİR soru olacak şekilde dağıtır.
 * Dolu günlerin üzerine yazmaz: ya atlar ('skip') ya da hiç atama yapmaz ('abort').
 */
export function autoSchedule(
  count: number,
  startDate: string,
  taken: ReadonlySet<string>,
  mode: 'skip' | 'abort',
): AutoScheduleResult & { conflict: boolean } {
  const assignments: { index: number; date: string }[] = [];
  const skipped: string[] = [];
  let date = startDate;
  let guard = 0;
  while (assignments.length < count && guard < 5000) {
    guard++;
    if (taken.has(date)) {
      skipped.push(date);
      if (mode === 'abort') return { assignments: [], skipped, conflict: true };
    } else {
      assignments.push({ index: assignments.length, date });
    }
    date = addDays(date, 1);
  }
  return { assignments, skipped, conflict: false };
}

/** Bugünden (veya verilen tarihten) itibaren ilk boş gün. */
export function firstFreeDate(from: string, taken: ReadonlySet<string>): string {
  let d = from;
  let guard = 0;
  while (taken.has(d) && guard < 5000) {
    d = addDays(d, 1);
    guard++;
  }
  return d;
}
