// Tarayıcıda ve Node'da çalışır. pdfjs-dist çağıran tarafça verilir.
// Metin tabanlı PDF'lerden satır satır metin çıkarır.

export interface PdfJsLike {
  getDocument(src: { data: Uint8Array }): {
    promise: Promise<{
      numPages: number;
      getPage(n: number): Promise<{
        getTextContent(): Promise<{ items: Array<{ str?: string; transform?: number[]; hasEOL?: boolean }> }>;
      }>;
    }>;
  };
}

export class NoTextError extends Error {
  constructor() {
    super('noText');
  }
}

export async function extractPdfText(pdfjs: PdfJsLike, data: Uint8Array): Promise<string> {
  const doc = await pdfjs.getDocument({ data }).promise;
  const pages: string[] = [];
  for (let p = 1; p <= doc.numPages; p++) {
    const page = await doc.getPage(p);
    const content = await page.getTextContent();
    // Aynı y koordinatındaki parçaları tek satırda birleştir.
    const lines: { y: number; s: string }[] = [];
    for (const it of content.items) {
      if (typeof it.str !== 'string') continue;
      const y = it.transform ? Math.round(it.transform[5]) : 0;
      const last = lines[lines.length - 1];
      if (last && Math.abs(last.y - y) <= 2) last.s += it.str;
      else lines.push({ y, s: it.str });
    }
    pages.push(lines.map((l) => l.s.trim()).filter(Boolean).join('\n'));
  }
  const text = pages.join('\n');
  if (text.replace(/\s/g, '').length < 20) throw new NoTextError();
  return text;
}
