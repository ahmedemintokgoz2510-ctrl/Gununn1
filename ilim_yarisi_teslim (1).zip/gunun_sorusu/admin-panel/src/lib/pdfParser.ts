import type { ParsedQuestion, RowError } from './types';

const LETTERS = ['A', 'B', 'C', 'D'];

const RE_QUESTION = /^\s*(?:soru|question|s)\s*(\d+)\s*[:.)\-–]\s*(.*)$/i;
const RE_NUMBERED = /^\s*(\d{1,4})\s*[.)]\s+(.+)$/;
const RE_OPTION = /^\s*\(?([A-Da-d])\s*[).:\-–]\s*(.*)$/;
const RE_CORRECT =
  /^\s*(?:doğru\s*cevap|dogru\s*cevap|doğru\s*şık|cevap|correct\s*answer|answer)\s*[:\-–]\s*(.*)$/i;
const RE_EXPLANATION = /^\s*(?:açıklama|aciklama|explanation)\s*[:\-–]\s*(.*)$/i;
const RE_CATEGORY = /^\s*(?:kategori|category)\s*[:\-–]\s*(.*)$/i;

type Field = 'text' | 0 | 1 | 2 | 3 | 'explanation' | 'category' | 'correct' | null;

function parseCorrect(raw: string): number {
  const m = raw.trim().match(/^\(?([A-Da-d])\b/);
  return m ? LETTERS.indexOf(m[1].toUpperCase()) : -1;
}

/**
 * Metin tabanlı PDF'ten çıkarılan satırları sorulara ayırır.
 * Beklenen biçim: "Soru 1: ...", "A) ...", ..., "Doğru cevap: B",
 * isteğe bağlı "Açıklama:" ve "Kategori:". Kural tabanlıdır; yapay zekâ kullanmaz.
 */
export function parseQuestionText(raw: string, lang: 'tr' | 'en' = 'tr'): ParsedQuestion[] {
  const lines = raw.replace(/\r/g, '').split('\n');
  const out: ParsedQuestion[] = [];
  let cur = null as ParsedQuestion | null;
  let correctRaw = '';
  let field = null as Field;
  let seq = 0;

  const flush = () => {
    if (!cur) return;
    finish(cur, correctRaw);
    out.push(cur);
    cur = null;
    correctRaw = '';
    field = null;
  };

  const append = (target: ParsedQuestion, f: Field, s: string) => {
    const t = s.trim();
    if (!t || f === null) return;
    const join = (a: string) => (a ? a + ' ' + t : t);
    if (f === 'text') target.text = join(target.text);
    else if (f === 'explanation') target.explanation = join(target.explanation);
    else if (f === 'category') target.category = join(target.category);
    else if (f === 'correct') correctRaw = join(correctRaw);
    else target.options[f] = join(target.options[f]);
  };

  for (const line of lines) {
    if (!line.trim()) continue;

    const q = line.match(RE_QUESTION);
    // "1. metin" biçimi yalnızca henüz soru başlamamışsa veya önceki soru bitmişse yeni soru sayılır.
    const n: RegExpMatchArray | null = !q && (cur === null || field === 'explanation' || field === 'category' || field === 'correct' || field === 3)
      ? line.match(RE_NUMBERED)
      : null;
    if (q || n) {
      flush();
      const m: RegExpMatchArray = (q ?? n)!;
      seq += 1;
      cur = {
        sourceIndex: Number(m[1]) || seq,
        text: m[2].trim(),
        options: ['', '', '', ''],
        correctIndex: -1,
        explanation: '',
        category: '',
        lang,
        errors: [],
      };
      field = 'text';
      continue;
    }
    if (!cur) continue; // ilk sorudan önceki başlık/giriş metni

    const c = line.match(RE_CORRECT);
    if (c) {
      correctRaw = c[1].trim();
      field = 'correct';
      continue;
    }
    const e = line.match(RE_EXPLANATION);
    if (e) {
      cur.explanation = e[1].trim();
      field = 'explanation';
      continue;
    }
    const k = line.match(RE_CATEGORY);
    if (k) {
      cur.category = k[1].trim();
      field = 'category';
      continue;
    }
    const o = line.match(RE_OPTION);
    if (o && field !== 'explanation' && field !== 'category') {
      const idx = LETTERS.indexOf(o[1].toUpperCase()) as 0 | 1 | 2 | 3;
      cur.options[idx] = o[2].trim();
      field = idx;
      continue;
    }
    append(cur, field, line);
  }
  flush();
  return out;
}

function finish(q: ParsedQuestion, correctRaw: string): void {
  q.correctIndex = parseCorrect(correctRaw);
  q.errors = validateDraft(q, correctRaw !== '');
}

/** Bir taslak sorunun eksik/bozuk alanlarını bulur. */
export function validateDraft(
  q: Pick<ParsedQuestion, 'text' | 'options' | 'correctIndex'>,
  hadCorrectValue = true,
): RowError[] {
  const errors: RowError[] = [];
  if (!q.text.trim()) errors.push({ code: 'missingText' });
  q.options.forEach((o, i) => {
    if (!o.trim()) errors.push({ code: 'missingOption', detail: LETTERS[i] });
  });
  if (q.correctIndex < 0 || q.correctIndex > 3) {
    errors.push({ code: hadCorrectValue ? 'badCorrect' : 'missingCorrect' });
  }
  return errors;
}
