import './style.css';
import * as api from './api';
import { t, getLang, type Key } from './i18n';
import { $, esc, msg } from './ui';
import type { Ctx, View } from './views_core';
import { overview, questions, questionForm, calendar } from './views_core';
import { pdfImport, bulkImport } from './views_import';
import { participants, results, settings, account } from './views_misc';

const routes: { path: string; nav: Key; view: View; menu: boolean }[] = [
  { path: 'overview', nav: 'nav_overview', view: overview, menu: true },
  { path: 'questions', nav: 'nav_questions', view: questions, menu: true },
  { path: 'new', nav: 'nav_new', view: (r, c) => questionForm(r, c), menu: true },
  { path: 'pdf', nav: 'nav_pdf', view: pdfImport, menu: true },
  { path: 'bulk', nav: 'nav_bulk', view: bulkImport, menu: true },
  { path: 'calendar', nav: 'nav_calendar', view: calendar, menu: true },
  { path: 'participants', nav: 'nav_participants', view: participants, menu: true },
  { path: 'results', nav: 'nav_results', view: results, menu: true },
  { path: 'settings', nav: 'nav_settings', view: settings, menu: true },
  { path: 'account', nav: 'nav_account', view: account, menu: true },
  { path: 'edit', nav: 'nav_questions', view: questionForm, menu: false },
];

const app = $('#app');
document.documentElement.lang = getLang();
document.title = t('appName');

function showLogin(error = ''): void {
  app.innerHTML = `<div class="card login"><h1>${esc(t('login'))}</h1>${api.configured ? '' : msg('err', t('notConfigured'))}${error ? msg('err', error) : ''}
  <label>${esc(t('email'))}</label><input id="em" type="email" autocomplete="username"><label>${esc(t('password'))}</label><input id="pw" type="password" autocomplete="current-password">
  <div style="margin-top:12px"><button id="go" ${api.configured ? '' : 'disabled'}>${esc(t('signIn'))}</button></div></div>`;
  const go = $<HTMLButtonElement>('#go');
  go.onclick = async () => {
    go.disabled = true;
    try {
      const ok = await api.login($<HTMLInputElement>('#em').value.trim(), $<HTMLInputElement>('#pw').value);
      if (!ok) showLogin(t('denied'));
    } catch (e) {
      showLogin(String((e as Error).message));
    }
  };
}

function showShell(ctx: Ctx): void {
  const render = async () => {
    const [, path = 'overview', arg] = location.hash.split('/');
    const r = routes.find((x) => x.path === path) ?? routes[0];
    app.innerHTML = `<div class="shell"><nav class="nav"><div class="brand">${esc(t('appName'))}</div>${routes
      .filter((x) => x.menu)
      .map((x) => `<a href="#/${x.path}" class="${x.path === r.path || (r.path === 'edit' && x.path === 'questions') ? 'on' : ''}">${esc(t(x.nav))}</a>`)
      .join('')}<a href="#" id="out">${esc(t('signOut'))}</a></nav><main class="main" id="view"></main></div>`;
    $('#out').onclick = (e) => { e.preventDefault(); void api.logout(); };
    try {
      await r.view($('#view'), ctx, arg);
    } catch (e) {
      $('#view').innerHTML = msg('err', String((e as Error).message));
    }
  };
  window.onhashchange = () => void render();
  void render();
}

api.watchAuth((user, isAdmin) => {
  window.onhashchange = null;
  if (user && isAdmin) showShell({ uid: user.uid, email: user.email ?? '' });
  else showLogin();
});
