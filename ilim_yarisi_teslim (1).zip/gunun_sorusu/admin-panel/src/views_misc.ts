import * as api from './api';
import { t, getLang, setLang } from './i18n';
import { $, esc, fmtPoints, msg } from './ui';
import { istanbulNow } from './lib/dates';
import type { View } from './views_core';

export const participants: View = async (root) => {
  const u = await api.listUsers();
  root.innerHTML = `<h1>${esc(t('nav_participants'))} (${u.length})</h1><div class="card tbl"><table><thead><tr><th>${esc(t('name'))}</th><th>${esc(t('email2'))}</th><th>${esc(t('phone'))}</th><th>${esc(t('points'))}</th><th>${esc(t('answered'))}</th><th>${esc(t('correctC'))}</th></tr></thead><tbody>
  ${u.map((x) => `<tr><td>${esc(x.name)}</td><td>${esc(x.email)}</td><td>${esc(x.phone)}</td><td>${fmtPoints(x.points)}</td><td>${x.answered}</td><td>${x.correct}</td></tr>`).join('') || `<tr><td colspan="6">${esc(t('none'))}</td></tr>`}</tbody></table></div>`;
};

export const results: View = async (root) => {
  const now = istanbulNow().date;
  root.innerHTML = `<h1>${esc(t('nav_results'))}</h1><div class="row"><select id="p" style="width:auto"><option value="daily">${esc(t('period_daily'))}</option><option value="monthly">${esc(t('period_monthly'))}</option><option value="all">${esc(t('period_all'))}</option></select></div><div id="out" class="card tbl"></div>`;
  const users = await api.listUsers();
  const names = new Map(users.map((x) => [x.uid, x.name]));
  const info = new Map(users.map((x) => [x.uid, x]));
  const draw = async () => {
    const p = $<HTMLSelectElement>('#p', root).value;
    let rows: { uid: string; name: string; points: number; extra: string }[] = [];
    if (p === 'daily') rows = (await api.dailyResults(now)).map((r) => ({ uid: r.uid, name: names.get(r.uid) ?? r.uid, points: r.points, extra: `${(r.elapsedMs / 1000).toFixed(3)} sn` }));
    else if (p === 'monthly') rows = (await api.monthlyResults(now.slice(0, 7))).map((r) => ({ uid: r.uid, name: r.name || names.get(r.uid) || r.uid, points: r.points, extra: `${r.correct}/${r.answered}` }));
    else rows = users.map((r) => ({ uid: r.uid, name: r.name, points: r.points, extra: `${r.correct}/${r.answered}` }));
    $('#out', root).innerHTML = `<table><thead><tr><th>${esc(t('rank'))}</th><th>${esc(t('name'))}</th><th>${esc(t('email2'))}</th><th>${esc(t('phone'))}</th><th>${esc(t('points'))}</th><th></th></tr></thead><tbody>${rows.map((r, i) => `<tr ${i === 0 ? 'style="font-weight:700"' : ''}><td>${i + 1}</td><td>${esc(r.name)}</td><td>${esc(info.get(r.uid)?.email ?? '')}</td><td>${esc(info.get(r.uid)?.phone ?? '')}</td><td>${fmtPoints(r.points)}</td><td>${esc(r.extra)}</td></tr>`).join('') || `<tr><td colspan="6">${esc(t('none'))}</td></tr>`}</tbody></table>`;
  };
  $<HTMLSelectElement>('#p', root).onchange = draw;
  await draw();
};

export const settings: View = async (root) => {
  root.innerHTML = `<h1>${esc(t('nav_settings'))}</h1><div class="card"><p>${esc(t('settingsInfo'))}</p><label>${esc(t('language'))}</label><select id="l" style="width:auto"><option value="tr">Türkçe</option><option value="en">English</option></select></div>`;
  $<HTMLSelectElement>('#l', root).value = getLang();
  $<HTMLSelectElement>('#l', root).onchange = (e) => { setLang((e.target as HTMLSelectElement).value as 'tr' | 'en'); location.reload(); };
};

export const account: View = async (root, ctx) => {
  root.innerHTML = `<h1>${esc(t('nav_account'))}</h1><div class="card"><p>${esc(t('email2'))}: <b>${esc(ctx.email)}</b></p><p><small>UID: ${esc(ctx.uid)}</small></p><p>${esc(t('accountInfo'))}</p><div id="al"></div><button id="rs">${esc(t('resetMail'))}</button></div>`;
  $<HTMLButtonElement>('#rs', root).onclick = async () => {
    try { await api.sendReset(ctx.email); $('#al', root).innerHTML = msg('ok', t('resetSent')); } catch (e) { $('#al', root).innerHTML = msg('err', String((e as Error).message)); }
  };
};
