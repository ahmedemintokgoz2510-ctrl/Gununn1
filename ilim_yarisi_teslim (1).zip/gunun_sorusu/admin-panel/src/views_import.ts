import * as api from './api';
import { t, getLang, errText, type Key } from './i18n';
import { $, $$, esc, msg } from './ui';
import { istanbulNow, isValidDate, isValidTime } from './lib/dates';
import { autoSchedule } from './lib/scheduler';
import { parseQuestionText, validateDraft } from './lib/pdfParser';
import { parseCsvQuestions, parseJsonQuestions } from './lib/importFiles';
import { extractPdfText, NoTextError, type PdfJsLike } from './lib/pdfExtract';
import { questionId } from './api';
import type { Ctx, View } from './views_core';
import type { ParsedQuestion, RowError } from './lib/types';

/** İçe aktarma önizleme/doğrulama ekranı. Onaylanmadan hiçbir şey kaydedilmez. */
async function review(root: HTMLElement, ctx: Ctx, initial: ParsedQuestion[]): Promise<void> {
  let items = initial.map((q) => ({ ...q, options: [...q.options] }));
  const [existingIds, schedule] = await Promise.all([api.existingQuestionIds(), api.listSchedule()]);
  const taken = new Set(schedule.map((s) => s.date));
  const L = ['A', 'B', 'C', 'D'];

  const recheck = () => {
    const seen = new Set<string>();
    for (const q of items) {
      const errs: RowError[] = validateDraft(q, true).filter((e) => e.code !== 'badCorrect' || q.correctIndex < 0 || q.correctIndex > 3);
      if (q.date && !isValidDate(q.date)) errs.push({ code: 'badDate', detail: q.date });
      const id = questionId(q);
      if (existingIds.has(id) || seen.has(id)) errs.push({ code: 'duplicate' });
      seen.add(id);
      q.errors = errs;
    }
  };

  const draw = () => {
    recheck();
    const bad = items.filter((q) => q.errors.length).length;
    const today = istanbulNow().date;
    root.innerHTML = `<div class="card"><b>${items.length}</b> ${esc(t('parsed'))} · <b>${bad}</b> ${esc(t('problems'))}</div>
    <div class="card"><h2>${esc(t('assignAuto'))}</h2><div class="row">
      <div><label>${esc(t('startDate'))}</label><input type="date" id="start" value="${esc(today)}" style="width:auto"></div>
      <div><label>${esc(t('time'))}</label><input type="time" id="time" value="00:00" style="width:auto"></div>
      <div><label>${esc(t('onConflict'))}</label><select id="mode" style="width:auto"><option value="skip">${esc(t('skipTaken'))}</option><option value="abort">${esc(t('abortTaken'))}</option></select></div>
      <div><label><input type="checkbox" id="doauto" style="width:auto" checked> ${esc(t('assignAuto'))}</label><small>${esc(t('perDay'))}</small></div></div></div>
    <div id="alert">${bad ? msg('warn', t('fixFirst')) : ''}</div>
    ${items.map((q, i) => `<div class="card ${q.errors.length ? 'bad-row' : ''}" data-i="${i}">
      <div class="row"><b>#${q.sourceIndex}</b>${q.date ? `<span class="pill">${esc(q.date)}</span>` : ''}<button class="danger" data-rm="${i}">${esc(t('delete'))}</button></div>
      ${q.errors.length ? msg('err', q.errors.map((e) => errText(e.code, e.detail)).join(' · ')) : ''}
      <textarea data-f="text">${esc(q.text)}</textarea>
      ${L.map((l, k) => `<div class="row"><b>${l}</b><input data-f="o${k}" value="${esc(q.options[k])}" style="flex:1"></div>`).join('')}
      <div class="two"><div><label>${esc(t('correct'))}</label><select data-f="c"><option value="-1">–</option>${L.map((l, k) => `<option value="${k}" ${q.correctIndex === k ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
      <div><label>${esc(t('category'))}</label><input data-f="cat" value="${esc(q.category)}"></div></div>
      <label>${esc(t('explanation'))}</label><textarea data-f="e">${esc(q.explanation)}</textarea></div>`).join('')}
    <button id="approve" ${bad || !items.length ? 'disabled' : ''}>${esc(t('approveAll'))} (${items.length})</button>`;

    $$<HTMLButtonElement>('[data-rm]', root).forEach((b) => (b.onclick = () => { items.splice(Number(b.dataset.rm), 1); draw(); }));
    $$<HTMLElement>('[data-i]', root).forEach((card) => {
      const q = items[Number(card.dataset.i)];
      const on = (f: string, fn: (v: string) => void) => {
        const el = card.querySelector<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>(`[data-f="${f}"]`)!;
        el.onchange = () => { fn(el.value); draw(); };
      };
      on('text', (v) => (q.text = v)); on('e', (v) => (q.explanation = v)); on('cat', (v) => (q.category = v)); on('c', (v) => (q.correctIndex = Number(v)));
      [0, 1, 2, 3].forEach((k) => on('o' + k, (v) => (q.options[k] = v)));
    });
    $<HTMLButtonElement>('#approve', root).onclick = async () => {
      const mode = $<HTMLSelectElement>('#mode', root).value as 'skip' | 'abort';
      const time = $<HTMLInputElement>('#time', root).value;
      const start = $<HTMLInputElement>('#start', root).value;
      const doAuto = $<HTMLInputElement>('#doauto', root).checked;
      const al = $('#alert', root);
      if (!isValidTime(time) || (doAuto && !isValidDate(start))) { al.innerHTML = msg('err', t('err_badDate')); return; }
      // Kendi tarihi olanlar önce yerleşir; dolu/yinelenen tarih varsa durdurulur.
      const dates: (string | undefined)[] = items.map((q) => q.date);
      const used = new Set(taken);
      const clash: string[] = [];
      dates.forEach((d) => { if (d) { if (used.has(d)) clash.push(d); used.add(d); } });
      if (clash.length) { al.innerHTML = msg('err', `${t('conflictWarn')} ${[...new Set(clash)].join(', ')}`); return; }
      if (doAuto) {
        const idx = items.map((_, i) => i).filter((i) => !dates[i]);
        const r = autoSchedule(idx.length, start, used, mode);
        if (r.conflict) { al.innerHTML = msg('err', `${t('conflictWarn')} ${r.skipped.join(', ')}`); return; }
        r.assignments.forEach((a) => (dates[idx[a.index]] = a.date));
        if (r.skipped.length) al.innerHTML = msg('warn', `${t('conflictWarn')} ${r.skipped.join(', ')}`);
      }
      try {
        (document.activeElement as HTMLElement | null)?.blur();
        $<HTMLButtonElement>('#approve', root).disabled = true;
        const n = await api.bulkCreate(items.map((q, i) => ({ draft: q, date: dates[i] })), ctx.uid, time);
        root.innerHTML = msg('ok', `${t('saved')} (${n})`) + `<a href="#/calendar"><button>${esc(t('nav_calendar'))}</button></a>`;
      } catch (e) {
        al.innerHTML = msg('err', String((e as Error).message));
        $<HTMLButtonElement>('#approve', root).disabled = false;
      }
    };
  };
  draw();
}

export const pdfImport: View = async (root, ctx) => {
  root.innerHTML = `<h1>${esc(t('nav_pdf'))}</h1><div class="card"><p>${esc(t('pdfFormat'))}</p><label>${esc(t('language'))}</label><select id="lang" style="width:auto"><option value="tr">Türkçe</option><option value="en">English</option></select>
  <label>${esc(t('pickPdf'))}</label><input type="file" id="file" accept="application/pdf"><div id="alert"></div></div><div id="rev"></div>`;
  $<HTMLSelectElement>('#lang', root).value = getLang();
  $<HTMLInputElement>('#file', root).onchange = async (e) => {
    const f = (e.target as HTMLInputElement).files?.[0];
    const al = $('#alert', root);
    if (!f) return;
    al.innerHTML = msg('warn', t('loading'));
    try {
      const pdfjs = (await import('pdfjs-dist')) as unknown as PdfJsLike & { GlobalWorkerOptions: { workerSrc: string } };
      const worker = (await import('pdfjs-dist/build/pdf.worker.min.mjs?url')).default as string;
      pdfjs.GlobalWorkerOptions.workerSrc = worker;
      const text = await extractPdfText(pdfjs, new Uint8Array(await f.arrayBuffer()));
      const parsed = parseQuestionText(text, $<HTMLSelectElement>('#lang', root).value as 'tr' | 'en');
      if (!parsed.length) { al.innerHTML = msg('err', t('pdfFormat')); return; }
      al.innerHTML = '';
      await review($('#rev', root), ctx, parsed);
    } catch (err) {
      al.innerHTML = msg('err', err instanceof NoTextError ? t('noText') : String((err as Error).message));
    }
  };
};

export const bulkImport: View = async (root, ctx) => {
  const sample = 'text,optionA,optionB,optionC,optionD,correct,explanation,category,lang,date\n"Örnek soru?",Bir,İki,Üç,Dört,B,Açıklama,Genel,tr,2026-12-01\n';
  root.innerHTML = `<h1>${esc(t('nav_bulk'))}</h1><div class="card"><p>${esc(t('csvFormat'))}</p>
  <a download="ornek.csv" href="data:text/csv;charset=utf-8,${encodeURIComponent('\uFEFF' + sample)}">ornek.csv</a>
  <label>${esc(t('csvFile'))}</label><input type="file" id="file" accept=".csv,.json,text/csv,application/json"><div id="alert"></div></div><div id="rev"></div>`;
  $<HTMLInputElement>('#file', root).onchange = async (e) => {
    const f = (e.target as HTMLInputElement).files?.[0];
    const al = $('#alert', root);
    if (!f) return;
    const text = await f.text();
    let parsed: ParsedQuestion[] = [];
    if (f.name.toLowerCase().endsWith('.json')) {
      const r = parseJsonQuestions(text, getLang());
      if (r.error) { al.innerHTML = msg('err', t(r.error as Key)); return; }
      parsed = r.questions;
    } else {
      const r = parseCsvQuestions(text, getLang());
      if (r.missingColumns.length) { al.innerHTML = msg('err', `${t('missingCols')} ${r.missingColumns.join(', ')}`); return; }
      parsed = r.questions;
    }
    if (!parsed.length) { al.innerHTML = msg('err', t('none')); return; }
    al.innerHTML = '';
    await review($('#rev', root), ctx, parsed);
  };
};
