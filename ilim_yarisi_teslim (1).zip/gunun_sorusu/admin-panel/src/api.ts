import { initializeApp } from 'firebase/app';
import { getAuth, signInWithEmailAndPassword, signOut as fbSignOut, onAuthStateChanged, sendPasswordResetEmail, type User } from 'firebase/auth';
import {
  getFirestore, collection, doc, getDocs, getDoc, getCountFromServer, query, where, orderBy, limit,
  runTransaction, writeBatch, serverTimestamp, type DocumentData,
} from 'firebase/firestore';
import type { DraftQuestion, Lang } from './lib/types';
import { fingerprint } from './lib/fingerprint';

const cfg = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY as string | undefined,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN as string | undefined,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID as string | undefined,
  appId: import.meta.env.VITE_FIREBASE_APP_ID as string | undefined,
};
export const configured = Boolean(cfg.apiKey && cfg.projectId && cfg.appId);

const app = configured ? initializeApp(cfg) : null;
const auth = app ? getAuth(app) : null;
const db = app ? getFirestore(app) : null;
const D = () => {
  if (!db) throw new Error('not-configured');
  return db;
};

// ------------------------------------------------------------------ oturum
export async function login(email: string, password: string): Promise<boolean> {
  if (!auth) throw new Error('not-configured');
  const cred = await signInWithEmailAndPassword(auth, email, password);
  const tok = await cred.user.getIdTokenResult(true);
  if (tok.claims.admin !== true) {
    await fbSignOut(auth);
    return false;
  }
  return true;
}
export async function sendReset(email: string): Promise<void> {
  if (!auth) throw new Error('not-configured');
  await sendPasswordResetEmail(auth, email);
}
export const logout = (): Promise<void> => (auth ? fbSignOut(auth) : Promise.resolve());
export function watchAuth(cb: (u: User | null, isAdmin: boolean) => void): void {
  if (!auth) return cb(null, false);
  onAuthStateChanged(auth, async (u) => {
    if (!u) return cb(null, false);
    const tok = await u.getIdTokenResult();
    cb(u, tok.claims.admin === true);
  });
}

// ------------------------------------------------------------------ modeller
export interface QDoc {
  id: string;
  i18n: Record<string, { text: string; options: string[]; explanation: string }>;
  defaultLang: Lang;
  correctIndex: number;
  category: string;
  scheduledDate: string | null;
  published: boolean;
  version: number;
  createdAtMs: number;
}
export interface ScheduleEntry { date: string; questionId: string; publishTime: string }

function toQ(id: string, d: DocumentData): QDoc {
  return {
    id,
    i18n: d.i18n ?? {},
    defaultLang: d.defaultLang ?? 'tr',
    correctIndex: d.correctIndex ?? 0,
    category: d.category ?? '',
    scheduledDate: d.scheduledDate ?? null,
    published: d.published === true,
    version: d.version ?? 1,
    createdAtMs: d.createdAt?.toMillis?.() ?? 0,
  };
}
export const mainContent = (q: QDoc) => q.i18n[q.defaultLang] ?? Object.values(q.i18n)[0] ?? { text: '', options: ['', '', '', ''], explanation: '' };

export async function listQuestions(): Promise<QDoc[]> {
  const s = await getDocs(query(collection(D(), 'questions'), orderBy('createdAt', 'desc'), limit(1000)));
  return s.docs.map((d) => toQ(d.id, d.data()));
}
export async function getQuestion(id: string): Promise<QDoc | null> {
  const s = await getDoc(doc(D(), 'questions', id));
  return s.exists() ? toQ(s.id, s.data()) : null;
}
export async function listSchedule(): Promise<ScheduleEntry[]> {
  const s = await getDocs(collection(D(), 'schedule'));
  return s.docs.map((d) => ({ date: d.id, questionId: d.data().questionId, publishTime: d.data().publishTime ?? '00:00' }));
}
export async function listPublishedDates(): Promise<Set<string>> {
  const s = await getDocs(collection(D(), 'daily'));
  return new Set(s.docs.map((d) => d.id));
}

// ------------------------------------------------------------------ yazma
function buildI18n(q: DraftQuestion, tr?: { text: string; options: string[]; explanation: string } | null) {
  const i18n: Record<string, { text: string; options: string[]; explanation: string }> = {
    [q.lang]: { text: q.text.trim(), options: q.options.map((o) => o.trim()), explanation: q.explanation.trim() },
  };
  if (tr && tr.text.trim() && tr.options.every((o) => o.trim())) {
    const other: Lang = q.lang === 'tr' ? 'en' : 'tr';
    i18n[other] = { text: tr.text.trim(), options: tr.options.map((o) => o.trim()), explanation: tr.explanation.trim() };
  }
  return i18n;
}
export const questionId = (q: Pick<DraftQuestion, 'text' | 'options'>) => fingerprint(q.text, q.options);

export async function existingQuestionIds(): Promise<Set<string>> {
  const s = await getDocs(collection(D(), 'questions'));
  return new Set(s.docs.map((d) => d.id));
}

export class DuplicateError extends Error {}
export class DateTakenError extends Error {}
export class LockedError extends Error {}

export async function createQuestion(
  q: DraftQuestion,
  uid: string,
  tr: { text: string; options: string[]; explanation: string } | null,
  schedule?: { date: string; time: string },
): Promise<string> {
  const id = questionId(q);
  const qref = doc(D(), 'questions', id);
  await runTransaction(D(), async (tx) => {
    if ((await tx.get(qref)).exists()) throw new DuplicateError();
    if (schedule) {
      const sref = doc(D(), 'schedule', schedule.date);
      if ((await tx.get(sref)).exists()) throw new DateTakenError();
      if ((await tx.get(doc(D(), 'daily', schedule.date))).exists()) throw new LockedError();
      tx.set(sref, { questionId: id, publishTime: schedule.time, createdBy: uid, createdAt: serverTimestamp() });
    }
    tx.set(qref, {
      i18n: buildI18n(q, tr), defaultLang: q.lang, correctIndex: q.correctIndex, category: q.category.trim(),
      scheduledDate: schedule ? schedule.date : null, published: false, version: 1, fingerprint: id,
      createdBy: uid, createdAt: serverTimestamp(), updatedAt: serverTimestamp(),
    });
  });
  return id;
}

export async function updateQuestion(
  id: string, q: DraftQuestion, tr: { text: string; options: string[]; explanation: string } | null,
): Promise<void> {
  const qref = doc(D(), 'questions', id);
  await runTransaction(D(), async (tx) => {
    const cur = await tx.get(qref);
    if (!cur.exists()) throw new Error('missing');
    tx.update(qref, {
      i18n: buildI18n(q, tr), defaultLang: q.lang, correctIndex: q.correctIndex, category: q.category.trim(),
      version: (cur.data().version ?? 1) + 1, updatedAt: serverTimestamp(), fingerprint: fingerprint(q.text, q.options),
    });
  });
}

/** Soruyu bir tarihe atar (varsa eski atamayı kaldırır). Dolu/yayınlanmış güne yazmaz. */
export async function assignDate(id: string, date: string, time: string, uid: string): Promise<void> {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new Error('badDate');
  const qref = doc(D(), 'questions', id);
  const sref = doc(D(), 'schedule', date);
  await runTransaction(D(), async (tx) => {
    const q = await tx.get(qref);
    if (!q.exists()) throw new Error('missing');
    if (q.data().published === true) throw new LockedError();
    const s = await tx.get(sref);
    const day = await tx.get(doc(D(), 'daily', date));
    if (day.exists()) throw new LockedError();
    if (s.exists() && s.data().questionId !== id) throw new DateTakenError();
    const old: string | null = q.data().scheduledDate ?? null;
    if (old && old !== date) {
      const oref = doc(D(), 'schedule', old);
      const oldDaily = await tx.get(doc(D(), 'daily', old));
      if (oldDaily.exists()) throw new LockedError();
      tx.delete(oref);
    }
    tx.set(sref, { questionId: id, publishTime: time, createdBy: uid, createdAt: serverTimestamp() });
    tx.update(qref, { scheduledDate: date, updatedAt: serverTimestamp() });
  });
}

export async function unassign(id: string): Promise<void> {
  const qref = doc(D(), 'questions', id);
  await runTransaction(D(), async (tx) => {
    const q = await tx.get(qref);
    if (!q.exists()) return;
    if (q.data().published === true) throw new LockedError();
    const old: string | null = q.data().scheduledDate ?? null;
    if (old) tx.delete(doc(D(), 'schedule', old));
    tx.update(qref, { scheduledDate: null, updatedAt: serverTimestamp() });
  });
}

export async function deleteQuestion(id: string): Promise<void> {
  const qref = doc(D(), 'questions', id);
  await runTransaction(D(), async (tx) => {
    const q = await tx.get(qref);
    if (!q.exists()) return;
    if (q.data().published === true) throw new LockedError();
    const old: string | null = q.data().scheduledDate ?? null;
    if (old) tx.delete(doc(D(), 'schedule', old));
    tx.delete(qref);
  });
}

export interface BulkItem { draft: DraftQuestion; date?: string }
/** Onaylanmış soruları (isteğe bağlı tarihleriyle) 200'lük parçalar hâlinde kaydeder. */
export async function bulkCreate(items: BulkItem[], uid: string, time: string): Promise<number> {
  let n = 0;
  for (let i = 0; i < items.length; i += 200) {
    const batch = writeBatch(D());
    for (const it of items.slice(i, i + 200)) {
      const id = questionId(it.draft);
      batch.set(doc(D(), 'questions', id), {
        i18n: buildI18n(it.draft, null), defaultLang: it.draft.lang, correctIndex: it.draft.correctIndex,
        category: it.draft.category.trim(), scheduledDate: it.date ?? null, published: false, version: 1,
        fingerprint: id, createdBy: uid, createdAt: serverTimestamp(), updatedAt: serverTimestamp(),
      });
      if (it.date) batch.set(doc(D(), 'schedule', it.date), { questionId: id, publishTime: time, createdBy: uid, createdAt: serverTimestamp() });
      n++;
    }
    await batch.commit();
  }
  return n;
}

// ------------------------------------------------------------------ istatistik
export async function overviewCounts(today: string) {
  const c = (q: ReturnType<typeof query>) => getCountFromServer(q).then((r) => r.data().count);
  const col = (n: string) => collection(D(), n);
  const [total, published, drafts, participants, todayAnswers, todayCorrect] = await Promise.all([
    c(query(col('questions'))), c(query(col('questions'), where('published', '==', true))),
    c(query(col('questions'), where('scheduledDate', '==', null), where('published', '==', false))),
    c(query(col('users'))), c(query(col('answers'), where('date', '==', today))),
    c(query(col('answers'), where('date', '==', today), where('correct', '==', true))),
  ]);
  return { total, published, drafts, planned: Math.max(0, total - published - drafts), participants, todayAnswers, todayCorrect };
}
export interface UserRow { uid: string; name: string; email: string; phone: string; points: number; answered: number; correct: number; streak: number }
export async function listUsers(): Promise<UserRow[]> {
  const s = await getDocs(query(collection(D(), 'users'), orderBy('totalPoints', 'desc'), limit(500)));
  return s.docs.map((d) => ({ uid: d.id, name: d.data().displayName ?? d.id, email: d.data().email ?? '', phone: d.data().phone ?? '', points: d.data().totalPoints ?? 0, answered: d.data().totalAnswered ?? 0, correct: d.data().totalCorrect ?? 0, streak: d.data().streak ?? 0 }));
}
export async function dailyResults(date: string): Promise<{ uid: string; points: number; correct: boolean; elapsedMs: number }[]> {
  const s = await getDocs(query(collection(D(), 'answers'), where('date', '==', date), orderBy('points', 'desc'), orderBy('answeredAtMs', 'asc'), limit(100)));
  return s.docs.map((d) => ({ uid: d.data().uid, points: d.data().points, correct: d.data().correct, elapsedMs: d.data().elapsedMs }));
}
export async function monthlyResults(ym: string): Promise<{ uid: string; name: string; points: number; answered: number; correct: number }[]> {
  const s = await getDocs(query(collection(D(), 'monthly'), where('ym', '==', ym), orderBy('points', 'desc'), limit(100)));
  return s.docs.map((d) => ({ uid: d.data().uid, name: d.data().displayName ?? '', points: d.data().points, answered: d.data().answered, correct: d.data().correct }));
}
