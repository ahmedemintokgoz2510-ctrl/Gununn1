import test from 'node:test';
import assert from 'node:assert';
import { parseQuestionText } from '../src/lib/pdfParser';
import { parseCsvQuestions, parseJsonQuestions } from '../src/lib/importFiles';
import { autoSchedule, firstFreeDate } from '../src/lib/scheduler';
import { fingerprint } from '../src/lib/fingerprint';

const SAMPLE = `İlim Yarışı Soru Seti
Hazırlayan: Test

Soru 1: Hz. Peygamber hangi şehirde doğmuştur?
A) Medine
B) Mekke
C) Taif
D) Kudüs
Doğru cevap: B
Açıklama: Mekke'de doğmuştur.
Kategori: Siyer

Soru 2: Namaz kaç rekâttan oluşur
günde toplam?
A) 15
B) 17
C) 20
D) 22
Doğru cevap: B

Soru 3: Eksik soru
A) bir
B) iki
Doğru cevap: Z
`;

test('PDF metni: 3 soru, eksik/bozuklar işaretlenir', () => {
  const r = parseQuestionText(SAMPLE);
  assert.strictEqual(r.length, 3);
  assert.strictEqual(r[0].text, 'Hz. Peygamber hangi şehirde doğmuştur?');
  assert.deepStrictEqual(r[0].options, ['Medine', 'Mekke', 'Taif', 'Kudüs']);
  assert.strictEqual(r[0].correctIndex, 1);
  assert.strictEqual(r[0].explanation, "Mekke'de doğmuştur.");
  assert.strictEqual(r[0].category, 'Siyer');
  assert.strictEqual(r[0].errors.length, 0);
  assert.strictEqual(r[1].text, 'Namaz kaç rekâttan oluşur günde toplam?');
  assert.strictEqual(r[1].category, '');
  assert.strictEqual(r[1].errors.length, 0);
  const codes = r[2].errors.map((e) => e.code + (e.detail ?? ''));
  assert.deepStrictEqual(codes, ['missingOptionC', 'missingOptionD', 'badCorrect']);
});

test('PDF: çok satırlı seçenek ve cevap yok', () => {
  const r = parseQuestionText('Soru 1: S?\nA) bir\nikinci satır\nB) b\nC) c\nD) d\n');
  assert.strictEqual(r[0].options[0], 'bir ikinci satır');
  assert.strictEqual(r[0].errors[0].code, 'missingCorrect');
});

test('CSV: tırnaklı virgül, hatalı satır, eksik sütun', () => {
  const csv =
    'text,optionA,optionB,optionC,optionD,correct,category,date\n' +
    '"Soru, virgüllü?",a,b,c,d,c,Genel,2026-12-01\n' +
    'Eksik?,a,b,,d,A,,2026-13-45\n';
  const r = parseCsvQuestions(csv);
  assert.strictEqual(r.questions.length, 2);
  assert.strictEqual(r.questions[0].text, 'Soru, virgüllü?');
  assert.strictEqual(r.questions[0].correctIndex, 2);
  assert.strictEqual(r.questions[0].date, '2026-12-01');
  assert.deepStrictEqual(
    r.questions[1].errors.map((e) => e.code),
    ['missingOption', 'badDate'],
  );
  assert.deepStrictEqual(parseCsvQuestions('a,b\n1,2').missingColumns.includes('text'), true);
});

test('JSON içe aktarma', () => {
  const ok = parseJsonQuestions(
    JSON.stringify([{ text: 'S', optionA: 1, optionB: 2, optionC: 3, optionD: 4, correct: 'a' }]),
  );
  assert.strictEqual(ok.questions[0].errors.length, 0);
  assert.strictEqual(parseJsonQuestions('{').error, 'invalidJson');
  assert.strictEqual(parseJsonQuestions('{}').error, 'notArray');
});

test('Otomatik tarihlendirme: 100 soru, 100 gün, ay/yıl geçişi', () => {
  const r = autoSchedule(100, '2026-12-01', new Set(), 'skip');
  assert.strictEqual(r.assignments.length, 100);
  assert.strictEqual(r.assignments[0].date, '2026-12-01');
  assert.strictEqual(r.assignments[31].date, '2027-01-01');
  assert.strictEqual(new Set(r.assignments.map((a) => a.date)).size, 100);
});

test('Çakışma: abort hiçbir şey atamaz; skip dolu günü atlar', () => {
  const taken = new Set(['2026-12-02']);
  const a = autoSchedule(3, '2026-12-01', taken, 'abort');
  assert.strictEqual(a.conflict, true);
  assert.strictEqual(a.assignments.length, 0);
  const s = autoSchedule(3, '2026-12-01', taken, 'skip');
  assert.deepStrictEqual(
    s.assignments.map((x) => x.date),
    ['2026-12-01', '2026-12-03', '2026-12-04'],
  );
  assert.deepStrictEqual(s.skipped, ['2026-12-02']);
});

test('Sıradaki boş gün (26 Kasım örneği)', () => {
  const taken = new Set(['2026-11-26', '2026-11-27', '2026-11-28']);
  assert.strictEqual(firstFreeDate('2026-11-26', taken), '2026-11-29');
});

test('Parmak izi: aynı soru, farklı boşluk/noktalama = aynı', () => {
  const a = fingerprint('Mekke  hangi ülkede?', ['A', 'B', 'C', 'D']);
  const b = fingerprint('mekke hangi ülkede', ['a', 'b', 'c', 'd']);
  const c = fingerprint('Medine hangi ülkede?', ['A', 'B', 'C', 'D']);
  assert.strictEqual(a, b);
  assert.notStrictEqual(a, c);
});
