#!/usr/bin/env bash
# android/ klasörü depoda kalıcıdır; "flutter create ." ÇALIŞTIRILMAZ.
# Yalnızca Gradle wrapper betik/jar dosyaları eksikse (jar ikili dosyadır), geçici bir
# şablon projeden kopyalanır. Mevcut ayarlara dokunulmaz.
set -euo pipefail
cd "$(dirname "$0")/.."
if [ -f android/gradlew ] && [ -f android/gradle/wrapper/gradle-wrapper.jar ]; then
  echo "Gradle wrapper mevcut."
  exit 0
fi
TMP="$(mktemp -d)"
flutter create --platforms=android --project-name wrapper_tpl "$TMP/tpl" >/dev/null
cp -n "$TMP/tpl/android/gradlew" android/gradlew
cp -n "$TMP/tpl/android/gradlew.bat" android/gradlew.bat
mkdir -p android/gradle/wrapper
cp -n "$TMP/tpl/android/gradle/wrapper/gradle-wrapper.jar" android/gradle/wrapper/gradle-wrapper.jar
chmod +x android/gradlew
rm -rf "$TMP"
echo "Gradle wrapper şablondan eklendi (ayarlar korundu)."
