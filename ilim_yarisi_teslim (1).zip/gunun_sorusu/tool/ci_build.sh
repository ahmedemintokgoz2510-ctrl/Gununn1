#!/usr/bin/env bash
# GitHub Actions ve Codemagic AYNI betiği çalıştırır: paket adı, SDK ve komutlar tek yerde.
set -euo pipefail
cd "$(dirname "$0")/.."

flutter doctor -v
bash tool/ensure_gradle_wrapper.sh
flutter pub get

if ! dart format --output=none --set-exit-if-changed lib test; then
  echo "::warning::Biçimlendirme farkı var. Yerelde 'dart format lib test' çalıştırıp commit edin."
  [ "${STRICT_FORMAT:-0}" = "1" ] && exit 1
fi

flutter analyze
flutter test

DEFINES=()
if [ -n "${FIREBASE_API_KEY:-}" ]; then
  DEFINES+=("--dart-define=FIREBASE_API_KEY=${FIREBASE_API_KEY}"
            "--dart-define=FIREBASE_APP_ID=${FIREBASE_APP_ID:-}"
            "--dart-define=FIREBASE_PROJECT_ID=${FIREBASE_PROJECT_ID:-}"
            "--dart-define=FIREBASE_SENDER_ID=${FIREBASE_SENDER_ID:-}")
else
  echo "UYARI: FIREBASE_* değişkenleri yok. APK derlenir ama uygulama 'sunucu yapılandırılmamış' ekranını gösterir."
fi

flutter build apk --release "${DEFINES[@]}"

APK=build/app/outputs/flutter-apk/app-release.apk
test -f "$APK" || { echo "APK oluşmadı: $APK"; exit 1; }
ls -l "$APK"
