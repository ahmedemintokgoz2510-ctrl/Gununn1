# Denetim Raporu (mevcut proje) ve durum

Her bulgunun yanında bu sürümdeki durumu yazılıdır. Derleme/test doğrulaması için README'deki "Açık noktalar"a bakın.

## Mantık hataları
- `resetStats()` günlük cevap kaydını siliyordu → **Düzeltildi**: günlük hak sunucuda; sıfırlama yalnızca görünümü sıfırlar.
- Günlük hak yalnızca SharedPreferences'taydı → **Düzeltildi**: sunucuda, hesaba bağlı, transaction ile.
- Günün sorusu cihaz saatiyle seçiliyordu (`gün % soru sayısı`) → **Düzeltildi**: sunucu takvimi, Europe/Istanbul.
- Soru eklenince/silinince geçmiş günler kayıyordu → **Düzeltildi**: günlük yayın kaydı soru kaydından ayrı ve dondurulmuş.
- Seri cihaz tarihine bağlıydı → **Düzeltildi**: sunucuda, son yayınlanmış güne göre.

## Güvenlik
- Doğru cevaplar APK içinde düz metindi → **Düzeltildi**: sorular sunucuda, cevap öğrenciye cevaplamadan önce gitmiyor.
- Puan/cevap istemcide hesaplanıyordu → **Düzeltildi**: sunucu hesaplıyor, istemci Firestore'a erişemiyor.
- Yönetici yetkisi → yalnızca sunucuda `admin` claim'i (`scripts/set-admin.js`).

## Eksik/sahte özellikler
- Giriş/kayıt/sıralama yalnızca arayüzdü → **Gerçek backend'e bağlandı** (Firebase gerekli).
- Yönetici paneli, PDF/CSV aktarımı, takvim yoktu → **Eklendi**.
- Yerel "soru ekle" ekranı (herkes kendi sorusunu ekleyebiliyordu) → **Kaldırıldı**, yönetim panelde.

## Süre
- Sayaç ekran açılınca başlıyor, çıkınca sıfırlanıyordu → **Düzeltildi**: sunucuda soru açılınca başlar.

## Derleme ve paket
- `android/` yoktu, `flutter create .` her derlemede çalışıyordu → **Android klasörü depoda, `flutter create .` kaldırıldı**.
- İki CI'da farklı paket adı riski → **Düzeltildi**: ikisi aynı `tool/ci_build.sh`; paket adı `com.sansar.gunun_sorusu`.
- Flutter sürümü sabit değildi → **3.27.4 sabitlendi**, Java 17.
- `test/` yoktu → **Eklendi** (çalıştırılmadı).

## Mimari
- Kategori adları serbest metin, İngilizce çevirisi yalnızca bilinen adlar için.
- Soru sürümü yalnızca sayaç; eski sürümlerin tam geçmişi tutulmuyor (günlük yayın kopyası zaten dondurulmuş).
