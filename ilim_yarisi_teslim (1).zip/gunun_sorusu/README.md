# İlim Yarışı – Günlük Soru Yarışması

Üç parça, tek backend:

| Parça | Klasör | Teknoloji |
|---|---|---|
| Katılımcı Android uygulaması | `lib/`, `android/` | Flutter (3.27.4 sabit) |
| Yönetici web paneli | `admin-panel/` | TypeScript + Vite + Firebase Hosting |
| Backend | `functions/`, `firestore.rules` | Cloud Functions (Node 20) + Firestore + Auth |

## Önemli: ücret
Cloud Functions ve zamanlanmış yayın **Firebase Blaze (kullandıkça öde)** planı ister.
Küçük kullanımda ücretsiz kota içinde kalır ama faturalandırma hesabı bağlamak zorunludur.

## Kurulum (sırayla)
1. Firebase projesi aç. Authentication'da **E-posta/Şifre**'yi etkinleştir.
2. Firestore'u **europe-west1** konumunda oluştur. Planı Blaze yap.
3. `.firebaserc.example` → `.firebaserc` yap, proje kimliğini yaz.
4. `cd functions && npm install && npm test`
5. `firebase deploy --only firestore,functions` (kurallar, indeksler, fonksiyonlar)
6. **İlk yöneticiyi ata** (istemciden yapılamaz): önce panelde veya Auth'ta hesabı oluştur, sonra
   `export GOOGLE_APPLICATION_CREDENTIALS=servis-hesabi.json && node scripts/set-admin.js ornek@mail.com`
7. Panel: `cd admin-panel && cp .env.example .env` (web uygulaması ayarlarını doldur) →
   `npm install && npm test && npm run build && firebase deploy --only hosting`
8. Android: GitHub Secrets (veya Codemagic `firebase` grubu) içine
   `FIREBASE_API_KEY, FIREBASE_APP_ID, FIREBASE_PROJECT_ID, FIREBASE_SENDER_ID` ekle.
   Push at → Actions çıktısında `ilim-yarisi-apk`. Yerelde: `bash tool/ci_build.sh`.
9. İlk soruları yüklemek için panelde **Toplu Soru Aktar** → `samples/ornek_30_soru.csv`.

## Kurallar (sunucuda uygulanır)
- Gün başına **tek** yayın (`schedule/{yyyy-MM-dd}`), saat dilimi Europe/Istanbul, sunucu saati esas.
- Cevap kaydı `answers/{tarih_uid}`: ikinci cevap reddedilir, kayıt değiştirilemez; çift istek transaction ile engellenir.
- Doğru cevap yalnızca `dailyKeys` / `questions` içinde; öğrenci cevaplamadan önce göremez, Firestore'a istemci erişimi yoktur.
- Puan (sunucu hesaplar, salise hassasiyetli): yanlış 0; doğru 1000 + hız bonusu. Bonus 500'den başlar, 5 dakikada doğrusal olarak 0'a iner; her salise puanı değiştirir (5 dakika içinde 300.001 farklı puan). Puanlar milli-puan tamsayı olarak saklanır, ekranda 3 ondalıkla gösterilir (örn. 1487,250). Eşit puanda önce cevaplayan üstte. Süre soru açılınca sunucuda başlar; ölçüm ağ gecikmesini ve sunucu örnekleri arası küçük saat farkını içerir.
- Yayınlanmış günün soru kopyası dondurulur; sonradan düzenleme geçmişi bozmaz. Yayınlanmış soru silinemez.
- "İstatistikleri sıfırla" yalnızca ekran görünümünü sıfırlar; "Yerel verileri temizle" ayarları siler ve çıkış yapar. İkisi de günlük hakkı geri vermez.

## Panel nereden açılır?
Panel ayrı bir uygulama değil, **web sitesidir**. `firebase deploy --only hosting` sonrası `https://PROJE-KIMLIGI.web.app` adresinden bilgisayar veya telefon tarayıcısında açılır. Yalnızca `admin` yetkili hesaplar girebilir.

## Açık/sınırlı noktalar (dürüst liste)
- Bildirimler (FCM) **kurulmadı**; ekran "henüz etkin değil" der.
- PDF aktarımı yalnızca metin tabanlı PDF; taranmış PDF reddedilir.
- Günde bir soru (günde birden fazla desteklenmez).
- KVKK ve kural metinleri taslaktır; yayından önce bir hukukçuya okutun. Uygulama içinde hesap silme yok; silme talepleri sosyal medya üzerinden alınır (Google Play yayını için hesap silme eklenmelidir).
- APK debug anahtarıyla imzalanır; mağaza için `android/key.properties` ekleyin.
