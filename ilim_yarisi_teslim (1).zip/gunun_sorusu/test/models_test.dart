import 'package:flutter_test/flutter_test.dart';
import 'package:gunun_sorusu/l10n/strings.dart';
import 'package:gunun_sorusu/models/api_models.dart';
import 'package:gunun_sorusu/utils/date_utils.dart';

void main() {
  test('AnswerResult sunucu verisini okur', () {
    final r = AnswerResult.fromMap({
      'date': '2026-12-01',
      'selectedIndex': 1,
      'correctIndex': 1,
      'correct': true,
      'points': 15,
      'basePoints': 10,
      'bonusPoints': 5,
      'elapsedMs': 42000,
      'category': 'Genel',
      'text': 'Soru?',
      'options': ['a', 'b', 'c', 'd'],
      'explanation': 'x',
    });
    expect(r.correct, isTrue);
    expect(r.points, 15);
    expect(r.elapsed, const Duration(seconds: 42));
    expect(r.options.length, 4);
  });

  test('DailyStatus: yayınlanmamış gün durumları', () {
    expect(DailyStatus.fromMap({'status': 'none', 'date': '2026-12-01'}).status, DayStatus.none);
    final sch = DailyStatus.fromMap({'status': 'scheduled', 'date': '2026-12-01', 'publishTime': '09:00'});
    expect(sch.status, DayStatus.scheduled);
    expect(sch.publishTime, '09:00');
    final pub = DailyStatus.fromMap({'status': 'published', 'date': '2026-12-01', 'answered': false});
    expect(pub.answered, isFalse);
    expect(pub.result, isNull);
  });

  test('QuizSession süreyi sunucu başlangıcından hesaplar, negatife düşmez', () {
    final q = QuizSession.fromMap({
      'answered': false,
      'serverNow': 10000,
      'startedAtMs': 4000,
      'question': {'date': '2026-12-01', 'text': 'S', 'options': ['a', 'b', 'c', 'd']},
    });
    expect(q.elapsedAtResponseMs, 6000);
    expect(const QuizSession(serverNowMs: 1, startedAtMs: 5).elapsedAtResponseMs, 0);
  });

  test('Leaderboard boş/eksik veriyle çöker mi', () {
    final b = Leaderboard.fromMap({'entries': [], 'me': null});
    expect(b.entries, isEmpty);
    expect(b.meRank, isNull);
  });

  test('Ekstra metinler hem TR hem EN için tanımlı', () {
    // strings_extra.dart içindeki iki tablo aynı anahtarlara sahip olmalı.
    final tr = S('tr');
    final en = S('en');
    for (final k in ['home.points', 'quiz.network_error', 'settings.clear_msg', 'ranking.all']) {
      expect(tr(k), isNot(k));
      expect(en(k), isNot(k));
      expect(tr(k), isNot(en(k)));
    }
  });

  test('Puan ve süre biçimi (salise)', () {
    expect(formatPoints(1487250, 'tr'), '1487,250');
    expect(formatPoints(1487250, 'en'), '1487.250');
    expect(formatDuration(const Duration(milliseconds: 83456), millis: true), '01:23.456');
    expect(formatDuration(const Duration(seconds: 5)), '00:05');
  });
}
