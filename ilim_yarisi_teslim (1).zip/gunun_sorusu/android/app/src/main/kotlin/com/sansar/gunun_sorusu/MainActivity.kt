package com.sansar.gunun_sorusu

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
