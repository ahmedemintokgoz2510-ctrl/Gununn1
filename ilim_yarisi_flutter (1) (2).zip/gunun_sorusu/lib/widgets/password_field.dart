import 'package:flutter/material.dart';

import '../state/app_scope.dart';
import '../theme/app_icons.dart';
import '../theme/app_theme.dart';

class PasswordField extends StatefulWidget {
  const PasswordField({super.key, required this.label, this.action = TextInputAction.next});
  final String label;
  final TextInputAction action;

  @override
  State<PasswordField> createState() => _PasswordFieldState();
}

class _PasswordFieldState extends State<PasswordField> {
  bool _hidden = true;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final s = context.s;
    return TextField(
      obscureText: _hidden,
      textInputAction: widget.action,
      decoration: appInput(p, label: widget.label).copyWith(
        prefixIcon: Icon(AppIcons.lock, size: 20, color: p.muted),
        suffixIcon: IconButton(
          icon: Icon(_hidden ? AppIcons.eye : AppIcons.eyeOff, size: 20, color: p.muted),
          tooltip: _hidden ? s('auth.show') : s('auth.hide'),
          onPressed: () => setState(() => _hidden = !_hidden),
        ),
      ),
    );
  }
}
