class QuestionEn {
  final String text;
  final List<String> options;
  final String explanation;
  const QuestionEn(this.text, this.options, this.explanation);
}

// builtin_questions.dart içindeki id'lerle eşleşir. Yeni yerleşik soru
// eklerken buraya da İngilizce karşılığını ekle (eklenmezse Türkçe görünür).
const Map<String, QuestionEn> kEnQuestions = {
  'b1': QuestionEn("What is the capital of Turkey?", ["Istanbul", "Ankara", "Izmir", "Bursa"], "Ankara was declared the capital on 13 October 1923."),
  'b2': QuestionEn("What is the largest ocean in the world?", ["Atlantic", "Indian", "Pacific", "Arctic"], "The Pacific Ocean covers about a third of Earth's surface."),
  'b3': QuestionEn("Which is the largest planet in the Solar System?", ["Saturn", "Jupiter", "Neptune", "Earth"], "Jupiter has more mass than all the other planets combined."),
  'b4': QuestionEn("At what temperature (°C) does water boil at sea level?", ["90", "100", "110", "120"], "At standard pressure, pure water boils at 100 °C."),
  'b5': QuestionEn("In which year was the Republic of Turkey proclaimed?", ["1920", "1921", "1923", "1938"], "The Republic was proclaimed on 29 October 1923."),
  'b6': QuestionEn("Who painted the Mona Lisa?", ["Michelangelo", "Leonardo da Vinci", "Raphael", "Picasso"], "Leonardo da Vinci painted it in the early 16th century."),
  'b7': QuestionEn("What does a light-year measure?", ["Time", "Speed", "Distance", "Mass"], "A light-year is the distance light travels in one year."),
  'b8': QuestionEn("How many bones does an adult human body have?", ["106", "206", "306", "406"], "The adult human skeleton has 206 bones."),
  'b9': QuestionEn("Which planet is known as the 'Red Planet'?", ["Venus", "Mars", "Mercury", "Uranus"], "Mars looks reddish because of iron oxide on its surface."),
  'b10': QuestionEn("What is the chemical formula of water?", ["CO2", "O2", "H2O", "NaCl"], "Water consists of two hydrogen atoms and one oxygen atom."),
  'b11': QuestionEn("Which is the longest river that rises within Turkey and flows into the sea?", ["Sakarya", "Kızılırmak", "Yeşilırmak", "Gediz"], "The Kızılırmak is about 1,355 km long and flows into the Black Sea."),
  'b12': QuestionEn("What is the highest mountain in Turkey?", ["Erciyes", "Mount Ağrı (Ararat)", "Uludağ", "Kaçkar"], "Mount Ağrı is about 5,137 metres high."),
  'b13': QuestionEn("What is the approximate value of pi?", ["2.71", "3.14", "1.62", "4.13"], "Pi is the ratio of a circle's circumference to its diameter."),
  'b14': QuestionEn("What is the sum of the interior angles of a triangle, in degrees?", ["90", "180", "270", "360"], "The interior angles of any triangle in a plane add up to 180 degrees."),
  'b15': QuestionEn("Which gas do plants take in from the air during photosynthesis?", ["Oxygen", "Nitrogen", "Carbon dioxide", "Hydrogen"], "Plants absorb carbon dioxide and release oxygen."),
  'b16': QuestionEn("Who wrote Les Misérables?", ["Victor Hugo", "Balzac", "Dostoevsky", "Dickens"], "Les Misérables is a novel by Victor Hugo, published in 1862."),
  'b17': QuestionEn("Which Ottoman sultan conquered Istanbul?", ["Selim I (Yavuz)", "Suleiman the Magnificent", "Mehmed the Conqueror", "Abdulhamid II"], "Istanbul was conquered on 29 May 1453."),
  'b18': QuestionEn("What is the smallest prime number?", ["0", "1", "2", "3"], "2 is both the smallest prime number and the only even prime."),
  'b19': QuestionEn("Which planet is famous for its rings?", ["Saturn", "Mars", "Venus", "Mercury"], "Saturn's rings are made of pieces of ice and rock."),
  'b20': QuestionEn("What is the highest mountain in the world?", ["K2", "Everest", "Kilimanjaro", "Mont Blanc"], "Everest is about 8,849 metres high."),
  'b21': QuestionEn("How many months of the year have 31 days?", ["5", "6", "7", "8"], "January, March, May, July, August, October and December have 31 days."),
  'b22': QuestionEn("Which organ pumps blood around the body?", ["Liver", "Heart", "Lung", "Kidney"], "The heart pumps blood to the whole body through the vessels."),
  'b23': QuestionEn("Who was the first Turkish astronaut to travel to space?", ["Tuva Atasever", "Alper Gezeravcı", "Ali Kuşçu", "Uğur Şahin"], "Alper Gezeravcı travelled to space in January 2024 on the Axiom-3 mission."),
  'b24': QuestionEn("Which of the following is not a mammal?", ["Dolphin", "Bat", "Penguin", "Whale"], "A penguin is a bird; the others are mammals."),
  'b25': QuestionEn("What is the capital of Japan?", ["Osaka", "Kyoto", "Tokyo", "Nagoya"], "Tokyo is Japan's capital and its most populous city."),
  'b26': QuestionEn("Which building did Mimar Sinan call his 'masterpiece'?", ["Süleymaniye Mosque", "Selimiye Mosque", "Şehzade Mosque", "Sultanahmet Mosque"], "The Selimiye Mosque is in Edirne."),
  'b27': QuestionEn("How many bits are in a byte?", ["4", "8", "16", "32"], "1 byte = 8 bits."),
  'b28': QuestionEn("Which programming language are Flutter apps written in?", ["Kotlin", "Swift", "Dart", "Java"], "Flutter uses Dart, a language developed by Google."),
  'b29': QuestionEn("Which company develops the Android operating system today?", ["Apple", "Google", "Microsoft", "Samsung"], "Android is developed by Google and distributed as open source."),
  'b30': QuestionEn("How many players does a football team field at once?", ["9", "10", "11", "12"], "A team plays with 11 players, including the goalkeeper."),
};
