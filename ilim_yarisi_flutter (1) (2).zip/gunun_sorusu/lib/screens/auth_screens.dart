import 'package:flutter/material.dart';

import '../state/app_scope.dart';
import '../theme/app_icons.dart';
import '../theme/app_theme.dart';
import '../widgets/app_button.dart';
import '../widgets/app_page.dart';
import '../widgets/notice_banner.dart';
import '../widgets/password_field.dart';

// Hesap sistemi (backend) henüz yok: formlar tasarım olarak hazır, gönder
// düğmesi bilinçli olarak devre dışı ve ekranda bilgilendirme gösteriliyor.

Widget _emailField(BuildContext context) => TextField(
      keyboardType: TextInputType.emailAddress,
      textInputAction: TextInputAction.next,
      decoration: appInput(context.pal, label: context.s('auth.email')).copyWith(
        prefixIcon: Icon(AppIcons.mail, size: 20, color: context.pal.muted),
      ),
    );

Widget _nameField(BuildContext context) => TextField(
      textCapitalization: TextCapitalization.words,
      textInputAction: TextInputAction.next,
      decoration: appInput(context.pal, label: context.s('auth.name')).copyWith(
        prefixIcon: Icon(AppIcons.user, size: 20, color: context.pal.muted),
      ),
    );

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return AppPage(
      title: s('auth.welcome'),
      subtitle: s('auth.login_sub'),
      showBack: true,
      child: ListView(
        keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
        padding: const EdgeInsets.fromLTRB(20, 24, 20, 24),
        children: [
          NoticeBanner(text: s('auth.unavailable')),
          const SizedBox(height: 20),
          _emailField(context),
          const SizedBox(height: 12),
          PasswordField(label: s('auth.password'), action: TextInputAction.done),
          const SizedBox(height: 20),
          AppButton(label: s('account.login'), onPressed: null),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              TextButton(
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(builder: (_) => const ForgotPasswordScreen()),
                ),
                child: Text(s('auth.forgot')),
              ),
              TextButton(
                onPressed: () => Navigator.of(context).pushReplacement(
                  MaterialPageRoute<void>(builder: (_) => const RegisterScreen()),
                ),
                child: Text(s('account.register')),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class RegisterScreen extends StatelessWidget {
  const RegisterScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return AppPage(
      title: s('account.register'),
      subtitle: s('auth.register_sub'),
      showBack: true,
      child: ListView(
        keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
        padding: const EdgeInsets.fromLTRB(20, 24, 20, 24),
        children: [
          NoticeBanner(text: s('auth.unavailable')),
          const SizedBox(height: 20),
          _nameField(context),
          const SizedBox(height: 12),
          _emailField(context),
          const SizedBox(height: 12),
          PasswordField(label: s('auth.password')),
          const SizedBox(height: 12),
          PasswordField(label: s('auth.confirm'), action: TextInputAction.done),
          const SizedBox(height: 20),
          AppButton(label: s('account.register'), onPressed: null),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(s('auth.have_account'), style: TextStyle(color: context.pal.muted)),
              TextButton(
                onPressed: () => Navigator.of(context).pushReplacement(
                  MaterialPageRoute<void>(builder: (_) => const LoginScreen()),
                ),
                child: Text(s('account.login')),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class ForgotPasswordScreen extends StatelessWidget {
  const ForgotPasswordScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return AppPage(
      title: s('auth.forgot_title'),
      showBack: true,
      child: ListView(
        keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
        padding: const EdgeInsets.fromLTRB(20, 24, 20, 24),
        children: [
          Text(
            s('auth.forgot_sub'),
            style: TextStyle(fontSize: 15, height: 1.45, color: context.pal.muted),
          ),
          const SizedBox(height: 16),
          NoticeBanner(text: s('auth.unavailable')),
          const SizedBox(height: 20),
          _emailField(context),
          const SizedBox(height: 20),
          AppButton(label: s('auth.send_link'), onPressed: null),
        ],
      ),
    );
  }
}
