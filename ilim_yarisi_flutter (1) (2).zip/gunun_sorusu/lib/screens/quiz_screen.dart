import 'dart:async';

import 'package:flutter/material.dart';

import '../l10n/question_l10n.dart';
import '../state/app_scope.dart';
import '../state/app_state.dart';
import '../theme/app_icons.dart';
import '../theme/app_theme.dart';
import '../utils/constants.dart';
import '../utils/date_utils.dart';
import '../widgets/app_button.dart';
import '../widgets/app_card.dart';
import '../widgets/app_page.dart';
import '../widgets/confirm_dialog.dart';
import '../widgets/option_tile.dart';
import 'result_screen.dart';

/// Aktif soru ekranı: süre bu ekran açıldığında başlar (yalnızca görüntü;
/// puanlama/cevap mantığı AppState'te aynen kalır).
class QuizScreen extends StatefulWidget {
  final AppState state;
  const QuizScreen({super.key, required this.state});

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  final Stopwatch _watch = Stopwatch()..start();
  Timer? _ticker;
  int? _selected;
  bool _submitting = false;

  @override
  void initState() {
    super.initState();
    _startTicker();
  }

  void _startTicker() {
    _ticker?.cancel();
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _ticker?.cancel();
    _watch.stop();
    super.dispose();
  }

  Future<void> _submit() async {
    final sel = _selected;
    if (sel == null || _submitting) return;
    setState(() => _submitting = true);
    _watch.stop();
    _ticker?.cancel();
    try {
      await widget.state.answerToday(sel);
    } catch (_) {
      if (!mounted) return;
      setState(() => _submitting = false);
      _watch.start();
      _startTicker();
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(context.s('quiz.error'))));
      return;
    }
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute<void>(
        builder: (_) => ResultScreen(state: widget.state, elapsed: _watch.elapsed),
      ),
    );
  }

  Future<void> _confirmLeave() async {
    final s = context.s;
    final ok = await showConfirmDialog(
      context,
      title: s('quiz.leave_title'),
      message: s('quiz.leave_msg'),
      confirmLabel: s('quiz.leave'),
    );
    if (ok && mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final p = context.pal;
    final lang = widget.state.language;
    final q = widget.state.todayQuestion;
    final options = q.optionsFor(lang);

    return PopScope(
      canPop: _submitting,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _confirmLeave();
      },
      child: AppPage(
        title: s('home.title'),
        showBack: true,
        trailing: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(999),
            border: Border.all(color: p.gold.withValues(alpha: 0.6)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(AppIcons.timer, size: 16, color: p.gold),
              const SizedBox(width: 6),
              Text(
                formatDuration(_watch.elapsed),
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: p.onHeader,
                ),
              ),
            ],
          ),
        ),
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(20, 24, 20, 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    InfoPill(text: categoryLabel(q.category, lang)),
                    const SizedBox(height: 14),
                    Text(
                      q.textFor(lang),
                      style: AppText.serif(24, color: p.text, height: 1.3),
                    ),
                    const SizedBox(height: 24),
                    for (int i = 0; i < options.length; i++)
                      OptionTile(
                        letter: kLetters[i],
                        text: options[i],
                        isSelected: _selected == i,
                        onTap: _submitting ? null : () => setState(() => _selected = i),
                      ),
                  ],
                ),
              ),
            ),
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 4, 20, 16),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (_selected == null)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Text(
                          s('quiz.select_hint'),
                          style: TextStyle(fontSize: 13, color: p.muted),
                        ),
                      ),
                    AppButton(
                      label: s('quiz.submit'),
                      icon: AppIcons.check,
                      loading: _submitting,
                      onPressed: (_selected == null || _submitting) ? null : _submit,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
