import 'package:flutter/material.dart';

import '../l10n/question_l10n.dart';
import '../state/app_scope.dart';
import '../state/app_state.dart';
import '../theme/app_icons.dart';
import '../theme/app_theme.dart';
import '../utils/constants.dart';
import '../widgets/app_button.dart';
import '../widgets/app_page.dart';
import '../widgets/segmented_pills.dart';

class AddQuestionScreen extends StatefulWidget {
  final AppState state;
  const AddQuestionScreen({super.key, required this.state});

  @override
  State<AddQuestionScreen> createState() => _AddQuestionScreenState();
}

class _AddQuestionScreenState extends State<AddQuestionScreen> {
  final _formKey = GlobalKey<FormState>();
  final _text = TextEditingController();
  final _options = List<TextEditingController>.generate(
    4,
    (_) => TextEditingController(),
  );
  final _explanation = TextEditingController();
  final _category = TextEditingController();
  int _correct = 0;
  bool _saving = false;

  @override
  void dispose() {
    _text.dispose();
    for (final c in _options) {
      c.dispose();
    }
    _explanation.dispose();
    _category.dispose();
    super.dispose();
  }

  String? _required(String? v) {
    if (v == null || v.trim().isEmpty) return context.s('add.required');
    return null;
  }

  Future<void> _save() async {
    if (_saving || !(_formKey.currentState?.validate() ?? false)) return;
    final messenger = ScaffoldMessenger.of(context);
    final navigator = Navigator.of(context);
    final saved = context.s('add.saved');
    final category =
        _category.text.trim().isEmpty ? 'Genel Kültür' : _category.text.trim();

    setState(() => _saving = true);
    await widget.state.addQuestion(
      text: _text.text.trim(),
      options: _options.map((c) => c.text.trim()).toList(),
      correctIndex: _correct,
      explanation: _explanation.text.trim(),
      category: category,
    );
    if (!mounted) return;
    navigator.pop();
    messenger.showSnackBar(SnackBar(content: Text(saved)));
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final p = context.pal;
    return AppPage(
      title: s('add.title'),
      showBack: true,
      child: Form(
        key: _formKey,
        child: ListView(
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          padding: const EdgeInsets.fromLTRB(20, 24, 20, 32),
          children: [
            TextFormField(
              controller: _text,
              decoration: appInput(p, label: s('add.question')),
              minLines: 2,
              maxLines: 4,
              textInputAction: TextInputAction.next,
              validator: _required,
            ),
            const SizedBox(height: 16),
            for (int i = 0; i < 4; i++)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: TextFormField(
                  controller: _options[i],
                  decoration: appInput(p, label: s('add.option', {'letter': kLetters[i]})),
                  textInputAction: TextInputAction.next,
                  validator: _required,
                ),
              ),
            const SizedBox(height: 4),
            Text(
              s('add.correct'),
              style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: p.muted),
            ),
            const SizedBox(height: 8),
            SegmentedPills<int>(
              selected: _correct,
              onChanged: (v) => setState(() => _correct = v),
              items: [
                for (int i = 0; i < 4; i++) PillItem(value: i, label: kLetters[i]),
              ],
            ),
            const SizedBox(height: 20),
            TextFormField(
              controller: _category,
              decoration: appInput(
                p,
                label: s('add.category'),
                hint: categoryLabel('Genel Kültür', widget.state.language),
              ),
              textInputAction: TextInputAction.next,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _explanation,
              decoration: appInput(p, label: s('add.explanation')),
              minLines: 1,
              maxLines: 3,
            ),
            const SizedBox(height: 24),
            AppButton(
              label: s('common.save'),
              icon: AppIcons.check,
              loading: _saving,
              onPressed: _saving ? null : _save,
            ),
          ],
        ),
      ),
    );
  }
}
