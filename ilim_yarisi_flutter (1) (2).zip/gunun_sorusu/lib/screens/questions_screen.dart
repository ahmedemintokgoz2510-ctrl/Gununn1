import 'package:flutter/material.dart';

import '../l10n/question_l10n.dart';
import '../models/question.dart';
import '../state/app_scope.dart';
import '../state/app_state.dart';
import '../theme/app_icons.dart';
import '../theme/app_theme.dart';
import '../utils/constants.dart';
import '../widgets/app_card.dart';
import '../widgets/app_page.dart';
import '../widgets/confirm_dialog.dart';
import '../widgets/option_tile.dart';
import '../widgets/state_views.dart';
import 'add_question_screen.dart';

class QuestionsScreen extends StatefulWidget {
  final AppState state;
  const QuestionsScreen({super.key, required this.state});

  @override
  State<QuestionsScreen> createState() => _QuestionsScreenState();
}

class _QuestionsScreenState extends State<QuestionsScreen> {
  String _category = 'Tümü';

  Future<void> _confirmDelete(Question q) async {
    final s = context.s;
    final ok = await showConfirmDialog(
      context,
      title: s('questions.delete_title'),
      message: q.textFor(widget.state.language),
      confirmLabel: s('common.delete'),
      destructive: true,
    );
    if (ok) await widget.state.deleteQuestion(q.id);
  }

  void _showDetail(Question q) {
    final lang = widget.state.language;
    final options = q.optionsFor(lang);
    final explanation = q.explanationFor(lang);
    final p = context.pal;
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              InfoPill(text: categoryLabel(q.category, lang)),
              const SizedBox(height: 12),
              Text(q.textFor(lang), style: AppText.serif(21, color: p.text, height: 1.3)),
              const SizedBox(height: 16),
              for (int i = 0; i < options.length; i++)
                OptionTile(
                  letter: kLetters[i],
                  text: options[i],
                  revealed: true,
                  isCorrect: i == q.correctIndex,
                ),
              if (explanation.isNotEmpty) ...[
                const SizedBox(height: 4),
                Text(explanation, style: TextStyle(height: 1.45, color: p.muted)),
              ],
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.state,
      builder: (context, _) {
        final s = context.s;
        final p = context.pal;
        final lang = widget.state.language;
        final cats = widget.state.categories;
        if (!cats.contains(_category)) _category = 'Tümü';
        final list = widget.state.allQuestions
            .where((q) => _category == 'Tümü' || q.category == _category)
            .toList();

        return AppPage(
          title: s('questions.title'),
          subtitle: s('questions.count', {'n': list.length}),
          floatingActionButton: FloatingActionButton.extended(
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute<void>(
                builder: (_) => AddQuestionScreen(state: widget.state),
              ),
            ),
            icon: Icon(AppIcons.plus),
            label: Text(s('questions.add')),
          ),
          child: Column(
            children: [
              SizedBox(
                height: 64,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
                  itemCount: cats.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                  itemBuilder: (context, i) {
                    final c = cats[i];
                    final sel = c == _category;
                    return Material(
                      color: sel ? p.primary : p.card,
                      shape: StadiumBorder(side: BorderSide(color: sel ? p.primary : p.line)),
                      child: InkWell(
                        customBorder: const StadiumBorder(),
                        onTap: () => setState(() => _category = c),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          child: Center(
                            child: Text(
                              categoryLabel(c, lang),
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                color: sel ? p.onPrimary : p.text,
                              ),
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
              Expanded(
                child: list.isEmpty
                    ? EmptyState(
                        icon: AppIcons.inbox,
                        title: s('questions.empty_title'),
                        message: s('questions.empty_msg'),
                      )
                    : ListView.separated(
                        padding: const EdgeInsets.fromLTRB(20, 8, 20, 96),
                        itemCount: list.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 10),
                        itemBuilder: (context, i) {
                          final q = list[i];
                          return AppCard(
                            padding: const EdgeInsets.fromLTRB(16, 14, 8, 14),
                            onTap: () => _showDetail(q),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        q.isCustom
                                            ? '${categoryLabel(q.category, lang)} · ${s('questions.mine')}'
                                            : categoryLabel(q.category, lang),
                                        style: TextStyle(
                                          fontSize: 12,
                                          fontWeight: FontWeight.w600,
                                          color: p.muted,
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        q.textFor(lang),
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(fontSize: 15, height: 1.35),
                                      ),
                                    ],
                                  ),
                                ),
                                if (q.isCustom)
                                  IconButton(
                                    icon: Icon(AppIcons.trash, size: 20, color: p.danger),
                                    tooltip: s('common.delete'),
                                    onPressed: () => _confirmDelete(q),
                                  )
                                else
                                  Padding(
                                    padding: const EdgeInsets.symmetric(horizontal: 8),
                                    child: Icon(AppIcons.chevronRight, size: 20, color: p.muted),
                                  ),
                              ],
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        );
      },
    );
  }
}
