import 'package:flutter/material.dart';

import '../l10n/question_l10n.dart';
import '../state/app_scope.dart';
import '../state/app_state.dart';
import '../theme/app_icons.dart';
import '../utils/date_utils.dart';
import '../widgets/app_card.dart';
import '../widgets/app_page.dart';
import '../widgets/state_views.dart';

class HistoryScreen extends StatelessWidget {
  final AppState state;
  const HistoryScreen({super.key, required this.state});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: state,
      builder: (context, _) {
        final s = context.s;
        final p = context.pal;
        final lang = state.language;
        final items = state.history;

        return AppPage(
          title: s('profile.history'),
          subtitle: s('history.count', {'n': items.length}),
          showBack: true,
          child: items.isEmpty
              ? EmptyState(
                  icon: AppIcons.history,
                  title: s('history.empty_title'),
                  message: s('history.empty_msg'),
                )
              : ListView.separated(
                  padding: const EdgeInsets.fromLTRB(20, 24, 20, 24),
                  itemCount: items.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (context, i) {
                    final e = items[i];
                    return AppCard(
                      child: Row(
                        children: [
                          IconBadge(
                            icon: e.correct ? AppIcons.check : AppIcons.close,
                            size: 40,
                            bg: e.correct ? p.successBg : p.dangerBg,
                            color: e.correct ? p.success : p.danger,
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  formatDate(e.date, lang),
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                    color: p.muted,
                                  ),
                                ),
                                const SizedBox(height: 3),
                                Text(
                                  e.question.textFor(lang),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontSize: 15, height: 1.35),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            e.correct ? s('stats.correct') : s('history.wrong'),
                            style: TextStyle(
                              fontSize: 12.5,
                              fontWeight: FontWeight.w700,
                              color: e.correct ? p.success : p.danger,
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
        );
      },
    );
  }
}
