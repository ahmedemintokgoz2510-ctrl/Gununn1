import 'package:flutter/material.dart';

import '../state/app_scope.dart';
import '../state/app_state.dart';
import '../theme/app_icons.dart';
import '../widgets/app_page.dart';
import '../widgets/segmented_pills.dart';
import '../widgets/state_views.dart';

/// Sıralama için sunucu/hesap gerekir; şimdilik dürüst bir boş durum gösterir.
class RankingScreen extends StatefulWidget {
  final AppState state;
  const RankingScreen({super.key, required this.state});

  @override
  State<RankingScreen> createState() => _RankingScreenState();
}

class _RankingScreenState extends State<RankingScreen> {
  String _period = 'monthly';

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return AppPage(
      title: s('ranking.title'),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
            child: SegmentedPills<String>(
              selected: _period,
              onChanged: (v) => setState(() => _period = v),
              items: [
                PillItem(value: 'monthly', label: s('ranking.monthly')),
                PillItem(value: 'daily', label: s('ranking.daily')),
              ],
            ),
          ),
          Expanded(
            child: EmptyState(
              icon: AppIcons.trophy,
              title: s('ranking.empty_title'),
              message: s('ranking.empty_msg'),
            ),
          ),
        ],
      ),
    );
  }
}
