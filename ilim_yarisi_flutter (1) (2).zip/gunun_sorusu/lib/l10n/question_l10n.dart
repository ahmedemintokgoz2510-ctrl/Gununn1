import '../data/builtin_questions_en.dart';
import '../models/question.dart';

extension QuestionL10n on Question {
  QuestionEn? _en(String lang) =>
      (lang == 'en' && !isCustom) ? kEnQuestions[id] : null;

  String textFor(String lang) => _en(lang)?.text ?? text;
  List<String> optionsFor(String lang) => _en(lang)?.options ?? options;
  String explanationFor(String lang) => _en(lang)?.explanation ?? explanation;
}

/// Kategori anahtarları veride Türkçe tutulur; yalnızca görünen ad çevrilir.
const Map<String, String> _catEn = {
  'Tümü': 'All',
  'Coğrafya': 'Geography',
  'Bilim': 'Science',
  'Tarih': 'History',
  'Sanat': 'Art',
  'Matematik': 'Mathematics',
  'Edebiyat': 'Literature',
  'Genel Kültür': 'General Knowledge',
  'Teknoloji': 'Technology',
  'Spor': 'Sports',
};

String categoryLabel(String key, String lang) =>
    lang == 'en' ? (_catEn[key] ?? key) : key;
