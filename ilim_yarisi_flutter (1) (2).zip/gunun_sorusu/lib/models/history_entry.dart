import 'question.dart';

class HistoryEntry {
  final String dateKey; // yyyy-MM-dd
  final Question question;
  final int answer;
  const HistoryEntry({
    required this.dateKey,
    required this.question,
    required this.answer,
  });

  bool get correct => answer == question.correctIndex;
  DateTime get date => DateTime.parse(dateKey);
}
