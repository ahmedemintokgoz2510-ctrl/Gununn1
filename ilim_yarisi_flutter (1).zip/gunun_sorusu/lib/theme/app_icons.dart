import 'package:flutter/widgets.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

/// Tüm Lucide ikonları tek yerden gelir. Paket sürümünde bir ikon adı
/// değişirse yalnızca bu dosya düzeltilir.
class AppIcons {
  AppIcons._();
  static const IconData home = LucideIcons.house;
  static const IconData questions = LucideIcons.bookOpen;
  static const IconData stats = LucideIcons.trendingUp;
  static const IconData settings = LucideIcons.settings;
  static const IconData flame = LucideIcons.flame;
  static const IconData check = LucideIcons.check;
  static const IconData close = LucideIcons.x;
  static const IconData chevronRight = LucideIcons.chevronRight;
  static const IconData back = LucideIcons.chevronLeft;
  static const IconData arrowRight = LucideIcons.arrowRight;
  static const IconData plus = LucideIcons.plus;
  static const IconData trash = LucideIcons.trash2;
  static const IconData timer = LucideIcons.timer;
  static const IconData globe = LucideIcons.globe;
  static const IconData sun = LucideIcons.sun;
  static const IconData moon = LucideIcons.moon;
  static const IconData phone = LucideIcons.smartphone;
  static const IconData reset = LucideIcons.rotateCcw;
  static const IconData star = LucideIcons.star;
  static const IconData info = LucideIcons.info;
  static const IconData target = LucideIcons.target;
  static const IconData calendar = LucideIcons.calendar;
  static const IconData inbox = LucideIcons.inbox;
  static const IconData refresh = LucideIcons.refreshCw;
  static const IconData award = LucideIcons.award;
  static const IconData user = LucideIcons.user;
  static const IconData mail = LucideIcons.mail;
  static const IconData lock = LucideIcons.lock;
  static const IconData eye = LucideIcons.eye;
  static const IconData eyeOff = LucideIcons.eyeOff;
  static const IconData bell = LucideIcons.bell;
  static const IconData gift = LucideIcons.gift;
  static const IconData history = LucideIcons.history;
  static const IconData logOut = LucideIcons.logOut;
  static const IconData trophy = LucideIcons.trophy;
}
