GUNUN SORUSU - Flutter (Android)

1) Bu klasoru GitHub reposuna yukle (zip'i ac, icindekileri yukle).
2) CodeMagic'te repoyu bagla. codemagic.yaml otomatik algilanir.
   Pipeline once android/ klasorunu olusturur (flutter create), sonra APK derler.
3) Yerelde calistirmak icin: klasorde `flutter create . --platforms=android` bir kez, sonra `flutter run`.

Soru eklemek icin: uygulamada "Sorular" sekmesi > "Soru Ekle"
veya lib/data/builtin_questions.dart dosyasina elle ekle.

--- ARAYUZ YENILEMESI (Ilim Yarisi) ---
- Tasarim sistemi: lib/theme (renkler, tema, Lucide ikonlari), lib/widgets (ortak bilesenler)
- Dil (TR/EN): lib/l10n/strings.dart ; yerlesik sorularin Ingilizcesi: lib/data/builtin_questions_en.dart
  Yeni yerlesik soru eklersen buraya da ayni id ile Ingilizce karsiligini ekle.
- Ikon adi derleme hatasi verirse yalnizca lib/theme/app_icons.dart duzeltilir.
- Hesap/giris/siralama/odul/bildirim ekranlari tasarim olarak hazir ama backend yok:
  bilgilendirme/bos durum gosterirler. Backend eklenince bu ekranlara baglanir.
- Katilim gecmisi cihazdaki mevcut kayitlardan okunur; "Istatistikleri sifirla" gecmisi de siler.
